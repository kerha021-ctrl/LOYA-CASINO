(()=>{
'use strict';
/* ================= utilidades ================= */
const $=s=>document.querySelector(s),$$=s=>Array.from(document.querySelectorAll(s));
const clamp=(v,a,b)=>Math.max(a,Math.min(b,v)),rnd=(a,b)=>a+Math.random()*(b-a),ri=(a,b)=>Math.floor(rnd(a,b+1));
const mod=(x,m)=>((x%m)+m)%m,TAU=Math.PI*2;
const fmt=n=>Math.round(n).toLocaleString('es-ES');
const E={out:t=>1-Math.pow(1-t,3),io:t=>t<.5?4*t*t*t:1-Math.pow(-2*t+2,3)/2,back:t=>{const c=1.1;return 1+(c+1)*Math.pow(t-1,3)+c*Math.pow(t-1,2)},out4:t=>1-Math.pow(1-t,4)};
const esc=s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const clone=o=>JSON.parse(JSON.stringify(o));
function merge(a,b){for(const k in b){if(b[k]&&typeof b[k]==='object'&&!Array.isArray(b[k])&&a[k]&&typeof a[k]==='object'&&!Array.isArray(a[k]))merge(a[k],b[k]);else a[k]=b[k];}return a;}
let toastT=0;function toast(m){const t=$('#toast');t.textContent=m;t.classList.add('on');clearTimeout(toastT);toastT=setTimeout(()=>t.classList.remove('on'),2200);}

/* ================= audio ================= */
let AC=null,tickT=0;
const S={screen:'home',game:null,admin:false,coins:0,shown:0,mute:false,slotMult:1,slLast:0,rGroup:'red',rTier:0,cardMode:'bot'};
function tone(f,d=.12,type='sine',v=.05,when=0){if(S.mute)return;try{AC=AC||new(window.AudioContext||window.webkitAudioContext)();const o=AC.createOscillator(),g=AC.createGain();o.type=type;o.frequency.value=f;const t=AC.currentTime+when;g.gain.setValueAtTime(v,t);g.gain.exponentialRampToValueAtTime(.0001,t+d);o.connect(g);g.connect(AC.destination);o.start(t);o.stop(t+d+.02);}catch(e){}}
const sfx={tick(){const n=performance.now();if(n-tickT<55)return;tickT=n;tone(900,.04,'square',.015)},win(){[523,659,784,1047].forEach((f,i)=>tone(f,.25,'triangle',.06,i*.09))},lose(){tone(180,.3,'sawtooth',.03)},card(){tone(300,.07,'triangle',.04)},jack(){[523,659,784,1047,1319,1568].forEach((f,i)=>tone(f,.32,'triangle',.07,i*.08))}};

/* ================= configuración ================= */
function defSegs(){const a=[{l:'0',c:'#0f9d58',g:'green',w:.4}];for(let i=1;i<=14;i++)a.push({l:String(i),c:i%2?'#b3132a':'#17171d',g:i%2?'red':'black',w:.8});a.push({l:'★',c:'#d9a521',g:'gold',w:.25});for(let i=0;i<5;i++)a.push({l:'✖',c:'#2d2a3d',g:'house',w:3});return a;}
const DEF={ver:5,startCoins:1000,winMul:1.3,
 fx:{stars:true,fireworks:true,lights:true,rainbow:false},jackpotAura:'gold',coinColor:'#f0bf4a',
 slots:{bet:10,spinTime:2,winChance:14,jackpotChance:.4,jackpotPrize:5000,jackpotIndex:4,
  symbols:[{s:'🍒',m:3},{s:'🍋',m:4},{s:'🔔',m:6},{s:'⭐',m:8},{s:'7️⃣',m:0},{s:'🍀',m:10},{s:'👑',m:15},{s:'💎',m:20}],
  reelColor:'#1d1530',frameColor:'#d4a23a',bulbColor:'#ffd36b'},
 roulette:{bet:10,luck:40,spinTime:6.2,pay:{red:4,black:4,green:25,gold:40},
  tiers:[{n:'Normal',cost:1,boost:0},{n:'Suerte',cost:2,boost:8},{n:'Súper',cost:4,boost:16},{n:'Mega',cost:8,boost:28}],segments:defSegs()},
 cards:{randomBot:true,streakWins:3,streakLoss:2,playerWinChance:30,bet:50,prize:100,betMin:10,betMax:100000,payout:2,frame:'#c9a45a',panel:'#4a3220',ink:'#d9c08a',backBase:'#0b0a14',backAccent:'#7b6cf0',felt:'#15101f'},
 daily:{r:[10,20,30,40,50,60,70]},
 plush:{cost:100,grabChance:50,sellPct:100,upgBase:40,upgStep:30,rar:{normal:{p:33.5,v:30},plata:{p:24,v:90},oro:{p:16,v:180},diamante:{p:10,v:450},ultra:{p:6,v:1200},mega:{p:5.5,v:4500},unico:{p:5,v:300000}},auraI:1,aura:{plata:'#dde8ff',oro:'#ffc83a',diamante:'#6ff0ff',ultra:'#c060ff',mega:'#ff5a1e'},spMul:[1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1]}};
let cfg=loadCfg();
function loadCfg(){try{const s=localStorage.getItem('loya_cfg');if(s){const o=JSON.parse(s),v=o.ver||1;if(v<2){if(o.slots){delete o.slots.winChance;delete o.slots.jackpotChance;}if(o.roulette){delete o.roulette.pay;delete o.roulette.tiers;delete o.roulette.segments;}}if(v<3&&o.plush)delete o.plush.cost;if(v<4&&o.cards)delete o.cards.playerWinChance;if(v<5&&o.plush&&o.plush.rar)Object.keys(o.plush.rar).forEach(k=>{const q=o.plush.rar[k];if(q&&typeof q.v==='number')q.v*=3;});const c=merge(clone(DEF),o);c.ver=5;return c;}}catch(e){}return clone(DEF);}
const winM=()=>Math.max(0,cfg.winMul==null?1:cfg.winMul);
function saveCfg(){try{localStorage.setItem('loya_cfg',JSON.stringify(cfg));}catch(e){}}
function saveCoins(){try{localStorage.setItem('loya_coins',String(S.coins));}catch(e){}}
(function(){let c=NaN;try{c=parseFloat(localStorage.getItem('loya_coins'));}catch(e){}S.coins=isNaN(c)?cfg.startCoins:c;S.shown=S.coins;})();
function addCoins(n){S.coins=Math.max(0,Math.round(S.coins+n));saveCoins();}
const getP=p=>p.split('.').reduce((o,k)=>o==null?o:o[k],cfg);
function setP(p,v){const k=p.split('.');let o=cfg;for(let i=0;i<k.length-1;i++)o=o[k[i]];o[k[k.length-1]]=v;}

/* ================= tweens ================= */
const TWS=[];
function tw(dur,fn,ease=E.io,delay=0){return new Promise(res=>TWS.push({t:-delay,dur:Math.max(dur,.0001),fn,ease,res}));}
function runTweens(dt){for(let i=TWS.length-1;i>=0;i--){const w=TWS[i];w.t+=dt;if(w.t<0)continue;const p=Math.min(1,w.t/w.dur);w.fn(w.ease(p));if(p>=1){TWS.splice(i,1);w.res();}}}
const sleep=ms=>tw(ms/1000,()=>{},E.io);

/* ================= three base ================= */
let renderer;
try{renderer=new THREE.WebGLRenderer({canvas:$('#gl'),antialias:true});}
catch(e){document.body.insertAdjacentHTML('beforeend','<div style="position:fixed;inset:0;display:grid;place-items:center;z-index:99;color:#fff;padding:30px;text-align:center">Tu dispositivo no soporta WebGL, necesario para los gráficos 3D.</div>');throw e;}
renderer.setPixelRatio(Math.min(devicePixelRatio,2));
renderer.outputEncoding=THREE.sRGBEncoding;renderer.toneMapping=THREE.ACESFilmicToneMapping;renderer.toneMappingExposure=1.05;
function makeEnv(r){try{const c=document.createElement('canvas');c.width=512;c.height=256;const g=c.getContext('2d');
 const gr=g.createLinearGradient(0,0,0,256);gr.addColorStop(0,'#2a2140');gr.addColorStop(.5,'#0d0b14');gr.addColorStop(1,'#3a2a10');g.fillStyle=gr;g.fillRect(0,0,512,256);
 [[80,70,60,'#fff2c8'],[260,50,50,'#ffffff'],[400,90,70,'#ffd27a'],[180,150,40,'#9d8cff'],[330,170,50,'#ffb36b']].forEach(([x,y,q,col])=>{const rg=g.createRadialGradient(x,y,0,x,y,q);rg.addColorStop(0,col);rg.addColorStop(1,'rgba(0,0,0,0)');g.fillStyle=rg;g.fillRect(x-q,y-q,q*2,q*2);});
 const t=new THREE.CanvasTexture(c);t.mapping=THREE.EquirectangularReflectionMapping;t.encoding=THREE.sRGBEncoding;
 const pm=new THREE.PMREMGenerator(r);const e=pm.fromEquirectangular(t).texture;pm.dispose();t.dispose();return e;}catch(e){return null;}}
const ENV=makeEnv(renderer);
const goldMat=c=>new THREE.MeshStandardMaterial({color:c,metalness:.9,roughness:.28});
const SCENES=[];
function mkScene(o){const scene=new THREE.Scene();scene.background=new THREE.Color(0x07060b);if(ENV)scene.environment=ENV;
 const fov=o.fov||45,camera=new THREE.PerspectiveCamera(fov,innerWidth/innerHeight,.1,300);
 const s={scene,camera,dir:new THREE.Vector3(...o.dir).normalize(),fitW:o.fitW,fitH:o.fitH,shift:o.shift||0,target:new THREE.Vector3(...(o.target||[0,0,0])),update(){}};
 s.fit=()=>{camera.aspect=innerWidth/innerHeight;const t=Math.tan(THREE.MathUtils.degToRad(fov/2));const d=Math.max((s.fitH/2)/t,(s.fitW/2)/(t*camera.aspect));
  camera.position.copy(s.target).addScaledVector(s.dir,d);camera.lookAt(s.target);camera.updateMatrixWorld();camera.updateProjectionMatrix();
  if(s.shift){const H=2*d*t,up=new THREE.Vector3().setFromMatrixColumn(camera.matrixWorld,1).multiplyScalar(-s.shift*H);camera.position.add(up);camera.lookAt(s.target.clone().add(up));camera.updateMatrixWorld();}};
 SCENES.push(s);return s;}
function addLights(sc){sc.add(new THREE.AmbientLight(0x8a7aa8,.55));const d=new THREE.DirectionalLight(0xfff1d6,1.15);d.position.set(3,9,7);sc.add(d);
 const p1=new THREE.PointLight(0xffc766,1.1,60);p1.position.set(-5,4,6);sc.add(p1);const p2=new THREE.PointLight(0x8f7bff,.9,60);p2.position.set(5,-2,6);sc.add(p2);}
const ray=new THREE.Raycaster(),ndc=new THREE.Vector2();
function pNdc(e){ndc.set(e.clientX/innerWidth*2-1,-(e.clientY/innerHeight)*2+1);}
function rrect(g,x,y,w,h,r){g.beginPath();g.moveTo(x+r,y);g.arcTo(x+w,y,x+w,y+h,r);g.arcTo(x+w,y+h,x,y+h,r);g.arcTo(x,y+h,x,y,r);g.arcTo(x,y,x+w,y,r);g.closePath();}
function speckle(g,W,H,n,col,s){g.fillStyle=col;for(let i=0;i<n;i++)g.fillRect(Math.random()*W,Math.random()*H,s,s);}
function starBurst(g,x,y,r,pts,col){g.fillStyle=col;g.beginPath();for(let i=0;i<pts*2;i++){const a=i*Math.PI/pts-Math.PI/2,q=i%2?r*.4:r;g.lineTo(x+Math.cos(a)*q,y+Math.sin(a)*q);}g.closePath();g.fill();}
function canvasTex(c){const t=new THREE.CanvasTexture(c);t.encoding=THREE.sRGBEncoding;t.anisotropy=4;return t;}
function mulberry(a){return function(){a|=0;a=a+0x6D2B79F5|0;let t=Math.imul(a^a>>>15,1|a);t=t+Math.imul(t^t>>>7,61|t)^t;return((t^t>>>14)>>>0)/4294967296}}

/* ================= efectos 2D ================= */
const fxc=$('#fx'),fg=fxc.getContext('2d');let FW=0,FH=0,fxDirty=false;
let FXMASK=null;
const P=[],LS=[],RB=[];let FIRE=null;
function fxResize(){const d=Math.min(devicePixelRatio,1.5);FW=innerWidth;FH=innerHeight;fxc.width=FW*d;fxc.height=FH*d;fg.setTransform(d,0,0,d,0,0);}
function pAdd(o){const p=Object.assign({x:0,y:0,vx:0,vy:0,g:0,life:1,size:6,hue:45,type:'dot',rot:0,vr:0},o);p.max=p.life;P.push(p);}
function starPath(g,x,y,r,rot){g.beginPath();for(let i=0;i<10;i++){const a=rot+i*Math.PI/5-Math.PI/2,q=i%2?r*.45:r;g.lineTo(x+Math.cos(a)*q,y+Math.sin(a)*q);}g.closePath();}
function burst(x,y){const h=ri(0,360);for(let i=0;i<46;i++){const a=rnd(0,TAU),s=rnd(90,330);pAdd({x,y,vx:Math.cos(a)*s,vy:Math.sin(a)*s,g:170,life:rnd(1,1.7),size:rnd(2.5,4.5),hue:h+rnd(-25,25)});}}
function fxPlay(kinds,big){
 if(kinds.includes('stars'))for(let i=0;i<(big?90:50);i++){const a=rnd(0,TAU),s=rnd(200,720);pAdd({type:'star',x:FW/2,y:FH*.42,vx:Math.cos(a)*s,vy:Math.sin(a)*s-200,g:520,life:rnd(1.5,2.6),size:rnd(7,17),hue:rnd(38,58),rot:rnd(0,TAU),vr:rnd(-5,5)});}
 if(kinds.includes('fireworks'))for(let b=0;b<(big?8:4);b++)setTimeout(()=>burst(rnd(.15,.85)*FW,rnd(.15,.5)*FH),b*330);
 if(kinds.includes('lights'))LS.push({t:0,dur:big?4.6:3});
 if(kinds.includes('rainbow'))RB.push({t:0,dur:big?5:3.6});
 if(kinds.includes('fire'))FIRE={t:0,dur:5};
 if(kinds.includes('gold'))for(let i=0;i<(big?140:70);i++)pAdd({type:'star',x:rnd(0,FW),y:rnd(-FH*.3,0),vx:rnd(-40,40),vy:rnd(80,360),g:120,life:rnd(2,3.4),size:rnd(4,11),hue:rnd(40,52),rot:rnd(0,TAU),vr:rnd(-4,4)});}
function fxStep(dt){
 if(!(P.length||LS.length||RB.length||FIRE)){if(fxDirty){fg.clearRect(0,0,FW,FH);fxDirty=false;}return;}
 fxDirty=true;fg.clearRect(0,0,FW,FH);
 if(FXMASK){fg.save();fg.beginPath();fg.rect(0,0,FW,FH);fg.ellipse(FXMASK.x,FXMASK.y,FXMASK.rx,FXMASK.ry,0,0,TAU);fg.clip('evenodd');}
 for(let i=RB.length-1;i>=0;i--){const r=RB[i];r.t+=dt;const p=r.t/r.dur;if(p>=1){RB.splice(i,1);continue;}
  const gr=clamp(p*3,0,1),fd=p>.7?1-(p-.7)/.3:1,cx=FW/2,cy=FH*.62,R0=Math.min(FW*.62,FH*.45);
  fg.save();fg.globalAlpha=.75*fd;fg.lineWidth=R0*.07;
  for(let k=0;k<7;k++){fg.strokeStyle='hsl('+(k*50)+',95%,58%)';fg.beginPath();fg.arc(cx,cy,R0-k*R0*.07,Math.PI,Math.PI+Math.PI*E.out(gr));fg.stroke();}fg.restore();}
 fg.globalCompositeOperation='lighter';
 for(let i=LS.length-1;i>=0;i--){const l=LS[i];l.t+=dt;if(l.t>=l.dur){LS.splice(i,1);continue;}const fd=Math.sin(Math.PI*l.t/l.dur);
  for(let k=0;k<6;k++){const ox=k%2?FW:0,oy=FH,a=-Math.PI/2+(k%2?-.35:.35)+Math.sin(l.t*2+k*1.3)*.8,len=FH*1.3,sp=.1;
   const gr=fg.createLinearGradient(ox,oy,ox+Math.cos(a)*len,oy+Math.sin(a)*len);const col='hsla('+((l.t*90+k*60)%360)+',100%,60%,';gr.addColorStop(0,col+(.38*fd)+')');gr.addColorStop(1,col+'0)');
   fg.fillStyle=gr;fg.beginPath();fg.moveTo(ox,oy);fg.lineTo(ox+Math.cos(a-sp)*len,oy+Math.sin(a-sp)*len);fg.lineTo(ox+Math.cos(a+sp)*len,oy+Math.sin(a+sp)*len);fg.closePath();fg.fill();}}
 if(FIRE){FIRE.t+=dt;if(FIRE.t>FIRE.dur)FIRE=null;else for(let i=0;i<10;i++)pAdd({type:'fire',x:rnd(0,FW),y:FH+10,vx:rnd(-30,30),vy:-rnd(250,520),g:-60,life:rnd(.7,1.3),size:rnd(14,34)});}
 for(let i=P.length-1;i>=0;i--){const p=P[i];p.life-=dt;if(p.life<=0||P.length>1400){P.splice(i,1);continue;}
  p.vy+=p.g*dt;p.x+=p.vx*dt;p.y+=p.vy*dt;p.rot+=p.vr*dt;const a=clamp(p.life/(p.max*.5),0,1);
  if(p.type==='star'){fg.fillStyle='hsla('+p.hue+',100%,'+(60+a*10)+'%,'+a+')';starPath(fg,p.x,p.y,p.size,p.rot);fg.fill();}
  else if(p.type==='fire'){const q=p.life/p.max;fg.fillStyle='hsla('+(15+(1-q)*35)+',100%,'+(45+(1-q)*20)+'%,'+(q*.55)+')';fg.beginPath();fg.arc(p.x,p.y,p.size*q,0,TAU);fg.fill();}
  else{fg.fillStyle='hsla('+p.hue+',100%,62%,'+a+')';fg.beginPath();fg.arc(p.x,p.y,p.size,0,TAU);fg.fill();}}
 fg.globalCompositeOperation='source-over';if(FXMASK)fg.restore();}
function celebrate(big){const k=Object.keys(cfg.fx).filter(x=>cfg.fx[x]);
 if(big){k.push(cfg.jackpotAura==='fire'?'fire':cfg.jackpotAura==='rainbow'?'rainbow':cfg.jackpotAura==='gold'?'gold':'stars');if(!k.includes('fireworks'))k.push('fireworks');}
 fxPlay(Array.from(new Set(k)),big);big?sfx.jack():sfx.win();}

/* ================= moneda 3D de premio ================= */
const COIN={visible:false};let winTimer=0;
function initCoin(){const cv=$('#coinGL');const r=new THREE.WebGLRenderer({canvas:cv,antialias:true,alpha:true});r.setPixelRatio(Math.min(devicePixelRatio,2));r.setSize(260,260,false);r.setClearColor(0x000000,0);
 r.outputEncoding=THREE.sRGBEncoding;r.toneMapping=THREE.ACESFilmicToneMapping;
 const sc=new THREE.Scene(),env=makeEnv(r);if(env)sc.environment=env;const cam=new THREE.PerspectiveCamera(35,1,.1,50);cam.position.set(0,0,7.4);
 addLights(sc);
 const fc=document.createElement('canvas');fc.width=fc.height=512;const tex=canvasTex(fc);
 const side=new THREE.MeshStandardMaterial({color:new THREE.Color(cfg.coinColor),metalness:.9,roughness:.25});
 const grp=new THREE.Group();const cyl=new THREE.CylinderGeometry(1,1,.16,64,1,true);cyl.rotateX(Math.PI/2);grp.add(new THREE.Mesh(cyl,side));
 const rim=new THREE.Mesh(new THREE.TorusGeometry(1,.06,12,64),side);grp.add(rim);
 const fm=new THREE.MeshStandardMaterial({map:tex,metalness:.55,roughness:.35,emissiveMap:tex,emissive:0xffffff,emissiveIntensity:.25});
 const f1=new THREE.Mesh(new THREE.CircleGeometry(.96,64),fm);f1.position.z=.082;grp.add(f1);
 const f2=new THREE.Mesh(new THREE.CircleGeometry(.96,64),fm);f2.position.z=-.082;f2.rotation.y=Math.PI;grp.add(f2);
 sc.add(grp);Object.assign(COIN,{r,sc,cam,grp,side,tex,g:fc.getContext('2d'),fc,fm});}
function drawCoin(amount){if(!COIN.r)initCoin();const g=COIN.g,Z=512,col=new THREE.Color(cfg.coinColor);COIN.side.color.copy(col);
 const c=cfg.coinColor;g.clearRect(0,0,Z,Z);const gr=g.createRadialGradient(200,190,20,256,256,260);gr.addColorStop(0,'#fff6c8');gr.addColorStop(.35,c);gr.addColorStop(1,'#6e470a');
 g.fillStyle=gr;g.beginPath();g.arc(256,256,254,0,TAU);g.fill();g.strokeStyle='rgba(90,55,5,.7)';g.lineWidth=10;g.beginPath();g.arc(256,256,226,0,TAU);g.stroke();
 g.strokeStyle='rgba(255,246,200,.55)';g.lineWidth=4;g.setLineDash([3,12]);g.beginPath();g.arc(256,256,206,0,TAU);g.stroke();g.setLineDash([]);
 g.textAlign='center';g.textBaseline='middle';g.fillStyle='#5a3a05';g.font='800 50px Cinzel,Georgia,serif';g.fillText('LOYA',256,120);
 const t=fmt(amount);const sz=clamp(210-t.length*20,70,170);g.font='900 '+sz+'px Cinzel,Georgia,serif';g.lineWidth=8;g.strokeStyle='rgba(255,246,200,.85)';g.strokeText(t,256,262);g.fillStyle='#5a3a05';g.fillText(t,256,262);
 for(let i=0;i<14;i++){const a=i/14*TAU;g.strokeStyle='#5a3a05';g.lineWidth=5;g.beginPath();g.moveTo(256+Math.cos(a)*40,400+Math.sin(a)*14);g.lineTo(256+Math.cos(a)*62,400+Math.sin(a)*22);g.stroke();}
 g.fillStyle='#5a3a05';g.beginPath();g.ellipse(256,400,22,8,0,0,TAU);g.fill();COIN.tex.needsUpdate=true;}
function showWin(amount,o={}){$('#win').classList.toggle('cmp',!!o.compact);drawCoin(amount);$('#winT').textContent=o.title||(o.jackpot?'¡PREMIO MAYOR!':'¡GANASTE!');$('#winA').textContent='+'+fmt(amount);
 $('#win').classList.remove('hidden');COIN.visible=true;clearTimeout(winTimer);winTimer=setTimeout(hideWin,o.jackpot?5200:3400);}
function hideWin(){$('#win').classList.add('hidden');COIN.visible=false;}
$('#win').addEventListener('click',hideWin);
function coinRender(T){if(!COIN.visible)return;const g=COIN.grp;g.rotation.y=T*2.6;g.rotation.x=Math.sin(T*1.7)*.2;g.scale.setScalar(1+Math.sin(T*5)*.04);COIN.r.render(COIN.sc,COIN.cam);}

/* ================= escena de inicio / lobby ================= */
const AMB=mkScene({fov:45,dir:[0,0,1],fitW:7.2,fitH:7.5,shift:.05});
addLights(AMB.scene);
function buildEmblem(){const g=new THREE.Group(),spin=new THREE.Group();g.add(spin);
 const gold=goldMat(0xe2b449),dark=new THREE.MeshStandardMaterial({color:0x0a0a0c,roughness:.5,metalness:.3});
 for(let i=0;i<18;i++){const a=i/18*TAU,long=i%2===0,h=long?2.1:1.3,c=new THREE.Mesh(new THREE.ConeGeometry(long?.3:.22,h,4),gold),r=1.15+h/2;
  c.position.set(Math.cos(a)*r,Math.sin(a)*r,0);c.rotation.z=a-Math.PI/2;c.rotation.y=Math.PI/4;spin.add(c);}
 g.add(new THREE.Mesh(new THREE.TorusGeometry(1.2,.09,12,64),gold));
 const sk=new THREE.Mesh(new THREE.SphereGeometry(1,48,32),gold);sk.scale.set(.95,1.05,.7);g.add(sk);
 [-.35,.35].forEach(x=>{const e=new THREE.Mesh(new THREE.SphereGeometry(.24,24,16),dark);e.scale.set(1,1.15,.5);e.position.set(x,.15,.62);g.add(e);});
 const nose=new THREE.Mesh(new THREE.ConeGeometry(.1,.26,3),dark);nose.position.set(0,-.12,.68);nose.rotation.x=Math.PI;g.add(nose);
 const mouth=new THREE.Mesh(new THREE.BoxGeometry(.7,.07,.1),dark);mouth.position.set(0,-.5,.58);g.add(mouth);
 for(let i=-2;i<=2;i++){const t=new THREE.Mesh(new THREE.BoxGeometry(.03,.2,.1),dark);t.position.set(i*.14,-.5,.58);g.add(t);}
 const hit=new THREE.Mesh(new THREE.SphereGeometry(2.6,12,8),new THREE.MeshBasicMaterial({transparent:true,opacity:0,depthWrite:false}));g.add(hit);g.userData.spin=spin;return g;}
const EMB=buildEmblem();AMB.scene.add(EMB);
const FL=[];
(function(){const cg=new THREE.CylinderGeometry(.34,.34,.07,28);cg.rotateX(Math.PI/2);const cm=goldMat(0xe2b449);
 for(let i=0;i<18;i++){const m=new THREE.Mesh(cg,cm);m.userData={x:rnd(-5.5,5.5),y:rnd(-9,9),z:rnd(-7,-1),vy:rnd(.25,.8),sp:rnd(.8,2.5)};AMB.scene.add(m);FL.push(m);}
 const n=240,pos=new Float32Array(n*3);for(let i=0;i<n;i++){pos[i*3]=rnd(-9,9);pos[i*3+1]=rnd(-10,10);pos[i*3+2]=rnd(-8,2);}
 const geo=new THREE.BufferGeometry();geo.setAttribute('position',new THREE.BufferAttribute(pos,3));
 AMB.pts=new THREE.Points(geo,new THREE.PointsMaterial({color:0xffd98a,size:.06,transparent:true,opacity:.7,depthWrite:false,blending:THREE.AdditiveBlending}));AMB.scene.add(AMB.pts);})();
AMB.cards=[];
function buildAmbCards(){AMB.cards.forEach(m=>AMB.scene.remove(m));AMB.cards=[];const geo=new THREE.PlaneGeometry(1.2,1.7);
 for(let i=0;i<7;i++){const m=new THREE.Mesh(geo,new THREE.MeshBasicMaterial({map:backTex(),transparent:true,alphaTest:.5,side:THREE.DoubleSide}));m.userData={x:rnd(-5,5),y:rnd(-9,9),z:rnd(-6,-2),vy:rnd(.2,.55),sp:rnd(.4,1.2)};AMB.scene.add(m);AMB.cards.push(m);}}
AMB.update=(T,dt)=>{EMB.visible=S.screen==='home';EMB.rotation.y=Math.sin(T*.7)*.45;EMB.rotation.x=Math.sin(T*.5)*.12;EMB.userData.spin.rotation.z=T*.15;
 const mv=m=>{const u=m.userData;u.y-=u.vy*dt;if(u.y<-9)u.y=9;m.position.set(u.x,u.y,u.z);m.rotation.x=T*u.sp;m.rotation.y=T*u.sp*.7;};
 FL.forEach(mv);AMB.cards.forEach(mv);AMB.pts.rotation.y=T*.02;};

/* ================= TRAGAPERRAS ================= */
const SL=mkScene({fov:40,dir:[0,.1,1],fitW:7.8,fitH:6.4,shift:.1});
addLights(SL.scene);
SL.machine=new THREE.Group();SL.scene.add(SL.machine);
Object.assign(SL,{reels:[],bulbs:[],busy:false,dirty:false,auraT:0,flash:0,n:8,pending:null,jt:0});
function drawSymbol(g,sym,w,h){g.textAlign='center';g.textBaseline='middle';let fs=120;g.font=fs+'px "Apple Color Emoji","Segoe UI Emoji","Noto Color Emoji",system-ui,sans-serif';const m=g.measureText(sym).width;if(m>w*.82){fs=Math.floor(fs*w*.82/m);g.font=fs+'px "Apple Color Emoji","Segoe UI Emoji","Noto Color Emoji",system-ui,sans-serif';}g.fillText(sym,w/2,h/2+8);}
function paintTile(g,sym){const w=256,h=228;g.fillStyle=cfg.slots.reelColor;g.fillRect(0,0,w,h);const rg=g.createRadialGradient(w/2,h/2,10,w/2,h/2,150);rg.addColorStop(0,'rgba(255,255,255,.2)');rg.addColorStop(1,'rgba(0,0,0,.35)');g.fillStyle=rg;g.fillRect(0,0,w,h);
 g.strokeStyle='rgba(231,184,75,.5)';g.lineWidth=6;g.strokeRect(4,4,w-8,h-8);g.shadowColor='rgba(0,0,0,.6)';g.shadowBlur=14;drawSymbol(g,sym,w,h);g.shadowBlur=0;}
function drawJackTile(g,t,style,sym){const w=256,h=228;g.clearRect(0,0,w,h);
 if(style==='fire'){const bg=g.createLinearGradient(0,0,0,h);bg.addColorStop(0,'#2a0500');bg.addColorStop(1,'#7a1a00');g.fillStyle=bg;g.fillRect(0,0,w,h);g.globalCompositeOperation='lighter';
  for(let i=0;i<9;i++){const x=(i+.5)*w/9,hh=h*(.5+.35*Math.sin(t*7+i*1.9)+.1*Math.sin(t*13+i)),wb=Math.sin(t*5+i)*10;const gr=g.createLinearGradient(0,h,0,h-hh);gr.addColorStop(0,'rgba(255,200,40,.95)');gr.addColorStop(.5,'rgba(255,100,20,.7)');gr.addColorStop(1,'rgba(255,40,0,0)');
   g.fillStyle=gr;g.beginPath();g.moveTo(x-20,h);g.quadraticCurveTo(x-6+wb,h-hh*.55,x+wb,h-hh);g.quadraticCurveTo(x+6+wb,h-hh*.55,x+20,h);g.fill();}g.globalCompositeOperation='source-over';}
 else if(style==='rainbow'){const gr=g.createLinearGradient(0,0,w,h);for(let i=0;i<=6;i++)gr.addColorStop(i/6,'hsl('+((t*90+i*60)%360)+',85%,48%)');g.fillStyle=gr;g.fillRect(0,0,w,h);}
 else{const a=.55+.3*Math.sin(t*4),bg=g.createRadialGradient(w/2,h/2,5,w/2,h/2,170);bg.addColorStop(0,'rgba(255,225,120,'+a+')');bg.addColorStop(1,'#2b1d05');g.fillStyle=bg;g.fillRect(0,0,w,h);
  g.globalCompositeOperation='lighter';g.fillStyle='rgba(255,220,120,.16)';for(let i=0;i<12;i++){const an=t*.8+i*TAU/12;g.beginPath();g.moveTo(w/2,h/2);g.lineTo(w/2+Math.cos(an-.1)*300,h/2+Math.sin(an-.1)*300);g.lineTo(w/2+Math.cos(an+.1)*300,h/2+Math.sin(an+.1)*300);g.fill();}g.globalCompositeOperation='source-over';}
 g.strokeStyle='#ffd36b';g.lineWidth=8;g.strokeRect(4,4,w-8,h-8);g.shadowColor='rgba(255,200,60,.95)';g.shadowBlur=26;drawSymbol(g,sym,w,h);g.shadowBlur=0;}
function glowTex(){const c=document.createElement('canvas');c.width=c.height=256;const g=c.getContext('2d'),r=g.createRadialGradient(128,128,0,128,128,128);r.addColorStop(0,'rgba(255,255,255,1)');r.addColorStop(.4,'rgba(255,255,255,.35)');r.addColorStop(1,'rgba(255,255,255,0)');g.fillStyle=r;g.fillRect(0,0,256,256);return new THREE.CanvasTexture(c);}
function buildSlots(){const M=SL.machine;
 for(let i=M.children.length-1;i>=0;i--){const o=M.children[i];M.remove(o);o.traverse(x=>{if(x.material)[].concat(x.material).forEach(m=>{if(m.map&&m.map.dispose)m.map.dispose();m.dispose();});if(x.geometry)x.geometry.dispose();});}
 const c=cfg.slots,syms=c.symbols,n=syms.length;if(c.jackpotIndex>=n)c.jackpotIndex=0;SL.n=n;
 const TH=1.42,R=(TH+.05)/2/Math.tan(Math.PI/n),frame=goldMat(new THREE.Color(c.frameColor)),body=new THREE.MeshStandardMaterial({color:0x1a1030,metalness:.4,roughness:.55});
 const add=(g,m,x,y,z)=>{const o=new THREE.Mesh(g,m);o.position.set(x,y,z);M.add(o);return o;},bx=(w,h,d)=>new THREE.BoxGeometry(w,h,d);
 add(bx(7.4,5.6,.4),body,0,.1,-R-.5);
 add(bx(.6,4.9,1.5),frame,-3.2,.1,-.3);add(bx(.6,4.9,1.5),frame,3.2,.1,-.3);
 add(bx(7.0,1.5,1.5),frame,0,1.8,-.3);add(bx(7.0,1.3,1.5),frame,0,-1.7,-.3);
 SL.jc=document.createElement('canvas');SL.jc.width=256;SL.jc.height=228;SL.jg=SL.jc.getContext('2d');SL.jTex=canvasTex(SL.jc);drawJackTile(SL.jg,0,cfg.jackpotAura,syms[c.jackpotIndex].s);SL.jTex.needsUpdate=true;
 const mats=syms.map((s,i)=>{if(i===c.jackpotIndex)return new THREE.MeshBasicMaterial({map:SL.jTex});const cv=document.createElement('canvas');cv.width=256;cv.height=228;paintTile(cv.getContext('2d'),s.s);return new THREE.MeshBasicMaterial({map:canvasTex(cv)});});
 const plane=new THREE.PlaneGeometry(1.7,TH),core=new THREE.CylinderGeometry(R-.05,R-.05,1.7,28);core.rotateZ(Math.PI/2);const coreM=new THREE.MeshStandardMaterial({color:0x120c1c,roughness:.8});
 SL.reels=[];
 for(let r=0;r<3;r++){const g=new THREE.Group();g.position.set((r-1)*1.85,0,.12-R);g.add(new THREE.Mesh(core,coreM));
  for(let k=0;k<n;k++){const s=(k+r*2)%n,phi=TAU*k/n,m=new THREE.Mesh(plane,mats[s]);m.position.set(0,R*Math.sin(phi),R*Math.cos(phi));m.rotation.x=-phi;g.add(m);}
  g.rotation.x=TAU*ri(0,n-1)/n;M.add(g);SL.reels.push({g,spin:null,lk:0});}
 add(bx(.09,2.2,.5),frame,-.925,0,.15);add(bx(.09,2.2,.5),frame,.925,0,.15);
 SL.payline=add(new THREE.PlaneGeometry(5.7,.045),new THREE.MeshBasicMaterial({color:0xff3b3b,transparent:true,opacity:.75,blending:THREE.AdditiveBlending,depthWrite:false}),0,0,.36);
 const gc=document.createElement('canvas');gc.width=4;gc.height=64;const gg=gc.getContext('2d'),gr=gg.createLinearGradient(0,0,0,64);gr.addColorStop(0,'rgba(0,0,0,.9)');gr.addColorStop(1,'rgba(0,0,0,0)');gg.fillStyle=gr;gg.fillRect(0,0,4,64);const gt=new THREE.CanvasTexture(gc);
 const sm=new THREE.MeshBasicMaterial({map:gt,transparent:true,depthWrite:false});add(new THREE.PlaneGeometry(5.7,.75),sm,0,.68,.34);const sb=add(new THREE.PlaneGeometry(5.7,.75),sm,0,-.68,.34);sb.rotation.z=Math.PI;
 const mc=document.createElement('canvas');mc.width=1024;mc.height=190;const mg=mc.getContext('2d');mg.fillStyle='#120a22';mg.fillRect(0,0,1024,190);mg.strokeStyle='rgba(255,230,160,.8)';mg.lineWidth=6;mg.strokeRect(10,10,1004,170);
 mg.textAlign='center';mg.textBaseline='middle';mg.font='900 120px "Cinzel Decorative",Cinzel,Georgia,serif';const lg=mg.createLinearGradient(0,30,0,160);lg.addColorStop(0,'#fff2c0');lg.addColorStop(.5,'#e7b84b');lg.addColorStop(1,'#9a6a12');mg.fillStyle=lg;mg.fillText('LOYA SLOTS',512,98);
 add(new THREE.PlaneGeometry(5.8,1.08),new THREE.MeshBasicMaterial({map:canvasTex(mc)}),0,1.85,.46);
 SL.bulbs=[];const bg=new THREE.SphereGeometry(.085,12,8);
 for(const y of[1.2,-1.2])for(let i=0;i<12;i++){const m=new THREE.MeshBasicMaterial({color:c.bulbColor});add(bg,m,-2.6+i*.4727,y,.5);SL.bulbs.push(m);}
 SL.aura=new THREE.Sprite(new THREE.SpriteMaterial({map:glowTex(),color:0xffcf5a,transparent:true,opacity:0,blending:THREE.AdditiveBlending,depthWrite:false}));SL.aura.scale.set(13,11,1);SL.aura.position.set(0,0,-R-.9);M.add(SL.aura);}
SL.update=(T,dt)=>{const M=SL.machine;M.rotation.y=Math.sin(T*.6)*.05;M.rotation.x=Math.sin(T*.4)*.012;
 SL.reels.forEach((r,i)=>{const s=r.spin;if(!s)return;s.t+=dt;if(s.t<0)return;const p=clamp(s.t/s.dur,0,1);r.g.rotation.x=s.a0+(s.a1-s.a0)*E.back(p);
  if(i===1){const k=Math.floor(r.g.rotation.x/(TAU/SL.n));if(k!==r.lk){r.lk=k;sfx.tick();}}
  if(p>=1){r.g.rotation.x=s.a1%TAU;r.spin=null;}});
 if(SL.pending&&!SL.reels.some(r=>r.spin)){const f=SL.pending;SL.pending=null;f();}
 SL.jt+=dt;if(SL.jt>.055&&cfg.jackpotAura!=='none'&&SL.jTex){SL.jt=0;drawJackTile(SL.jg,T,cfg.jackpotAura,cfg.slots.symbols[cfg.slots.jackpotIndex].s);SL.jTex.needsUpdate=true;}
 const fast=SL.busy||SL.flash>0;if(SL.flash>0)SL.flash-=dt;
 SL.bulbs.forEach((m,i)=>{if(SL.flash>0)m.color.setHSL((T*.9+i/24)%1,1,.6);else{const on=(Math.floor(T*(fast?9:2.5))+i)%3===0;m.color.set(cfg.slots.bulbColor).multiplyScalar(on?1:.25);}});
 SL.payline.material.opacity=.55+.3*Math.sin(T*6);
 const a=SL.aura.material;if(SL.auraT>0){SL.auraT-=dt;a.opacity=Math.min(1,SL.auraT)*(.55+.25*Math.sin(T*9));const st=cfg.jackpotAura;if(st==='rainbow')a.color.setHSL((T*.6)%1,1,.55);else if(st==='fire')a.color.setHSL(.05+.03*Math.sin(T*12),1,.5);else a.color.set(0xffcf5a);}else a.opacity=0;};
function slotsSpin(){if(SL.busy)return;const c=cfg.slots,stake=c.bet*S.slotMult;if(S.coins<stake){toast('No tienes monedas suficientes');return;}
 addCoins(-stake);SL.busy=true;const btn=$('#slSpin');if(btn)btn.disabled=true;
 const syms=c.symbols,n=syms.length,J=clamp(c.jackpotIndex,0,n-1);let res,win=0,jack=false;
 if(Math.random()*100<c.jackpotChance){res=[J,J,J];win=c.jackpotPrize;jack=true;}
 else if(Math.random()*100<c.winChance){const pool=[];for(let i=0;i<n;i++)if(i!==J)pool.push(i);const k=pool[ri(0,pool.length-1)];res=[k,k,k];win=Math.round(stake*syms[k].m);}
 else{do{res=[ri(0,n-1),ri(0,n-1),ri(0,n-1)];}while(res[0]===res[1]&&res[1]===res[2]);}
 win=Math.round(win*winM());
 SL.reels.forEach((r,i)=>{const k=mod(res[i]-2*i,n),phi=TAU*k/n,a0=mod(r.g.rotation.x,TAU),delta=mod(phi-a0,TAU)+TAU*(4+i*2);r.g.rotation.x=a0;r.spin={t:-i*.12,dur:(cfg.slots.spinTime||2)+i*.55,a0,a1:a0+delta};});
 SL.pending=()=>{SL.busy=false;const b=$('#slSpin');if(b)b.disabled=false;
  if(win>0){addCoins(win);S.slLast=win;const l=$('#slLast');if(l)l.textContent=fmt(win);SL.flash=jack?4.5:2.5;if(jack)SL.auraT=6;celebrate(jack);setTimeout(()=>showWin(win,{jackpot:jack}),jack?700:450);}else sfx.lose();
  if(SL.dirty){SL.dirty=false;buildSlots();}};}

/* ================= RULETA ================= */
const RO=mkScene({fov:42,dir:[0,1.05,.95],fitW:10.8,fitH:9.2,shift:.1});
addLights(RO.scene);
const GN={red:'Rojo',black:'Negro',green:'Verde',gold:'Dorado',house:'Casa'},GC={red:'#c4162d',black:'#1c1c24',green:'#10a35e',gold:'#e0a921',house:'#4a4660'};
Object.assign(RO,{alpha:0,rest:-1,spin:null});
(function(){const sc=RO.scene,wood=new THREE.MeshStandardMaterial({color:0x4a2d12,metalness:.35,roughness:.5});
 const bowl=new THREE.Mesh(new THREE.CylinderGeometry(5.2,5.5,.7,72),wood);bowl.position.y=-.25;sc.add(bowl);
 const track=new THREE.Mesh(new THREE.TorusGeometry(4.6,.2,14,72),goldMat(0xd9a940));track.rotation.x=Math.PI/2;track.position.y=.12;sc.add(track);
 RO.wheel=new THREE.Group();sc.add(RO.wheel);
 const disc=new THREE.Mesh(new THREE.CylinderGeometry(4.25,4.25,.2,96),goldMat(0xb98720));RO.wheel.add(disc);
 const fg2=new THREE.CircleGeometry(4.25,96);fg2.rotateX(-Math.PI/2);RO.faceMat=new THREE.MeshStandardMaterial({roughness:.5,metalness:.15,emissive:0xffffff,emissiveIntensity:.3});
 const face=new THREE.Mesh(fg2,RO.faceMat);face.position.y=.101;RO.wheel.add(face);
 const gold=goldMat(0xe2b449),hub=new THREE.Mesh(new THREE.CylinderGeometry(.55,.85,.5,32),gold);hub.position.y=.35;RO.wheel.add(hub);
 const cone=new THREE.Mesh(new THREE.ConeGeometry(.35,.8,24),gold);cone.position.y=.95;RO.wheel.add(cone);const bl=new THREE.Mesh(new THREE.SphereGeometry(.17,16,12),gold);bl.position.y=1.42;RO.wheel.add(bl);
 for(let i=0;i<4;i++){const rod=new THREE.Mesh(new THREE.CylinderGeometry(.06,.06,2.2,10),gold);rod.rotation.z=Math.PI/2;rod.rotation.y=i*Math.PI/4;rod.position.y=.5;RO.wheel.add(rod);}
 const ptr=new THREE.Mesh(new THREE.ConeGeometry(.24,.7,3),new THREE.MeshStandardMaterial({color:0xd3283c,metalness:.5,roughness:.3,emissive:0x550010}));ptr.position.set(0,.75,-4.85);ptr.rotation.x=Math.PI/2;sc.add(ptr);
 RO.ball=new THREE.Mesh(new THREE.SphereGeometry(.17,20,14),new THREE.MeshStandardMaterial({color:0xffffff,metalness:.8,roughness:.15}));sc.add(RO.ball);})();
function buildWheelTex(){const c=document.createElement('canvas');c.width=c.height=1024;const g=c.getContext('2d'),segs=cfg.roulette.segments,n=segs.length;
 g.translate(512,512);g.scale(1,-1);g.fillStyle='#2b1c0a';g.beginPath();g.arc(0,0,512,0,TAU);g.fill();const r1=372,r2=500;
 segs.forEach((s,i)=>{const a0=i*TAU/n,a1=(i+1)*TAU/n;g.beginPath();g.moveTo(Math.cos(a0)*r1,Math.sin(a0)*r1);g.arc(0,0,r2,a0,a1);g.arc(0,0,r1,a1,a0,true);g.closePath();g.fillStyle=s.c;g.fill();g.lineWidth=4;g.strokeStyle='#e7b84b';g.stroke();});
 segs.forEach((s,i)=>{const am=(i+.5)*TAU/n,col=new THREE.Color(s.c),lum=.3*col.r+.59*col.g+.11*col.b;g.save();g.rotate(am);g.translate(r2-22,0);g.scale(1,-1);g.textAlign='right';g.textBaseline='middle';g.font='800 '+(n>20?44:62)+'px Cinzel,Georgia,serif';g.lineWidth=5;g.strokeStyle=lum>.5?'rgba(255,255,255,.5)':'rgba(0,0,0,.6)';g.strokeText(s.l,0,0);g.fillStyle=lum>.5?'#1a1006':'#fff3cf';g.fillText(s.l,0,0);g.restore();});
 const rg=g.createRadialGradient(0,0,0,0,0,r1);rg.addColorStop(0,'#3a2a12');rg.addColorStop(.6,'#1a1208');rg.addColorStop(1,'#0c0804');g.fillStyle=rg;g.beginPath();g.arc(0,0,r1-4,0,TAU);g.fill();
 g.fillStyle='rgba(231,184,75,.22)';for(let i=0;i<24;i++){const a=i*TAU/24;g.beginPath();g.moveTo(0,0);g.lineTo(Math.cos(a-.07)*(r1-8),Math.sin(a-.07)*(r1-8));g.lineTo(Math.cos(a+.07)*(r1-8),Math.sin(a+.07)*(r1-8));g.fill();}
 g.strokeStyle='#e7b84b';[340,300,150].forEach((r,i)=>{g.lineWidth=i?3:6;g.beginPath();g.arc(0,0,r,0,TAU);g.stroke();});g.lineWidth=10;g.beginPath();g.arc(0,0,505,0,TAU);g.stroke();
 const old=RO.faceMat.map;const t=canvasTex(c);RO.faceMat.map=t;RO.faceMat.emissiveMap=t;RO.faceMat.needsUpdate=true;if(old)old.dispose();}
function placeBall(psi,r,y){RO.ball.position.set(r*Math.cos(psi),y,-r*Math.sin(psi));}
RO.update=(T,dt)=>{const n=cfg.roulette.segments.length;
 if(RO.spin){const s=RO.spin;s.t+=dt;const p=clamp(s.t/s.dur,0,1);RO.alpha=s.a0+s.delta*E.out4(p);const rel=s.K*(1-E.out(p)),psi=s.phi+RO.alpha+rel;
  const q=clamp((p-.55)/.3,0,1),dq=q*q*(3-2*q),r=4.35-.73*dq,y=.34-.1*dq+((p>.6&&p<.97)?Math.abs(Math.sin(p*60))*.2*(1-p)*(1-dq*.4):0);placeBall(psi,r,y);
  if(p<.92&&Math.floor(s.t*16)!==s.lt){s.lt=Math.floor(s.t*16);sfx.tick();}
  if(p>=1)rouDone();}
 else{RO.alpha+=dt*.12;if(RO.rest>=0&&RO.rest<n)placeBall((RO.rest+.5)*TAU/n+RO.alpha,3.62,.27);else placeBall(-T*.9,4.35,.34);}
 RO.wheel.rotation.y=RO.alpha;};
function rouProb(grp,tier){const segs=cfg.roulette.segments,tot=segs.reduce((a,s)=>a+Math.max(0,s.w),0),g=segs.filter(s=>s.g===grp).reduce((a,s)=>a+Math.max(0,s.w),0);if(!tot||!g)return 0;const b=clamp(tier.boost,0,100)/100,nat=g/tot*clamp((cfg.roulette.luck==null?100:cfg.roulette.luck)/100,0,1);return b+(1-b)*nat;}
function rouSpin(){if(RO.spin)return;const c=cfg.roulette,tier=c.tiers[S.rTier]||c.tiers[0],stake=c.bet*tier.cost;if(S.coins<stake){toast('No tienes monedas suficientes');return;}
 addCoins(-stake);const b=$('#ruSpin');if(b)b.disabled=true;
 const segs=c.segments,n=segs.length,grp=S.rGroup,all=segs.map((_,i)=>i),ing=all.filter(i=>segs[i].g===grp);
 const pick=arr=>{let tot=0;arr.forEach(i=>tot+=Math.max(0,segs[i].w));if(tot<=0)return arr[ri(0,arr.length-1)];let r=Math.random()*tot;for(const i of arr){r-=Math.max(0,segs[i].w);if(r<=0)return i;}return arr[arr.length-1];};
 const out=all.filter(i=>segs[i].g!==grp),idx=(ing.length&&Math.random()<rouProb(grp,tier))?pick(ing):pick(out.length?out:all);
 const phi=(idx+.5)*TAU/n,a0=RO.alpha,delta=mod(Math.PI/2-phi-a0,TAU)+TAU*ri(5,7);
 RO.spin={t:0,dur:cfg.roulette.spinTime||6.2,a0,delta,phi,K:TAU*(12+ri(0,3)),lt:-1,seg:segs[idx],stake,grp,pay:c.pay[grp]||0};RO.rest=idx;$('#gHud').textContent='¡La rueda gira!';}
function rouDone(){const s=RO.spin;RO.spin=null;const seg=s.seg,win=seg.g===s.grp?Math.round(s.stake*s.pay*winM()):0;const b=$('#ruSpin');if(b)b.disabled=false;
 $('#gHud').textContent='Cayó '+seg.l+' · '+(GN[seg.g]||seg.g);
 if(win>0){addCoins(win);const jk=seg.g==='gold';celebrate(jk);setTimeout(()=>showWin(win,{jackpot:jk}),jk?600:350);}else sfx.lose();}

/* ================= CARTAS ================= */
const CA=mkScene({fov:42,dir:[0,1.55,1],fitW:6.4,fitH:10.6,shift:.09,target:[0,0,.2]});
addLights(CA.scene);
const spot=new THREE.SpotLight(0xffe2a8,1.5,60,.8,.5);spot.position.set(0,13,4);CA.scene.add(spot);
const CW=1.5,CH=2.1,CT=.035,cardGeo=new THREE.BoxGeometry(CW,CT,CH),texCache=new Map();let backT=null;CA.live=new Set();
function drawArt(g,W,H,v,ink){const cx=W/2+8,cy=H*.36,dark='#0c0805';g.lineCap='round';g.lineJoin='round';const n=7+(v%6);
 for(let i=0;i<n;i++){const a=i/n*TAU+v*.4,L=95+((i*37+v*11)%5)*16,ex=cx+Math.cos(a)*L*1.05,ey=cy+Math.sin(a)*L*.95,mx=cx+Math.cos(a+.7)*L*.75,my=cy+Math.sin(a+.7)*L*.75;
  g.beginPath();g.moveTo(cx,cy);g.quadraticCurveTo(mx,my,ex,ey);g.strokeStyle=dark;g.lineWidth=17;g.stroke();g.strokeStyle=ink;g.lineWidth=11;g.stroke();g.strokeStyle='rgba(12,8,5,.5)';g.lineWidth=2;g.setLineDash([2,7]);g.stroke();g.setLineDash([]);}
 g.fillStyle='#17100a';g.beginPath();g.moveTo(cx-95,H*.52);g.quadraticCurveTo(cx-60,cy+40,cx-10,cy+52);g.lineTo(cx+40,cy+55);g.quadraticCurveTo(cx+100,H*.58,cx+78,H*.84);g.lineTo(cx-98,H*.86);g.closePath();g.fill();
 g.save();g.clip();g.strokeStyle='rgba(217,192,138,.35)';g.lineWidth=2;for(let x=-120;x<420;x+=9){g.beginPath();g.moveTo(cx-100+x*.2,H*.45);g.lineTo(cx-100+x*.2+60,H*.9);g.stroke();}g.restore();
 g.strokeStyle=ink;g.lineWidth=3;g.stroke();
 g.fillStyle=dark;g.beginPath();g.arc(cx,cy,54,0,TAU);g.fill();g.fillStyle=ink;g.beginPath();g.arc(cx,cy,47,0,TAU);g.fill();g.fillStyle=dark;
 g.beginPath();g.ellipse(cx-18,cy-6,12,16,-.3,0,TAU);g.fill();g.beginPath();g.ellipse(cx+18,cy-6,12,16,.3,0,TAU);g.fill();
 g.beginPath();g.moveTo(cx,cy+6);g.lineTo(cx-6,cy+22);g.lineTo(cx+6,cy+22);g.closePath();g.fill();g.lineWidth=3;g.strokeStyle=dark;for(let i=-2;i<=2;i++){g.beginPath();g.moveTo(cx+i*8,cy+30);g.lineTo(cx+i*8,cy+42);g.stroke();}
 const mx=cx+70,my=H*.74;g.fillStyle=dark;g.beginPath();g.arc(mx,my,40,0,TAU);g.fill();g.fillStyle=ink;g.beginPath();g.arc(mx,my,34,0,TAU);g.fill();g.fillStyle=dark;
 g.beginPath();g.ellipse(mx-11,my-6,7,5,.3,0,TAU);g.fill();g.beginPath();g.ellipse(mx+11,my-6,7,5,-.3,0,TAU);g.fill();g.beginPath();g.arc(mx,my+16,10,Math.PI*1.1,Math.PI*1.9);g.lineWidth=4;g.strokeStyle=dark;g.stroke();
 g.strokeStyle=dark;g.lineWidth=10;g.beginPath();g.moveTo(cx-110,H*.92);g.lineTo(cx-72,H*.5);g.stroke();g.strokeStyle=ink;g.lineWidth=5;g.stroke();}
function drawCardFace(v,s){const W=360,H=540,c=document.createElement('canvas');c.width=W;c.height=H;const g=c.getContext('2d'),cc=cfg.cards;
 rrect(g,0,0,W,H,30);g.fillStyle=cc.frame;g.fill();g.save();rrect(g,0,0,W,H,30);g.clip();speckle(g,W,H,3500,'rgba(0,0,0,.10)',2);speckle(g,W,H,2500,'rgba(255,255,255,.12)',2);g.restore();
 const px=32,py=32,pw=W-64,ph=H-64;rrect(g,px,py,pw,ph,34);g.fillStyle=cc.panel;g.fill();g.save();rrect(g,px,py,pw,ph,34);g.clip();
 g.fillStyle=['rgba(0,0,0,0)','rgba(90,60,210,.30)','rgba(210,40,55,.26)','rgba(30,175,150,.24)'][s];g.fillRect(px,py,pw,ph);
 g.fillStyle='rgba(0,0,0,.26)';for(let i=0;i<4;i++)for(let j=0;j<6;j++){const x=px+(i+.5)*pw/4,y=py+(j+(i%2?1:.5))*ph/6;g.beginPath();g.moveTo(x,y-48);g.lineTo(x+36,y);g.lineTo(x,y+48);g.lineTo(x-36,y);g.closePath();g.fill();}
 drawArt(g,W,H,v,cc.ink);speckle(g,W,H,5000,'rgba(0,0,0,.28)',1.6);speckle(g,W,H,2200,'rgba(255,240,200,.12)',1.4);g.restore();
 rrect(g,px,py,pw,ph,34);g.lineWidth=5;g.strokeStyle='#120a04';g.stroke();
 const corner=()=>{rrect(g,6,118,40,64,9);g.fillStyle='#0c0805';g.fill();g.fillStyle=cc.frame;g.font=(v>9?'800 22px':'800 30px')+' Cinzel,Georgia,serif';g.textAlign='center';g.textBaseline='middle';g.fillText(String(v),26,151);starBurst(g,26,208,13,6+s*2,'#0c0805');};
 corner();g.save();g.translate(W,H);g.rotate(Math.PI);corner();g.restore();return c;}
function drawCardBack(){const W=360,H=540,c=document.createElement('canvas');c.width=W;c.height=H;const g=c.getContext('2d'),cc=cfg.cards,rand=mulberry(7);
 rrect(g,0,0,W,H,30);g.fillStyle=cc.backBase;g.fill();g.save();rrect(g,0,0,W,H,30);g.clip();g.fillStyle=cc.backAccent;
 for(let i=0;i<7;i++)for(let j=0;j<10;j++){const x=(i+.5+(j%2?.5:0))*W/7+(rand()-.5)*20,y=(j+.5)*H/10+(rand()-.5)*20,r=14+rand()*16,a=rand()*TAU;g.save();g.translate(x,y);g.rotate(a);g.globalAlpha=.55+rand()*.4;g.beginPath();g.arc(0,0,r,0,Math.PI*1.25);g.arc(r*.35,-r*.1,r*.8,Math.PI*1.25,0,true);g.closePath();g.fill();g.restore();}
 g.globalAlpha=1;speckle(g,W,H,4000,'rgba(0,0,0,.3)',1.6);g.restore();rrect(g,10,10,W-20,H-20,24);g.lineWidth=3;g.strokeStyle=cc.backAccent;g.globalAlpha=.6;g.stroke();g.globalAlpha=1;return c;}
function backTex(){if(!backT)backT=canvasTex(drawCardBack());return backT;}
function faceTex(v,s){const k=v+'-'+s;let t=texCache.get(k);if(!t){t=canvasTex(drawCardFace(v,s));texCache.set(k,t);}return t;}
function resetCardTex(){const oldB=backT;backT=null;const oldC=Array.from(texCache.values());texCache.clear();
 CA.live.forEach(c=>{setFace(c,c.v,c.s);c.mats[3].map=c.mats[3].emissiveMap=backTex();c.mats[3].needsUpdate=true;});
 AMB.cards.forEach(m=>{m.material.map=backTex();m.material.needsUpdate=true;});oldC.forEach(t=>t.dispose());if(oldB)oldB.dispose();}
function setFace(c,v,s){c.v=v;c.s=s;const t=faceTex(v,s);c.mats[2].map=c.mats[2].emissiveMap=t;c.mats[2].needsUpdate=true;}
function newCard(v,s,faceUp){const pivot=new THREE.Group(),side=new THREE.MeshStandardMaterial({color:new THREE.Color(cfg.cards.frame).multiplyScalar(.6),roughness:.6});
 const mk=map=>new THREE.MeshStandardMaterial({map,emissiveMap:map,emissive:0xffffff,emissiveIntensity:.3,roughness:.55,metalness:.1,alphaTest:.5});
 const mats=[side,side,mk(faceTex(v,s)),mk(backTex()),side,side],mesh=new THREE.Mesh(cardGeo,mats);pivot.add(mesh);pivot.rotation.z=faceUp?0:Math.PI;CA.scene.add(pivot);
 const c={pivot,mesh,mats,v,s};mesh.userData.card=c;CA.live.add(c);return c;}
function killCard(c){CA.live.delete(c);CA.scene.remove(c.pivot);c.mats.forEach(m=>m.dispose());}
function buildFelt(){const W=1024,H=1144,k=W/10.2,c=document.createElement('canvas');c.width=W;c.height=H;const g=c.getContext('2d');g.fillStyle=cfg.cards.felt;g.fillRect(0,0,W,H);
 const vg=g.createRadialGradient(W/2,H/2,60,W/2,H/2,H*.7);vg.addColorStop(0,'rgba(255,255,255,.07)');vg.addColorStop(1,'rgba(0,0,0,.55)');g.fillStyle=vg;g.fillRect(0,0,W,H);
 g.strokeStyle='rgba(231,184,75,.55)';g.lineWidth=6;rrect(g,30,30,W-60,H-60,40);g.stroke();g.lineWidth=2;rrect(g,48,48,W-96,H-96,30);g.stroke();
 g.save();g.translate(W/2,H/2);g.strokeStyle='rgba(231,184,75,.2)';g.lineWidth=3;for(let i=0;i<16;i++){g.rotate(TAU/16);g.beginPath();g.moveTo(40,0);g.lineTo(i%2?150:210,0);g.stroke();}g.beginPath();g.arc(0,0,30,0,TAU);g.stroke();g.restore();
 const two=S.cardMode==='two';[[-1.35,two?'JUGADOR 2':'BOT'],[1.35,two?'JUGADOR 1':'TÚ']].forEach(([z,l])=>{const x=W/2,y=(z+5.7)*k,w=1.75*k,h=2.4*k;g.setLineDash([14,10]);g.strokeStyle='rgba(231,184,75,.5)';g.lineWidth=4;rrect(g,x-w/2,y-h/2,w,h,22);g.stroke();g.setLineDash([]);g.fillStyle='rgba(231,184,75,.28)';g.font='800 34px Cinzel,Georgia,serif';g.textAlign='center';g.textBaseline='middle';g.fillText(l,x,y);});
 const edge=goldMat(0x8a5f14),top=new THREE.MeshStandardMaterial({map:canvasTex(c),roughness:.9,metalness:0,emissive:0xffffff,emissiveIntensity:.12});top.emissiveMap=top.map;
 if(CA.table){CA.scene.remove(CA.table);if(CA.table.material[2].map)CA.table.material[2].map.dispose();}
 CA.table=new THREE.Mesh(new THREE.BoxGeometry(10.2,.4,11.4),[edge,edge,top,edge,edge,edge]);CA.table.position.y=-.2;CA.scene.add(CA.table);}
const G={mode:'bot',phase:'idle',hand:[],bot:[],d1:[],d2:[],turn:1,wins:0,losses:0,p2coins:0,gen:0,drag:null,antes:{1:0,2:0},msg:''};
const CANCEL={},DECK={x:4.4,y:.3,z:0},rv=()=>ri(1,13),rs=()=>ri(0,3);
const ga=async(gen,p)=>{await p;if(G.gen!==gen)throw CANCEL;};
function moveTo(c,t,dur=.5,arc=0,ease=E.io,delay=0){const p=c.pivot,a={x:p.position.x,y:p.position.y,z:p.position.z,rx:p.rotation.x,ry:p.rotation.y,rz:p.rotation.z};
 const b={x:t.x??a.x,y:t.y??a.y,z:t.z??a.z,rx:t.rx??a.rx,ry:t.ry??a.ry,rz:t.rz??a.rz};
 return tw(dur,e=>{p.position.set(a.x+(b.x-a.x)*e,a.y+(b.y-a.y)*e+Math.sin(Math.PI*e)*arc,a.z+(b.z-a.z)*e);p.rotation.set(a.rx+(b.rx-a.rx)*e,a.ry+(b.ry-a.ry)*e,a.rz+(b.rz-a.rz)*e);},ease,delay);}
function handPose(i,n,top){const t=i-(n-1)/2,sp=n>4?.98:1.1;return top?{x:-t*sp,y:.55+i*.02,z:-3.9-Math.abs(t)*.14,rx:.5,ry:t*.1,rz:Math.PI}:{x:t*sp,y:.55+i*.02,z:3.9+Math.abs(t)*.14,rx:.5,ry:-t*.1,rz:0};}
function layout(arr,top,delay=0){arr.forEach((c,i)=>{const p=handPose(i,arr.length,top);moveTo(c,p,.38,.15,E.io,delay?i*delay:0);});}
function deal(c,pose,delay){c.pivot.position.set(DECK.x,DECK.y+.4,DECK.z);c.pivot.rotation.set(0,0,Math.PI);return moveTo(c,pose,.55,.9,E.io,delay);}
function cHud(m){if(m!==undefined)G.msg=m;const two=G.mode==='two',el=$('#cardMsg');if(!el)return;const sc=two?'J1 '+G.wins+' · J2 '+G.losses:'Victorias '+G.wins+' · Derrotas '+G.losses;let t=G.msg;if(!t)t=two?'Arrastra una carta al centro':'Apuesta '+fmt(curBet())+' · si ganas recibes '+fmt(Math.round(curBet()*cfg.cards.payout*winM()));el.innerHTML='<b>'+esc(t)+'</b><small>'+sc+'</small>';}
function clearCards(){G.gen++;if(G.antes[1]>0&&G.mode==='bot'||G.antes[1]>0)addCoins(G.antes[1]);G.antes={1:0,2:0};CA.live.forEach(c=>{CA.scene.remove(c.pivot);c.mats.forEach(m=>m.dispose());});CA.live.clear();G.hand=[];G.bot=[];G.drag=null;if(passRes){const r=passRes;passRes=null;$('#pass').classList.add('hidden');r();}}
async function startCards(){clearCards();const gen=G.gen;G.mode=S.cardMode;G.phase='deal';G.wins=G.losses=0;G.streak=0;G.forceLoss=0;buildFelt();cHud('Repartiendo…');
 try{const n=5;
  for(let i=0;i<n;i++){const b=newCard(rv(),rs(),false);G.bot.push(b);deal(b,handPose(i,n,true),i*.09);}
  if(G.mode==='bot'){for(let i=0;i<n;i++){const c=newCard(rv(),rs(),false);G.hand.push(c);deal(c,Object.assign(handPose(i,n,false)),.45+i*.09);}
   await ga(gen,sleep(1100));G.phase='pick';cHud('Arrastra una carta al centro');}
  else{G.d1=Array.from({length:n},()=>({v:rv(),s:rs()}));G.d2=Array.from({length:n},()=>({v:rv(),s:rs()}));G.p2coins=cfg.startCoins;await ga(gen,sleep(900));await twoTurn(1,gen);}
 }catch(e){if(e!==CANCEL)throw e;}}
let passRes=null;
function passScreen(p){$('#passT').textContent='Turno del jugador '+p;$('#passS').textContent=p===1?'Jugador 2: aparta la vista. El jugador 1 verá sus cartas al continuar.':'Jugador 1: pasa el dispositivo. El jugador 2 verá sus cartas al continuar.';$('#pass').classList.remove('hidden');return new Promise(r=>{passRes=r;});}
$('#passBtn').onclick=()=>{$('#pass').classList.add('hidden');const r=passRes;passRes=null;if(r)r();};
async function twoTurn(p,gen){G.turn=p;G.phase='wait';cHud('');await ga(gen,passScreen(p));
 const d=p===1?G.d1:G.d2;G.hand=d.map((x,i)=>{const c=newCard(x.v,x.s,false);c.data=x;deal(c,handPose(i,d.length,false),i*.08);return c;});
 await ga(gen,sleep(750));G.phase='pick';cHud('Jugador '+p+': arrastra una carta');}
async function placeCard(gen,c,top){await ga(gen,moveTo(c,{x:0,y:.09,z:top?-1.35:1.35,rx:0,ry:top?Math.PI:0,rz:0},.45,1.1));sfx.card();await ga(gen,moveTo(c,{rz:Math.PI},.38,.7));}
function hl(c,win){const m=c.mats[2];if(win){m.emissive.set(0xffd36b);m.emissiveIntensity=.8;const L=new THREE.PointLight(0xffd36b,2.4,6);L.position.set(c.pivot.position.x,2,c.pivot.position.z);CA.scene.add(L);c.light=L;tw(.4,e=>c.pivot.scale.setScalar(1+.12*e),E.out);}else{m.color.set(0x666666);m.emissiveIntensity=.03;}}
async function reveal(gen,a,b){setFace(a,a.v,a.s);setFace(b,b.v,b.s);await ga(gen,Promise.all([moveTo(a,{y:.09,rz:0},.8,1.6),moveTo(b,{y:.09,rz:0},.8,1.6,E.io,.12)]));sfx.card();}
async function finishRound(gen,a,b,res,who){await ga(gen,sleep(250));
 if(res!==0){hl(res>0?a:b,true);hl(res>0?b:a,false);}
 await ga(gen,sleep(1500));
 [a,b].forEach(c=>{if(c.light){CA.scene.remove(c.light);c.light=null;}});
 await ga(gen,Promise.all([a,b].map(c=>tw(.4,e=>{c.pivot.scale.setScalar(1-e*.95);c.pivot.position.y=.09+e*1.4;},E.io))));killCard(a);killCard(b);}
async function roundBot(card){const gen=G.gen,bet=curBet();G.phase='busy';cHud('');
 if(S.coins<bet){toast('No tienes monedas para esa apuesta');G.phase='pick';layout(G.hand,false);return;}
 try{addCoins(-bet);G.antes[1]=bet;G.hand.splice(G.hand.indexOf(card),1);layout(G.hand,false);
  await placeCard(gen,card,false);
  const v=card.v,forced=G.forceLoss>0;if(forced)G.forceLoss--;
  let bi=ri(0,G.bot.length-1);if(forced){const cand=[];G.bot.forEach((x,i)=>{if(x.v>v)cand.push(i);});if(cand.length)bi=cand[ri(0,cand.length-1)];}
  const bc=G.bot.splice(bi,1)[0];layout(G.bot,true);
  if(forced){if(bc.v<=v)bc.v=v<13?ri(v+1,13):v;}
  else if(cfg.cards.randomBot===false){const pw=v===1?0:Math.min(100,cfg.cards.playerWinChance*13/12);let bv;if(Math.random()*100<pw)bv=ri(1,v-1);else bv=v<13?ri(v+1,13):v;bc.v=bv;}
  await ga(gen,moveTo(bc,{x:0,y:.09,z:-1.35,rx:0,ry:0,rz:Math.PI},.55,1.1));sfx.card();await ga(gen,sleep(250));
  await reveal(gen,card,bc);const res=Math.sign(card.v-bc.v);
  if(res>0){const pay=Math.round(bet*cfg.cards.payout*winM());G.wins++;G.streak=(G.streak||0)+1;let msg='¡Ganaste!';if(G.streak>=(cfg.cards.streakWins||3)){G.forceLoss=cfg.cards.streakLoss==null?2:cfg.cards.streakLoss;G.streak=0;if(G.forceLoss>0)msg='¡Ganaste! Racha completa: las próximas '+G.forceLoss+' jugadas serán de mala suerte';}addCoins(pay);G.antes[1]=0;cHud(msg);celebrate(false);setTimeout(()=>showWin(pay,{compact:true}),500);}
  else if(res<0){G.losses++;G.streak=0;G.antes[1]=0;cHud('Perdiste esta mano');sfx.lose();}
  else{addCoins(bet);G.antes[1]=0;cHud('Empate: apuesta devuelta');}
  await finishRound(gen,card,bc,res);
  const nc=newCard(rv(),rs(),false);G.hand.push(nc);deal(nc,handPose(G.hand.length-1,G.hand.length,false));layout(G.hand,false);
  const nb=newCard(rv(),rs(),false);G.bot.push(nb);deal(nb,handPose(G.bot.length-1,G.bot.length,true));layout(G.bot,true);
  await ga(gen,sleep(650));G.phase='pick';cHud('Arrastra una carta al centro');
 }catch(e){if(e!==CANCEL)throw e;}}
async function clearHand(gen){const h=G.hand;G.hand=[];await ga(gen,Promise.all(h.map(c=>tw(.25,e=>c.pivot.scale.setScalar(1-e),E.io))));h.forEach(killCard);}
async function roundTwo(card){const gen=G.gen,bet=cfg.cards.bet,p=G.turn,top=p===2;G.phase='busy';cHud('');
 try{
  const i=G.hand.indexOf(card);G.hand.splice(i,1);const d=p===1?G.d1:G.d2;d[d.indexOf(card.data)]={v:rv(),s:rs()};
  layout(G.hand,false);G.played=G.played||{};G.played[p]=card;
  await placeCard(gen,card,top);
  if(p===1){await clearHand(gen);await twoTurn(2,gen);return;}
  await clearHand(gen);const a=G.played[1],b=G.played[2];G.played={};await ga(gen,sleep(200));await reveal(gen,a,b);
  const res=Math.sign(a.v-b.v);
  if(res>0){G.wins++;cHud('¡Gana el jugador 1!');celebrate(false);toast('¡Punto para el jugador 1!');}
  else if(res<0){G.losses++;cHud('¡Gana el jugador 2!');celebrate(false);toast('¡Punto para el jugador 2!');}
  else{cHud('Empate');}
  G.antes={1:0,2:0};await finishRound(gen,a,b,res);await twoTurn(1,gen);
 }catch(e){if(e!==CANCEL)throw e;}}
const dragPlane=new THREE.Plane(new THREE.Vector3(0,1,0),-1.15),tmpV=new THREE.Vector3();
function dragPt(e){pNdc(e);ray.setFromCamera(ndc,CA.camera);return ray.ray.intersectPlane(dragPlane,tmpV);}
$('#gl').addEventListener('pointerdown',e=>{
 if(S.screen==='home'){pNdc(e);ray.setFromCamera(ndc,AMB.camera);if(ray.intersectObject(EMB,true).length)openLogin();return;}
 if(S.screen!=='game'||S.game!=='cards'||G.phase!=='pick')return;
 pNdc(e);ray.setFromCamera(ndc,CA.camera);const hits=ray.intersectObjects(G.hand.map(c=>c.mesh),false);if(!hits.length)return;
 const card=hits[0].object.userData.card;
 if(G.mode==='bot'&&S.coins<curBet()){toast('No tienes monedas para esa apuesta');return;}
 G.drag={card,id:e.pointerId,sx:e.clientX,sy:e.clientY,tx:card.pivot.position.x,tz:card.pivot.position.z,moved:0};
 try{$('#gl').setPointerCapture(e.pointerId);}catch(_){}sfx.card();});
$('#gl').addEventListener('pointermove',e=>{const d=G.drag;if(!d||e.pointerId!==d.id)return;d.moved=Math.max(d.moved,Math.hypot(e.clientX-d.sx,e.clientY-d.sy));const pt=dragPt(e);if(pt){d.tx=clamp(pt.x,-4.5,4.5);d.tz=clamp(pt.z-1,-1,5);}});
function endDrag(e){const d=G.drag;if(!d||e.pointerId!==d.id)return;G.drag=null;const c=d.card;
 if(d.tz<2.4||d.moved<8){G.mode==='two'?roundTwo(c):roundBot(c);}else{layout(G.hand,false);}}
$('#gl').addEventListener('pointerup',endDrag);$('#gl').addEventListener('pointercancel',e=>{const d=G.drag;if(!d)return;G.drag=null;layout(G.hand,false);});
CA.update=(T,dt)=>{const d=G.drag;if(!d)return;const p=d.card.pivot,k=1-Math.exp(-dt*16);const dx=d.tx-p.position.x;
 p.position.x+=dx*k;p.position.z+=(d.tz-p.position.z)*k;p.position.y+=(1.15-p.position.y)*k;
 p.rotation.z+=(clamp(-dx*.35,-.5,.5)-p.rotation.z)*k;p.rotation.x+=(.3-p.rotation.x)*k;p.rotation.y+=(clamp(dx*.25,-.4,.4)-p.rotation.y)*k;};
function setCardsMode(m){if(S.cardMode===m)return;S.cardMode=m;panelCards();startCards();}

/* ================= lluvia de oro y cartas (inicio y lobby) ================= */
const bgc=$('#bgfx'),bgx=bgc.getContext('2d');let BW=0,BH=0,bgT=0,bgSpawn=0,bgInit=false,coinSpr=null,cardSpr=null,cardKey='';const BP=[];
function bgResize(){const d=Math.min(devicePixelRatio,1.5);BW=innerWidth;BH=innerHeight;bgc.width=BW*d;bgc.height=BH*d;bgx.setTransform(d,0,0,d,0,0);}
function bgSprites(){
 if(!coinSpr){const c=document.createElement('canvas');c.width=c.height=64;const g=c.getContext('2d'),gr=g.createRadialGradient(24,22,4,32,32,32);gr.addColorStop(0,'#fff6c8');gr.addColorStop(.45,'#f0bf4a');gr.addColorStop(1,'#8a5d10');g.fillStyle=gr;g.beginPath();g.arc(32,32,30,0,TAU);g.fill();g.strokeStyle='rgba(90,55,5,.8)';g.lineWidth=3;g.beginPath();g.arc(32,32,24,0,TAU);g.stroke();g.fillStyle='rgba(90,55,5,.85)';g.font='800 28px Georgia,serif';g.textAlign='center';g.textBaseline='middle';g.fillText('★',32,34);coinSpr=c;}
 const key=cfg.cards.backBase+cfg.cards.backAccent;
 if(key!==cardKey){cardKey=key;const c=document.createElement('canvas');c.width=48;c.height=68;const g=c.getContext('2d'),rd=mulberry(5);rrect(g,0,0,48,68,6);g.fillStyle=cfg.cards.backBase;g.fill();g.save();rrect(g,0,0,48,68,6);g.clip();g.fillStyle=cfg.cards.backAccent;
  for(let i=0;i<4;i++)for(let j=0;j<5;j++){g.save();g.translate((i+.5)*12+(rd()-.5)*4,(j+.5)*13.6+(rd()-.5)*4);g.rotate(rd()*TAU);g.globalAlpha=.6+rd()*.35;g.beginPath();g.arc(0,0,4,0,Math.PI*1.25);g.arc(1.4,-.4,3.2,Math.PI*1.25,0,true);g.closePath();g.fill();g.restore();}
  g.restore();rrect(g,2,2,44,64,5);g.strokeStyle='rgba(231,184,75,.75)';g.lineWidth=1.6;g.stroke();cardSpr=c;}}
function bgMake(first){const card=Math.random()<.32,z=rnd(.55,1.4);BP.push({card,x:rnd(0,BW),y:first?rnd(-40,BH):rnd(-70,-20),vy:(card?rnd(70,170):rnd(110,260))*z,sw:rnd(.6,1.6),sa:rnd(10,40),ph:rnd(0,TAU),a:rnd(0,TAU),va:rnd(1.5,5)*(Math.random()<.5?-1:1),s:(card?rnd(26,46):rnd(16,34))*z,al:rnd(.6,.95)});}
function bgStep(dt){const on=S.screen==='home'||S.screen==='lobby';
 if(!on){if(BP.length||bgInit){BP.length=0;bgInit=false;bgT=0;bgx.clearRect(0,0,BW,BH);}return;}
 bgSprites();if(!bgInit){bgInit=true;for(let i=0;i<34;i++)bgMake(true);}
 bgT+=dt;bgSpawn+=dt*(bgT<3?10:5.5);while(bgSpawn>=1){bgSpawn--;if(BP.length<80)bgMake(false);}
 bgx.clearRect(0,0,BW,BH);
 for(let i=BP.length-1;i>=0;i--){const p=BP[i];p.y+=p.vy*dt;p.a+=p.va*dt;if(p.y>BH+70){BP.splice(i,1);continue;}
  const x=p.x+Math.sin(bgT*p.sw+p.ph)*p.sa,sx=Math.max(p.card?.25:.18,Math.abs(Math.cos(p.a))),w=p.s,h=p.card?p.s*1.4:p.s;
  bgx.save();bgx.globalAlpha=p.al;bgx.translate(x,p.y);if(p.card){bgx.rotate(Math.sin(p.a*.5)*.6);bgx.drawImage(cardSpr,-w*sx/2,-h/2,w*sx,h);}else bgx.drawImage(coinSpr,-w*sx/2,-w/2,w*sx,w);bgx.restore();}}

/* ================= navegación y paneles ================= */
let cur=null;
function setScene(s){cur=s;s.fit();}
function show(id){FXMASK=null;['home','lobby','game','daily'].forEach(x=>$('#'+x).classList.toggle('hidden',x!==id));S.screen=id;}
function setAdmin(on){S.admin=on;document.body.classList.toggle('is-admin',on);}
function goHome(){S.dailyAuto=false;clearCards();show('home');setScene(AMB);}
function goLobby(){if(S.game==='cards')clearCards();S.game=null;show('lobby');setScene(AMB);dailyDot();if(!S.dailyAuto&&dailyClaimable()){S.dailyAuto=true;setTimeout(()=>{if(S.screen==='lobby')openDaily();},450);}}
function goGame(g){S.game=g;show('game');hideWin();$('#gHud').style.display=(g==='cards')?'none':'';
 if(g==='slots'){$('#gTitle').textContent='Tragaperras';setScene(SL);panelSlots();}
 else if(g==='roulette'){$('#gTitle').textContent='Ruleta';setScene(RO);panelRoulette();}
 else if(g==='claw'){$('#gTitle').textContent='Peluches';setScene(CL);clawEnter();panelClaw();}
 else if(g==='shelf'){$('#gTitle').textContent='Estantería';setScene(SH);shelfEnter();panelShelf();}
 else{$('#gTitle').textContent='Cartas';setScene(CA);panelCards();startCards();}}
function setHud(t){$('#gHud').textContent=t;}
function panelSlots(){const c=cfg.slots;setHud('Elige tu apuesta y gira');
 $('#panel').innerHTML='<div class="info"><div><small>Último premio</small><b id="slLast">'+fmt(S.slLast)+'</b></div><div><small>Premio mayor</small><b class="jk">'+fmt(Math.round(c.jackpotPrize*winM()))+'</b></div></div><div class="seg">'+[1,2,5,10].map(m=>'<button data-a="slmult" data-v="'+m+'" class="'+(S.slotMult===m?'on':'')+'">'+fmt(c.bet*m)+'</button>').join('')+'</div><button class="btn big" id="slSpin" data-a="slspin"'+(SL.busy?' disabled':'')+'>GIRAR</button>';}
function panelRoulette(){const c=cfg.roulette;if(S.rTier>=c.tiers.length)S.rTier=0;const tier=c.tiers[S.rTier],stake=c.bet*tier.cost,pr=rouProb(S.rGroup,tier);
 $('#panel').innerHTML='<div class="seg">'+['red','black','green','gold'].map(g=>'<button data-a="rgroup" data-v="'+g+'" class="'+(S.rGroup===g?'on':'')+'"><i class="dot" style="background:'+GC[g]+'"></i>'+GN[g]+'<small>paga ×'+(c.pay[g]||0)+'</small></button>').join('')+'</div>'
 +'<div class="seg">'+c.tiers.map((t,i)=>'<button data-a="rtier" data-v="'+i+'" class="'+(S.rTier===i?'on':'')+'">'+esc(t.n)+'<small>×'+t.cost+' · +'+t.boost+'%</small></button>').join('')+'</div>'
 +'<div class="info"><div><small>Apuestas</small><b>'+fmt(stake)+'</b></div><div><small>Si ganas</small><b>'+fmt(Math.round(stake*(c.pay[S.rGroup]||0)*winM()))+'</b></div><div><small>Probabilidad</small><b>'+Math.round(pr*100)+'%</b></div></div>'
 +'<button class="btn big" id="ruSpin" data-a="ruspin"'+(RO.spin?' disabled':'')+'>GIRAR RUEDA</button>';if(!RO.spin)setHud('Elige color y nivel de suerte');}
$('#panel').addEventListener('click',e=>{const b=e.target.closest('[data-a]');if(!b)return;const a=b.dataset.a,v=b.dataset.v;
 if(a==='slmult'){S.slotMult=+v;panelSlots();}else if(a==='slspin')slotsSpin();else if(a==='rgroup'){S.rGroup=v;panelRoulette();}else if(a==='rtier'){S.rTier=+v;panelRoulette();}else if(a==='ruspin')rouSpin();else if(a==='cmode')setCardsMode(v);});

/* ================= SONIDO DE FERIA (máquina de peluches) ================= */
const FAIR={on:false,step:0,timer:0,mo:null,mg:null};
const MEL=[523,659,784,1047,784,659,523,0,587,698,880,1175,880,698,587,0,659,784,988,1319,988,784,659,0,784,988,1175,1568,1175,988,784,0];
const BASS=[131,196,131,196,147,220,147,220,165,247,165,247,196,294,196,294];
function fairStep(){if(!FAIR.on||S.mute)return;const i=FAIR.step++%MEL.length,n=MEL[i];if(n)tone(n,.14,'square',i%4===3?.03:.018);if(i%2===0)tone(BASS[(i>>1)%BASS.length],.2,'triangle',.04);if(i%4===0)tone(80,.07,'sine',.06);if(i%8===4)tone(2600,.03,'square',.008);}
function fairStart(){if(FAIR.on)return;try{AC=AC||new(window.AudioContext||window.webkitAudioContext)();if(AC.state==='suspended')AC.resume();}catch(e){}FAIR.on=true;FAIR.step=0;FAIR.timer=setInterval(fairStep,150);}
function fairStop(){if(!FAIR.on)return;FAIR.on=false;clearInterval(FAIR.timer);motor(false);}
function motor(on,f){try{if(!on||S.mute){if(FAIR.mg&&AC)FAIR.mg.gain.setTargetAtTime(0,AC.currentTime,.05);return;}
 AC=AC||new(window.AudioContext||window.webkitAudioContext)();
 if(!FAIR.mo){FAIR.mo=AC.createOscillator();FAIR.mg=AC.createGain();const fl=AC.createBiquadFilter();fl.type='lowpass';fl.frequency.value=700;FAIR.mo.type='sawtooth';FAIR.mg.gain.value=0;FAIR.mo.connect(fl);fl.connect(FAIR.mg);FAIR.mg.connect(AC.destination);FAIR.mo.start();}
 FAIR.mo.frequency.setTargetAtTime(f||70,AC.currentTime,.05);FAIR.mg.gain.setTargetAtTime(.035,AC.currentTime,.05);}catch(e){}}
function sweep(f0,f1,d,type,v){if(S.mute)return;try{AC=AC||new(window.AudioContext||window.webkitAudioContext)();const o=AC.createOscillator(),g=AC.createGain(),t=AC.currentTime;o.type=type||'sine';o.frequency.setValueAtTime(f0,t);o.frequency.exponentialRampToValueAtTime(f1,t+d);g.gain.setValueAtTime(v||.05,t);g.gain.exponentialRampToValueAtTime(.0001,t+d);o.connect(g);g.connect(AC.destination);o.start(t);o.stop(t+d+.02);}catch(e){}}
function fairSfx(k){
 if(k==='go'){tone(1568,.08,'square',.05);tone(2093,.14,'square',.05,.08);}
 else if(k==='desc')sweep(900,220,.9,'triangle',.05);
 else if(k==='clack'){tone(180,.08,'square',.06);tone(120,.1,'sawtooth',.05,.03);}
 else if(k==='win'){[784,988,1175,1568,1175,1568,1976].forEach((f,i)=>tone(f,.22,'triangle',.07,i*.09));tone(2637,.5,'sine',.05,.3);tone(3136,.5,'sine',.04,.45);}
 else if(k==='miss'){[311,277,247,196].forEach((f,i)=>tone(f,.28,'sawtooth',.035,i*.24));}}
let clawPrev={x:0,y:0,z:0};
function clawMotor(dt){const K=CLW,d=Math.hypot(K.x-clawPrev.x,K.y-clawPrev.y,K.z-clawPrev.z)/Math.max(dt,.001);clawPrev={x:K.x,y:K.y,z:K.z};motor(d>.25&&S.game==='claw',60+Math.min(d,3)*25);}

/* ================= REGALO DIARIO ================= */
const DNAMES=['LUN','MAR','MIÉ','JUE','VIE','SÁB','DOM'],DFULL=['lunes','martes','miércoles','jueves','viernes','sábado','domingo'];
function loadDaily(){try{const s=JSON.parse(localStorage.getItem('loya_daily'));if(s&&s.cl)return s;}catch(e){}return{wk:'',cl:[0,0,0,0,0,0,0],streak:0,last:''};}
let DLY=loadDaily();
const saveDaily=()=>{try{localStorage.setItem('loya_daily',JSON.stringify(DLY));}catch(e){}};
const dkey=d=>d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0')+'-'+String(d.getDate()).padStart(2,'0');
function todayInfo(){const d=new Date(),idx=(d.getDay()+6)%7,mon=new Date(d);mon.setDate(d.getDate()-idx);return{idx,wk:dkey(mon),key:dkey(d)};}
function dailySync(){const t=todayInfo();if(DLY.wk!==t.wk){DLY.wk=t.wk;DLY.cl=[0,0,0,0,0,0,0];saveDaily();}
 const y=new Date();y.setDate(y.getDate()-1);if(DLY.last&&DLY.last!==t.key&&DLY.last!==dkey(y)&&DLY.streak){DLY.streak=0;saveDaily();}return t;}
const dailyReward=i=>Math.round((cfg.daily&&cfg.daily.r&&cfg.daily.r[i])||0);
function dailyClaimable(){const t=dailySync();return !DLY.cl[t.idx];}
function dailyDot(){const b=$('#lobDaily');if(b)b.classList.toggle('has',dailyClaimable());}
function nextTxt(){const n=new Date(),m=new Date(n);m.setHours(24,0,0,0);const s=Math.max(0,Math.floor((m-n)/1000)),p=v=>String(v).padStart(2,'0');return p(Math.floor(s/3600))+':'+p(Math.floor(s%3600/60))+':'+p(s%60);}
const DY=mkScene({fov:40,dir:[0,.3,1],fitW:5.6,fitH:4.8,shift:.2,target:[0,.9,0]});
addLights(DY.scene);
Object.assign(DY,{hero:null,burst:[],orbit:[],leaving:false,mode:'idle',open:.07,cd:0});
(function(){const n=220,pos=new Float32Array(n*3);for(let i=0;i<n;i++){pos[i*3]=rnd(-9,9);pos[i*3+1]=rnd(-5,8);pos[i*3+2]=rnd(-9,2);}const geo=new THREE.BufferGeometry();geo.setAttribute('position',new THREE.BufferAttribute(pos,3));
 DY.pts=new THREE.Points(geo,new THREE.PointsMaterial({color:0xffd98a,size:.07,transparent:true,opacity:.75,depthWrite:false,blending:THREE.AdditiveBlending}));DY.scene.add(DY.pts);
 const pd=new THREE.Mesh(new THREE.CylinderGeometry(2.2,2.5,.22,48),goldMat(0x8a5f14));pd.position.y=-.12;DY.scene.add(pd);const rg=new THREE.Mesh(new THREE.TorusGeometry(2.2,.04,8,64),new THREE.MeshBasicMaterial({color:0xffd36b}));rg.rotation.x=Math.PI/2;rg.position.y=-.01;DY.scene.add(rg);})();
let DYRAYS=null;
function dyRays(){if(DYRAYS)return DYRAYS;const c=document.createElement('canvas');c.width=c.height=256;const g=c.getContext('2d');g.translate(128,128);const gr=g.createRadialGradient(0,0,0,0,0,128);gr.addColorStop(0,'rgba(255,255,255,.9)');gr.addColorStop(1,'rgba(255,255,255,0)');g.fillStyle=gr;for(let i=0;i<14;i++){g.rotate(TAU/14);g.beginPath();g.moveTo(0,0);g.lineTo(128,-8);g.lineTo(128,8);g.closePath();g.fill();}DYRAYS=new THREE.CanvasTexture(c);return DYRAYS;}
function mkHero(){const g=new THREE.Group(),M=(c,r,m,e)=>new THREE.MeshStandardMaterial({color:c,roughness:r,metalness:m,emissive:e||0x000000});
 const wood=M(0x5a2f86,.5,.3),gold=M(0xe2b449,.3,.9),gemM=M(0xff4fd8,.2,.3,0x661a55),coinM=M(0xf0bf4a,.25,.9);
 const add=(geo,mat,x,y,z,par)=>{const o=new THREE.Mesh(geo,mat);o.position.set(x,y,z);(par||g).add(o);return o;},bx=(w,h,d)=>new THREE.BoxGeometry(w,h,d);
 const glow=new THREE.Sprite(new THREE.SpriteMaterial({map:glowT(),color:0xffc83a,transparent:true,opacity:.8,blending:THREE.AdditiveBlending,depthWrite:false}));glow.scale.set(4.4,4.4,1);glow.position.set(0,.6,-.4);g.add(glow);
 const rays=new THREE.Sprite(new THREE.SpriteMaterial({map:dyRays(),color:0xffe08a,transparent:true,opacity:.45,blending:THREE.AdditiveBlending,depthWrite:false}));rays.scale.set(6,6,1);rays.position.set(0,.6,-.5);g.add(rays);
 add(bx(1.1,.62,.76),wood,0,.31,0);[-.4,.4].forEach(x=>add(bx(.1,.64,.78),gold,x,.31,0));add(bx(1.16,.07,.82),gold,0,.035,0);add(bx(1.14,.05,.8),gold,0,.6,0);
 [[-.55,-.38],[.55,-.38],[-.55,.38],[.55,.38]].forEach(q=>add(new THREE.SphereGeometry(.06,10,8),gold,q[0],.05,q[1]));
 const heap=new THREE.Group();heap.position.y=.58;g.add(heap);const cg=new THREE.CylinderGeometry(.14,.14,.04,14);
 for(let i=0;i<22;i++){const c=new THREE.Mesh(cg,coinM),a=rnd(0,TAU),r=rnd(0,.34)*(1-i/40);c.position.set(Math.cos(a)*r*1.1,.02+i*.012,Math.sin(a)*r*.7);c.rotation.set(rnd(-.5,.5),rnd(0,TAU),rnd(-.5,.5));heap.add(c);}
 const inner=new THREE.Sprite(new THREE.SpriteMaterial({map:glowT(),color:0xffd36b,transparent:true,opacity:0,blending:THREE.AdditiveBlending,depthWrite:false}));inner.scale.set(1.8,1.2,1);inner.position.set(0,.75,0);g.add(inner);
 const lid=new THREE.Group();lid.position.set(0,.62,-.38);g.add(lid);
 const lm=new THREE.Mesh(new THREE.CylinderGeometry(.38,.38,1.1,18,1,false,0,Math.PI),wood);lm.rotation.z=Math.PI/2;lm.position.z=.38;lid.add(lm);
 [-.4,.4].forEach(x=>{const b=new THREE.Mesh(new THREE.CylinderGeometry(.39,.39,.1,18,1,false,0,Math.PI),gold);b.rotation.z=Math.PI/2;b.position.set(x,0,.38);lid.add(b);});
 add(new THREE.SphereGeometry(.1,14,10),gemM,0,.04,.78,lid);add(bx(.18,.24,.05),gold,0,-.1,.4,lid);
 g.scale.setScalar(1.9);return{g,lid,heap,inner,glow,rays};}
DY.build=()=>{if(DY.hero){DY.scene.remove(DY.hero.g);DY.hero=null;}DY.orbit.forEach(m=>DY.scene.remove(m));DY.orbit=[];
 try{const t=dailySync(),done=!!DLY.cl[t.idx];DY.hero=mkHero();DY.scene.add(DY.hero.g);DY.mode=done?'open':'idle';DY.open=done?1:.07;
  const cg=new THREE.CylinderGeometry(.14,.14,.035,16),cm=goldMat(0xf0bf4a);for(let i=0;i<10;i++){const m=new THREE.Mesh(cg,cm);m.userData.a=i/10*TAU;DY.scene.add(m);DY.orbit.push(m);}}catch(e){console.warn('hero',e);}};
DY.update=(T,dt)=>{const h=DY.hero;
 if(h){h.g.rotation.y=Math.sin(T*.7)*.45;h.g.position.y=DY.mode==='open'?0:.06+Math.sin(T*3)*.05;if(DY.mode==='idle')DY.open=.07+.05*Math.sin(T*3);
  h.lid.rotation.x=-1.5*DY.open;h.inner.material.opacity=Math.min(1,DY.open*1.1)*(.7+.3*Math.sin(T*6));h.glow.material.opacity=.7+.15*Math.sin(T*4);h.rays.material.rotation=T*.45;}
 DY.orbit.forEach((m,i)=>{const a=m.userData.a+T*1.1;m.position.set(Math.cos(a)*2,1.1+Math.sin(T*2+i)*.25,Math.sin(a)*1.2);m.rotation.x=T*3+i;m.rotation.z=T*2;});
 for(let i=DY.burst.length-1;i>=0;i--){const b=DY.burst[i];b.t+=dt;b.v.y-=9*dt;b.m.position.addScaledVector(b.v,dt);b.m.rotation.x+=b.s*dt;b.m.rotation.z+=b.s*.6*dt;if(b.m.position.y<.05&&b.v.y<0){b.m.position.y=.05;b.v.y*=-.45;b.v.x*=.7;b.v.z*=.7;}if(b.t>2.2){b.m.scale.setScalar(Math.max(.001,1-(b.t-2.2)*2.5));if(b.t>2.6){DY.scene.remove(b.m);DY.burst.splice(i,1);}}}
 DY.pts.rotation.y=T*.03;DY.cd+=dt;if(DY.cd>.5){DY.cd=0;const e=$('#dyCd');if(e)e.textContent=nextTxt();}};
DY.spawnBurst=()=>{const geo=new THREE.CylinderGeometry(.12,.12,.03,14),mat=goldMat(new THREE.Color(cfg.coinColor||'#f0bf4a'));for(let i=0;i<34;i++){const m=new THREE.Mesh(geo,mat);m.position.set(rnd(-.3,.3),1.4,.4);DY.scene.add(m);const a=rnd(0,TAU),s=rnd(1.5,4);DY.burst.push({m,t:0,s:rnd(4,12),v:new THREE.Vector3(Math.cos(a)*s*.6,rnd(4,8),Math.abs(Math.sin(a))*s+.5)});}};
function dyTile(i,t){const st=DLY.cl[i]?'done':(i===t.idx?'today':(i<t.idx?'miss':'lock')),mark=st==='done'?'✓':st==='miss'?'✗':st==='lock'?'🔒':'';
 if(i===6)return'<div class="dtile big '+st+'" data-d="6"><span class="dmark">'+mark+'</span><div class="bigico">🎁</div><div><div class="dday">'+DNAMES[6]+' · PREMIO GORDO</div><div class="damt">+'+fmt(dailyReward(6))+'</div></div></div>';
 let coins='';for(let k=0;k<Math.min(i+1,6);k++)coins+='<i class="cn"></i>';
 return'<div class="dtile '+st+'" data-d="'+i+'"><span class="dmark">'+mark+'</span><div class="dday">'+DNAMES[i]+'</div><div class="cstack">'+coins+'</div><div class="damt">+'+fmt(dailyReward(i))+'</div></div>';}
function dyPanel(){const t=dailySync(),done=!!DLY.cl[t.idx];let h='<div class="dhead"><b>Regalos de la semana</b><span class="dstreak">🔥 Racha '+DLY.streak+'</span></div><div class="dgrid">';
 for(let i=0;i<7;i++)h+=dyTile(i,t);h+='</div>';
 h+=done?'<button class="btn big" disabled>Reclamado ✓</button><div class="dnext">Próximo regalo en <b id="dyCd">'+nextTxt()+'</b></div>':'<button class="btn big pulse" data-a="dyclaim">¡RECLAMAR +'+fmt(dailyReward(t.idx))+'!</button>';
 h+='<div class="cap">Cada regalo solo se reclama su propio día: lunes +'+fmt(dailyReward(0))+' hasta domingo +'+fmt(dailyReward(6))+'.</div>';
 $('#dyPanel').innerHTML=h;$('#dyHud').textContent=done?'¡Ya reclamaste el regalo de hoy!':'¡Tu regalo de hoy te espera!';}
function openDaily(){dailySync();S.game=null;DY.leaving=false;$('#dyCard').classList.remove('gone');show('daily');try{DY.build();setScene(DY);}catch(e){console.warn(e);setScene(AMB);}dyPanel();}
async function dyClaim(){const t=dailySync();if(DLY.cl[t.idx]||DY.leaving)return;DY.leaving=true;const r=dailyReward(t.idx);
 DLY.cl[t.idx]=1;const y=new Date();y.setDate(y.getDate()-1);DLY.streak=(DLY.last===dkey(y))?DLY.streak+1:1;DLY.last=t.key;saveDaily();addCoins(r);
 const tl=$('#dyPanel [data-d="'+t.idx+'"]');if(tl)tl.classList.add('flip');sfx.card();
 DY.mode='open';const o0=DY.open;await tw(.55,e=>{DY.open=o0+(1-o0)*e;},E.out);
 DY.spawnBurst();dyPanel();celebrate(false);fxPlay(['stars','lights'],false);showWin(r,{title:'¡REGALO DIARIO!'});
 await sleep(2700);hideWin();$('#dyCard').classList.add('gone');await sleep(800);DY.leaving=false;goLobby();dailyDot();}
$('#dyPanel').addEventListener('click',e=>{if(e.target.closest('[data-a="dyclaim"]')){dyClaim();return;}const tl=e.target.closest('[data-d]');if(!tl)return;const i=+tl.dataset.d,t=todayInfo();
 if(tl.classList.contains('today'))dyClaim();else if(tl.classList.contains('done'))toast('Ya reclamaste este regalo');else if(tl.classList.contains('miss'))toast('Ese día ya pasó');else toast('Disponible el '+DFULL[i]);});
$('#lobDaily').onclick=openDaily;$('#dyBack').onclick=()=>{if(!DY.leaving)goLobby();};

/* ================= apuesta de cartas ================= */
S.cardBet=null;
function curBet(){const c=cfg.cards,v=Math.round(S.cardBet==null?c.bet:S.cardBet);return Math.max(c.betMin,Math.min(c.betMax,v||c.betMin));}
function setCardBet(v){const c=cfg.cards;S.cardBet=Math.max(c.betMin,Math.min(c.betMax,Math.round(v)||c.betMin));const i=$('#cardBet');if(i&&document.activeElement!==i)i.value=S.cardBet;const w=$('#cardWin');if(w)w.textContent=fmt(Math.round(S.cardBet*c.payout*winM()));G.msg='';cHud();}
$('#panel').addEventListener('click',e=>{const b=e.target.closest('[data-cb]');if(!b)return;const v=b.dataset.cb,cur=curBet();
 if(v==='-')setCardBet(cur-Math.max(10,Math.round(cur*.1)));else if(v==='+')setCardBet(cur+Math.max(10,Math.round(cur*.1)));else if(v==='min')setCardBet(cfg.cards.betMin);else if(v==='half')setCardBet(cur/2);else if(v==='dbl')setCardBet(cur*2);else if(v==='all')setCardBet(Math.min(S.coins,cfg.cards.betMax));});
$('#panel').addEventListener('input',e=>{if(e.target.id==='cardBet'){const v=parseFloat(e.target.value);if(!isNaN(v)){const c=cfg.cards;S.cardBet=Math.max(c.betMin,Math.min(c.betMax,Math.round(v)));const w=$('#cardWin');if(w)w.textContent=fmt(Math.round(S.cardBet*c.payout*winM()));G.msg='';cHud();}}});
$('#panel').addEventListener('change',e=>{if(e.target.id==='cardBet')setCardBet(parseFloat(e.target.value));});
function cardsLayout(){if(S.game!=='cards')return;const p=$('#panel'),H=innerHeight,ph=p.offsetHeight||170,top=70,free=Math.max(.45,(H-ph-top)/H);CA.fitH=9.6/free;CA.shift=(ph-top)/(2*H);CA.fit();}
function panelCards(){const c=cfg.cards,two=S.cardMode==='two';if(S.cardBet==null)S.cardBet=c.bet;$('#gHud').style.display='none';
 $('#panel').innerHTML='<div id="cardMsg" class="cmsg"></div><div class="seg"><button data-a="cmode" data-v="bot" class="'+(!two?'on':'')+'">Contra el bot</button><button data-a="cmode" data-v="two" class="'+(two?'on':'')+'">2 jugadores</button></div>'
 +(two?'':'<div class="betrow"><button data-cb="-" aria-label="Bajar apuesta">−</button><input type="number" id="cardBet" inputmode="numeric" min="'+c.betMin+'" max="'+c.betMax+'" value="'+curBet()+'" aria-label="Monedas a apostar"><button data-cb="+" aria-label="Subir apuesta">+</button><button class="sm" data-cb="half">½</button><button class="sm" data-cb="dbl">×2</button><button class="sm" data-cb="all">Todo</button></div>');
 cHud();requestAnimationFrame(()=>requestAnimationFrame(cardsLayout));}
function rigTick(T,dt){const sc=cur&&cur.scene;for(let i=RIGS.length-1;i>=0;i--){const w=RIGS[i],r=w.userData.rig;let top=w;while(top.parent)top=top.parent;
 if(!top.isScene){r.orph=(r.orph||0)+dt;if(r.orph>3)RIGS.splice(i,1);continue;}r.orph=0;if(top!==sc)continue;
 const t=T+r.ph,b=Math.sin(t*2.1),k=r.k;r.g.scale.set(k*(1+b*.008),k*(1+b*.022),k*(1+b*.008));
 if(r.head)r.head.rotation.set(Math.sin(t*.8)*.04,Math.sin(t*.55)*.14,Math.sin(t*1.1)*.05);
 if(r.eyes){const bt=(T*.9+r.ph*2)%4.6,bl=bt<.16?Math.sin(bt/.16*Math.PI):0;r.eyes.scale.y=1-.92*bl;}
 if(r.armL)r.armL.rotation.z=Math.sin(t*1.7)*.09;if(r.armR)r.armR.rotation.z=-Math.sin(t*1.7+.6)*.09;
 if(r.earL){const q=(T*.6+r.ph)%5,tq=q<.25?Math.sin(q/.25*Math.PI)*.3:0;r.earL.rotation.z=tq;r.earR.rotation.z=-tq;}
 if(r.tail)r.tail.rotation.y=Math.sin(t*(r.tailSp||3))*.4;if(r.spin)r.spin.forEach(q=>{q.g.rotation[q.ax||'y']+=q.s*dt;});}}
function DAILY_FIELDS(){return '<h4>Regalo diario (monedas por día)</h4>'+DFULL.map((d,i)=>num(d.charAt(0).toUpperCase()+d.slice(1),'daily.r.'+i,{step:5})).join('')+'<div class="btnrow"><button class="mini" data-act="dayreset">Reiniciar regalo de hoy</button></div>';}

addEventListener('pointerdown',()=>{try{if(AC&&AC.state==='suspended')AC.resume();}catch(e){}},{passive:true});
/* ================= login ================= */
function openLogin(){$('#lgE').textContent='';$('#lgU').value='';$('#lgP').value='';$('#login').classList.remove('hidden');setTimeout(()=>$('#lgU').focus(),60);}
function doLogin(){if($('#lgU').value.trim()==='admin'&&$('#lgP').value==='admin'){$('#login').classList.add('hidden');setAdmin(true);goLobby();toast('Modo administrador activado');}else $('#lgE').textContent='Usuario o contraseña incorrectos.';}
$('#logo').onclick=openLogin;$('#lgX').onclick=()=>$('#login').classList.add('hidden');$('#lgOk').onclick=doLogin;$('#lgP').addEventListener('keydown',e=>{if(e.key==='Enter')doLogin();});
$('#btnPlay').onclick=()=>{setAdmin(false);goLobby();};$('#btnLogout').onclick=()=>{setAdmin(false);goHome();};
$$('.tile').forEach(t=>t.onclick=()=>goGame(t.dataset.go));$('#btnBack').onclick=()=>{if(S.game==='view')viewBack();else goLobby();};
$('#btnSnd').onclick=()=>{S.mute=!S.mute;$('#btnSnd').textContent=S.mute?'🔇':'🔊';};
$('#lobAdmin').onclick=()=>openAdmin('gen');$('#gAdmin').onclick=()=>openAdmin(S.game==='slots'?'sl':S.game==='roulette'?'ru':S.game==='cards'?'ca':(S.game==='claw'||S.game==='shelf'||S.game==='view')?'pl':'gen');

/* ================= panel de administrador ================= */
let admTab='gen',armed=false,rfT=0;
const num=(l,p,o={})=>'<label class="f"><span>'+l+'</span><input type="number" data-k="'+p+'" data-t="n" value="'+getP(p)+'" min="'+(o.min??0)+'"'+(o.max!=null?' max="'+o.max+'"':'')+' step="'+(o.step||1)+'"></label>';
const col=(l,p)=>'<label class="f"><span>'+l+'</span><input type="color" data-k="'+p+'" data-t="s" value="'+getP(p)+'"></label>';
const chk=(l,p)=>'<label class="f chk"><span>'+l+'</span><input type="checkbox" data-k="'+p+'" data-t="b"'+(getP(p)?' checked':'')+'><i class="sw"></i></label>';
const sel=(l,p,opts,t)=>'<label class="f"><span>'+l+'</span><select data-k="'+p+'" data-t="'+(t||'s')+'">'+opts.map(o=>'<option value="'+esc(o[0])+'"'+(String(getP(p))===String(o[0])?' selected':'')+'>'+esc(o[1])+'</option>').join('')+'</select></label>';
const TABS={
 gen:()=>'<div class="note">Todo cambia en vivo y se guarda en este dispositivo.</div>'+num('Monedas iniciales','startCoins',{step:100})+num('Multiplicador de ganancias (×)','winMul',{min:0,step:.05})+'<div class="note">Multiplica lo que ganas en tragaperras, ruleta y cartas. 1.3 = +30 %.</div>'+DAILY_FIELDS()+'<h4>Datos de este navegador</h4><div class="note">Tu progreso se guarda solo en este navegador.</div><div class="btnrow"><button class="mini warn" data-act="wipe">Borrar todo mi progreso</button></div>'+'<div class="f"><span>Dar monedas a mi saldo</span><span class="inl"><input type="number" id="giveN" value="1000" min="0" step="100" style="width:96px"><button class="mini" style="margin:0" data-act="give">Dar</button></span></div><div class="btnrow"><button class="mini" data-act="resetWallet">Reiniciar saldo</button><button class="mini warn" data-act="resetAll">Restablecer todo</button></div>',
 sl:()=>{const c=cfg.slots;return num('Apuesta base','slots.bet',{min:1})+num('Duración del giro (s)','slots.spinTime',{min:.5,step:.1})+num('Probabilidad de ganar (%)','slots.winChance',{max:100})+num('Probabilidad del premio mayor (%)','slots.jackpotChance',{max:100,step:.5})+num('Premio mayor (monedas)','slots.jackpotPrize',{step:100})
  +sel('Símbolo del premio mayor','slots.jackpotIndex',c.symbols.map((x,i)=>[i,x.s]),'n')+'<h4>Símbolos y pago (× apuesta)</h4>'
  +c.symbols.map((x,i)=>'<div class="lr s3"><input type="text" maxlength="6" data-k="slots.symbols.'+i+'.s" data-t="s" value="'+esc(x.s)+'"><input type="number" min="0" step="1" data-k="slots.symbols.'+i+'.m" data-t="n" value="'+x.m+'"><button class="x" data-act="symdel" data-i="'+i+'" aria-label="Quitar">✕</button></div>').join('')
  +'<button class="mini" data-act="symadd">+ Símbolo</button><h4>Colores</h4>'+col('Fondo de los rodillos','slots.reelColor')+col('Marco de la máquina','slots.frameColor')+col('Luces','slots.bulbColor');},
 ru:()=>{const c=cfg.roulette,gs=[['red','Rojo'],['black','Negro'],['green','Verde'],['gold','Dorado']],gh=gs.concat([['house','Casa']]);
  return num('Apuesta base','roulette.bet',{min:1})+num('Duración del giro (s)','roulette.spinTime',{min:1,step:.5})+num('Suerte base de la rueda (%)','roulette.luck',{min:1,max:100})+'<h4>Pago por color (× apuesta)</h4>'+gs.map(g=>num(g[1],'roulette.pay.'+g[0],{step:.5})).join('')
  +'<h4>Botones de suerte</h4><div class="note">Costo: veces que se multiplica la apuesta. Suerte: % extra de que caiga tu color.</div><div class="lh t3"><span>Nombre</span><span>Costo ×</span><span>Suerte %</span><span></span></div>'
  +c.tiers.map((t,i)=>'<div class="lr t3"><input type="text" maxlength="12" data-k="roulette.tiers.'+i+'.n" data-t="s" value="'+esc(t.n)+'"><input type="number" min="1" step="1" data-k="roulette.tiers.'+i+'.cost" data-t="n" value="'+t.cost+'"><input type="number" min="0" max="100" step="1" data-k="roulette.tiers.'+i+'.boost" data-t="n" value="'+t.boost+'"><button class="x" data-act="tierdel" data-i="'+i+'" aria-label="Quitar">✕</button></div>').join('')
  +'<button class="mini" data-act="tieradd">+ Botón</button><h4>Casillas de la rueda</h4><div class="note">Peso: cuanto mayor, más probable que caiga.</div><div class="lh g5"><span>Texto</span><span>Color</span><span>Grupo</span><span>Peso</span><span></span></div>'
  +c.segments.map((s,i)=>'<div class="lr g5"><input type="text" maxlength="4" data-k="roulette.segments.'+i+'.l" data-t="s" value="'+esc(s.l)+'"><input type="color" data-k="roulette.segments.'+i+'.c" data-t="s" value="'+s.c+'"><select data-k="roulette.segments.'+i+'.g" data-t="s">'+gh.map(g=>'<option value="'+g[0]+'"'+(s.g===g[0]?' selected':'')+'>'+g[1]+'</option>').join('')+'</select><input type="number" min="0" step=".5" data-k="roulette.segments.'+i+'.w" data-t="n" value="'+s.w+'"><button class="x" data-act="segdel" data-i="'+i+'" aria-label="Quitar">✕</button></div>').join('')
  +'<div class="btnrow"><button class="mini" data-act="segadd">+ Casilla</button><button class="mini warn" data-act="segreset">Restaurar rueda</button></div>';},
 ca:()=>chk('Bot aleatorio (sus cartas y jugadas son al azar)','cards.randomBot')+num('Probabilidad de ganarle al bot (%) · solo si el bot no es aleatorio','cards.playerWinChance',{max:100})+num('Victorias seguidas para la mala racha','cards.streakWins',{min:1})+num('Jugadas que se pierden después','cards.streakLoss',{min:0})+num('Apuesta inicial','cards.bet',{step:10})+num('Apuesta mínima','cards.betMin',{min:1})+num('Apuesta máxima','cards.betMax',{step:100})+num('Pago al ganar (× apuesta)','cards.payout',{min:1,step:.1})+'<h4>Colores de las cartas</h4>'+col('Marco','cards.frame')+col('Panel','cards.panel')+col('Arte','cards.ink')+col('Reverso','cards.backBase')+col('Dibujo del reverso','cards.backAccent')+col('Mesa','cards.felt'),
 pl:()=>{const c=cfg.plush;return num('Costo por intento','plush.cost',{min:1})+num('Probabilidad de agarrar (%)','plush.grabChance',{max:100})+num('Venta (% del valor)','plush.sellPct',{max:100})
  +'<h4>Rarezas</h4><div class="note">Probabilidad = peso relativo entre rarezas. Valor = monedas por peluche.</div><div class="lh r3"><span>Rareza</span><span>Prob.</span><span>Valor</span></div>'
  +RARS.map(r=>'<div class="lr r3"><span style="color:'+RAR[r].c+';font-weight:700">'+RAR[r].n+'</span><input type="number" min="0" step=".5" data-k="plush.rar.'+r+'.p" data-t="n" value="'+c.rar[r].p+'"><input type="number" min="0" step="10" data-k="plush.rar.'+r+'.v" data-t="n" value="'+c.rar[r].v+'"></div>').join('')
  +'<h4>Auras (estilo gacha)</h4><div class="note">Color del aura según la rareza. Los normales no tienen aura y el Único cambia de color solo.</div>'+num('Intensidad del aura','plush.auraI',{step:.1})+RARS.slice(1,6).map(r=>col('Aura '+RAR[r].n,'plush.aura.'+r)).join('')+'<h4>Estantería</h4>'+num('Costo de la primera mejora','plush.upgBase',{step:5})+num('Aumento por cada mejora','plush.upgStep',{step:5})
  +'<h4>Valor por personaje (×)</h4>'+SPECIES.map((s,i)=>num(s.ico+' '+s.n,'plush.spMul.'+i,{step:.1})).join('')
  +'<h4>Dar peluche de prueba</h4><div class="f"><span class="inl"><select id="giveSp" style="max-width:150px">'+SPECIES.map((s,i)=>'<option value="'+i+'">'+s.ico+' '+esc(s.n)+'</option>').join('')+'</select><select id="giveRar" style="max-width:110px">'+RARS.map(r=>'<option value="'+r+'">'+RAR[r].n+'</option>').join('')+'</select></span><button class="mini" style="margin:0" data-act="givePl">Dar</button></div>'
  +'<div class="btnrow"><button class="mini warn" data-act="resetPl">Borrar colección</button></div>';},
 fx:()=>'<h4>Al ganar</h4>'+chk('Estrellas','fx.stars')+chk('Fuegos artificiales','fx.fireworks')+chk('Luces de colores','fx.lights')+chk('Arcoíris','fx.rainbow')
  +'<h4>Premio mayor</h4>'+sel('Aura','jackpotAura',[['gold','Oro'],['fire','Fuego'],['rainbow','Arcoíris'],['none','Sin aura']])+'<h4>Moneda 3D</h4>'+col('Color de la moneda','coinColor')
  +'<div class="btnrow"><button class="mini" data-act="testwin">Probar victoria</button><button class="mini" data-act="testjack">Probar premio mayor</button></div>'};
function renderAdmin(){$('#admTabs').innerHTML=[['gen','General'],['sl','Tragaperras'],['ru','Ruleta'],['ca','Cartas'],['pl','Peluches'],['fx','Efectos']].map(t=>'<button data-tab="'+t[0]+'" class="'+(admTab===t[0]?'on':'')+'">'+t[1]+'</button>').join('');$('#admBody').innerHTML=TABS[admTab]();}
function openAdmin(t){admTab=t||admTab;renderAdmin();$('#admin').classList.remove('hidden');}
$('#admClose').onclick=()=>$('#admin').classList.add('hidden');
$('#admTabs').addEventListener('click',e=>{const b=e.target.closest('[data-tab]');if(b){admTab=b.dataset.tab;renderAdmin();$('#admBody').scrollTop=0;}});
function cfgChanged(p){saveCfg();clearTimeout(rfT);rfT=setTimeout(()=>{
 if(p.startsWith('slots')||p==='jackpotAura'){if(SL.busy)SL.dirty=true;else buildSlots();if(S.game==='slots')panelSlots();}
 if(p.startsWith('roulette')){buildWheelTex();if(S.game==='roulette'&&!RO.spin)panelRoulette();}
 if(p.startsWith('cards')){resetCardTex();buildFelt();if(S.game==='cards')panelCards();}
 if(p.startsWith('plush')){if(S.game==='claw')panelClaw();if(S.game==='shelf')panelShelf();if(S.game==='view')panelView();}},180);}
function onField(e){const el=e.target;if(!el.dataset||!el.dataset.k)return;const t=el.dataset.t;let v;
 if(t==='n'){v=parseFloat(el.value);if(isNaN(v))return;}else if(t==='b')v=el.checked;else v=el.value;setP(el.dataset.k,v);cfgChanged(el.dataset.k);}
$('#admBody').addEventListener('input',onField);$('#admBody').addEventListener('change',onField);
function rebuildAll(){buildSlots();buildWheelTex();resetCardTex();buildFelt();if(S.game==='slots')panelSlots();if(S.game==='roulette')panelRoulette();if(S.game==='cards')panelCards();}
$('#admBody').addEventListener('click',e=>{const b=e.target.closest('[data-act]');if(!b)return;const a=b.dataset.act,i=+b.dataset.i;
 if(a==='wipe'){if(!armed){armed=true;b.textContent='Toca otra vez para confirmar';setTimeout(()=>{armed=false;if(!$('#admin').classList.contains('hidden'))renderAdmin();},3000);return;}armed=false;try{Object.keys(localStorage).filter(k=>k.indexOf('loya_')===0).forEach(k=>localStorage.removeItem(k));}catch(e){}location.reload();return;}
 if(a==='dayreset'){DLY.cl=[0,0,0,0,0,0,0];DLY.last='';DLY.streak=0;saveDaily();dailyDot();toast('Regalo diario reiniciado');return;}
 if(a==='give'){const n=parseFloat($('#giveN').value);if(n>0){addCoins(n);toast('+'+fmt(n)+' monedas');}return;}
 if(a==='givePl'){const it=addItem(+$('#giveSp').value,$('#giveRar').value);toast('Recibiste a '+it.name);return;}
 if(a==='resetPl'){if(!armed){armed=true;b.textContent='Toca otra vez para confirmar';setTimeout(()=>{armed=false;if(!$('#admin').classList.contains('hidden'))renderAdmin();},3000);return;}armed=false;PL.items=[];PL.upg=0;savePL();toast('Colección borrada');return;}
 if(a==='resetWallet'){S.coins=cfg.startCoins;saveCoins();toast('Saldo reiniciado');return;}
 if(a==='resetAll'){if(!armed){armed=true;b.textContent='Toca otra vez para confirmar';setTimeout(()=>{armed=false;if(!$('#admin').classList.contains('hidden'))renderAdmin();},3000);return;}armed=false;cfg=clone(DEF);saveCfg();S.coins=cfg.startCoins;saveCoins();rebuildAll();renderAdmin();toast('Todo restablecido');return;}
 if(a==='symadd'){if(cfg.slots.symbols.length<10)cfg.slots.symbols.push({s:'🍉',m:5});else toast('Máximo 10 símbolos');}
 else if(a==='symdel'){if(cfg.slots.symbols.length>3){cfg.slots.symbols.splice(i,1);if(cfg.slots.jackpotIndex>=cfg.slots.symbols.length)cfg.slots.jackpotIndex=0;}else toast('Mínimo 3 símbolos');}
 else if(a==='tieradd')cfg.roulette.tiers.push({n:'Nuevo',cost:3,boost:30});
 else if(a==='tierdel'){if(cfg.roulette.tiers.length>1)cfg.roulette.tiers.splice(i,1);else toast('Debe quedar al menos un botón');}
 else if(a==='segadd'){if(cfg.roulette.segments.length<40)cfg.roulette.segments.push({l:'?',c:'#b3132a',g:'red',w:1});else toast('Máximo 40 casillas');}
 else if(a==='segdel'){if(cfg.roulette.segments.length>4)cfg.roulette.segments.splice(i,1);else toast('Mínimo 4 casillas');}
 else if(a==='segreset')cfg.roulette.segments=defSegs();
 else if(a==='testwin'){celebrate(false);showWin(1234);return;}
 else if(a==='testjack'){celebrate(true);showWin(9999,{jackpot:true});return;}
 else return;
 const sc=$('#admBody').scrollTop;renderAdmin();$('#admBody').scrollTop=sc;cfgChanged(a.startsWith('sym')?'slots':'roulette');});

/* ================= PELUCHES: datos ================= */
const RARS=['normal','plata','oro','diamante','ultra','mega','unico'];
const RAR={normal:{n:'Normal',c:'#d8d2c0',em:0,ei:0},plata:{n:'Plata',c:'#e4ecf8',em:0xb8c4e0,ei:.16},oro:{n:'Oro',c:'#ffd34a',em:0xffb400,ei:.2},diamante:{n:'Diamante',c:'#6ff0ff',em:0x30d8ff,ei:.22},ultra:{n:'Ultra',c:'#c870ff',em:0xb040ff,ei:.26},mega:{n:'Mega',c:'#ff6a30',em:0xff4010,ei:.28},unico:{n:'Único',c:'#ffffff',em:0xffffff,ei:.3}};
let PL={items:[],next:1,upg:0};
try{const s=localStorage.getItem('loya_plush');if(s)PL=Object.assign(PL,JSON.parse(s));}catch(e){}
const savePL=()=>{try{localStorage.setItem('loya_plush',JSON.stringify(PL));}catch(e){}};
const SPECIES=[
 {k:'amarillo',n:'Pollito Piloto',ico:'🐥',sc:.95},{k:'azul',n:'Alienígena Verde',ico:'👽',sc:.95},{k:'rayo',n:'Zorrito',ico:'🦊',sc:1},{k:'pingu',n:'Pingüino Gorra',ico:'🐧',sc:1},
 {k:'grunon',n:'Oso Rayo',ico:'🐻',sc:.95},{k:'rata',n:'Rata Gentleman',ico:'🐀',sc:.95},{k:'gato',n:'Gato Serio',ico:'🐈‍⬛',sc:1},{k:'perrito',n:'Perrito Nube',ico:'🐶',sc:1},
 {k:'calavera',n:'Conejita Luna',ico:'🐰',sc:.9},{k:'sol',n:'Cultista Sol',ico:'☀️',sc:.9},{k:'sombra',n:'Sombra Máscara',ico:'🎭',sc:.85},{k:'capi',n:'Capibara',ico:'🥭',sc:1.05},
 {k:'shiba',n:'Perro Shiba',ico:'🐕',sc:1},{k:'hongo',n:'Pulpito',ico:'🐙',sc:1},{k:'tripu',n:'Fantasmita',ico:'👻',sc:.95},{k:'avatar',n:'Avatar Rojo',ico:'🧍',sc:.95}];
const GEO={sph:new THREE.SphereGeometry(1,18,14),cyl:new THREE.CylinderGeometry(1,1,1,18),cone:new THREE.ConeGeometry(1,1,16),box:new THREE.BoxGeometry(1,1,1),tor:new THREE.TorusGeometry(1,.2,8,24),dome:new THREE.SphereGeometry(1,20,10,0,TAU,0,Math.PI/2)};
const MC=new Map();
function F(c){const k='f'+c;let m=MC.get(k);if(!m){m=new THREE.MeshStandardMaterial({color:c,roughness:.92,metalness:0});MC.set(k,m);}return m;}
function GL(c,me=.1,ro=.2){const k='g'+c+'_'+me+'_'+ro;let m=MC.get(k);if(!m){m=new THREE.MeshStandardMaterial({color:c,roughness:ro,metalness:me});MC.set(k,m);}return m;}
function PM(g,t,m,sx,sy,sz,x,y,z,rx,ry,rz){const o=new THREE.Mesh(GEO[t],m);o.scale.set(sx,sy,sz);o.position.set(x||0,y||0,z||0);if(rx||ry||rz)o.rotation.set(rx||0,ry||0,rz||0);g.add(o);return o;}
function bead(g,x,y,z,r){PM(g,'sph',F(0x0c0c10),r,r,r,x,y,z);PM(g,'sph',F(0xffffff),r*.3,r*.3,r*.3,x+r*.3,y+r*.4,z+r*.8);}
const B={
amarillo(){const g=new THREE.Group(),y=F(0xf6cf2e),bl=F(0x3a63b8),k=F(0x1a1a1a),w=F(0xffffff),gr=GL(0x9aa0a8,.8,.3);
 PM(g,'cyl',y,.42,.8,.42,0,.62,0);PM(g,'sph',y,.42,.42,.42,0,1.02,0);PM(g,'cyl',bl,.435,.36,.435,0,.3,0);PM(g,'sph',bl,.435,.24,.435,0,.14,0);
 PM(g,'cyl',k,.425,.07,.425,0,1,0);PM(g,'cyl',gr,.2,.2,.2,0,1,.4,Math.PI/2);PM(g,'sph',w,.15,.15,.07,0,1,.56);PM(g,'sph',F(0x6b4a2b),.075,.075,.04,0,1,.62);PM(g,'sph',k,.035,.035,.03,0,1,.65);PM(g,'box',k,.14,.025,.02,0,.8,.41);
 [-1,1].forEach(s=>{PM(g,'cyl',y,.07,.38,.07,s*.5,.62,0,0,0,-s*.45);PM(g,'sph',k,.1,.1,.1,s*.62,.43,0);PM(g,'sph',k,.15,.08,.2,s*.15,.04,.08);});
 for(let i=0;i<5;i++)PM(g,'cyl',k,.012,.2,.012,(i-2)*.07,1.5,0,0,0,(i-2)*.22);return g;},
azul(){const g=new THREE.Group(),b=F(0x4a7fd6),lb=F(0x9cc0f0),pk=F(0xf2a0b8),k=F(0x111111);
 PM(g,'sph',b,.5,.5,.42,0,.5,0);PM(g,'sph',lb,.34,.36,.1,0,.46,.37);PM(g,'sph',b,.52,.46,.46,0,1.1,0);
 [-1,1].forEach(s=>{PM(g,'sph',b,.17,.42,.1,s*.5,1.52,0,0,0,-s*.5);PM(g,'sph',pk,.1,.3,.06,s*.5,1.5,.06,0,0,-s*.5);PM(g,'sph',k,.12,.17,.07,s*.2,1.14,.4);PM(g,'sph',F(0xffffff),.04,.05,.03,s*.2+.03,1.2,.46);PM(g,'sph',b,.13,.2,.13,s*.52,.55,.05,0,0,s*.4);PM(g,'sph',b,.17,.14,.2,s*.2,.09,.12);});
 PM(g,'sph',k,.09,.07,.07,0,1.02,.46);PM(g,'box',F(0x2b1030),.2,.03,.03,0,.9,.45);for(let i=0;i<3;i++)PM(g,'cone',b,.04,.22,.04,(i-1)*.1,1.62,0,0,0,(i-1)*.3);return g;},
rayo(){const g=new THREE.Group(),y=F(0xffd93a),r=F(0xe8352e),k=F(0x1a1a1a),br=F(0x7a4a1c);
 PM(g,'sph',y,.42,.42,.36,0,.48,0);PM(g,'sph',y,.42,.38,.38,0,1,.02);PM(g,'box',br,.3,.04,.02,0,.62,-.33);
 [-1,1].forEach(s=>{PM(g,'sph',y,.12,.42,.07,s*.3,1.5,0,0,0,-s*.3);PM(g,'sph',k,.1,.14,.065,s*.37,1.7,0,0,0,-s*.3);bead(g,s*.17,1.05,.34,.06);PM(g,'sph',r,.09,.09,.04,s*.3,.92,.3);PM(g,'sph',y,.1,.17,.1,s*.42,.5,.05,0,0,s*.4);PM(g,'sph',y,.13,.1,.17,s*.17,.08,.1);});
 PM(g,'sph',k,.035,.03,.03,0,.98,.4);PM(g,'box',y,.4,.1,.08,-.42,.7,-.3,0,0,.6);PM(g,'box',y,.3,.1,.08,-.55,.98,-.3,0,0,-.5);PM(g,'box',y,.4,.1,.08,-.5,1.22,-.3,0,0,.6);return g;},
pingu(){const g=new THREE.Group(),bl=F(0x3d8fd6),lb=F(0x8fd0f0),wh=F(0xeaf6ff),ye=F(0xf4c02b),k=F(0x1d1d22),gr=F(0x6fdc3a);
 PM(g,'sph',lb,.46,.52,.4,0,.5,0);PM(g,'sph',wh,.3,.34,.1,0,.46,.33);PM(g,'sph',bl,.5,.44,.44,0,1.05,0);PM(g,'sph',wh,.16,.2,.08,-.22,1,.36);PM(g,'sph',wh,.16,.2,.08,.22,1,.36);
 bead(g,-.22,1.02,.42,.06);bead(g,.22,1.02,.42,.06);PM(g,'cone',ye,.08,.16,.08,0,.92,.47,Math.PI/2);
 [-1,1].forEach(s=>{PM(g,'sph',bl,.1,.3,.2,s*.5,.6,0,0,0,-s*.5);PM(g,'sph',ye,.14,.05,.18,s*.18,.04,.12);});
 PM(g,'dome',k,.5,.4,.5,0,1.26,-.02,-.12);PM(g,'cyl',gr,.4,.04,.3,0,1.3,.42,.15);PM(g,'cyl',F(0xa6f04a),.1,.01,.1,0,1.42,.4,1.2);return g;},
grunon(){const g=new THREE.Group(),b=F(0x7fa6e8),wh=F(0xf4f8ff),dk=F(0x2f56b0),pk=F(0xf06aa0),br=F(0x14203a);
 PM(g,'sph',b,.46,.5,.4,0,.52,0);PM(g,'cyl',wh,.28,.04,.28,0,.5,.36,Math.PI/2);PM(g,'sph',dk,.1,.08,.04,-.08,.54,.41);PM(g,'sph',dk,.1,.08,.04,.08,.54,.41);PM(g,'sph',dk,.1,.09,.04,0,.6,.41);
 [-.1,0,.1].forEach(x=>PM(g,'sph',pk,.025,.03,.02,x,.4,.4));
 PM(g,'sph',b,.52,.46,.46,0,1.1,0);PM(g,'sph',wh,.22,.18,.14,0,1,.4);PM(g,'sph',dk,.07,.06,.05,0,1.08,.52);
 [-1,1].forEach(s=>{PM(g,'sph',b,.15,.15,.1,s*.38,1.5,0);PM(g,'sph',wh,.08,.08,.05,s*.38,1.5,.06);bead(g,s*.2,1.14,.42,.06);PM(g,'box',br,.18,.035,.03,s*.2,1.27,.43,0,0,s*.4);PM(g,'sph',b,.13,.24,.13,s*.5,.55,.05,0,0,s*.3);PM(g,'sph',b,.17,.12,.22,s*.2,.08,.14);});
 PM(g,'cone',b,.05,.22,.05,0,1.62,0);return g;},
rata(){const g=new THREE.Group(),wh=F(0xf6e8e2),pk=F(0xf0a8b0),k=F(0x14141a),gold=GL(0xe0b030,.9,.25);
 PM(g,'sph',k,.46,.5,.4,0,.5,0);PM(g,'sph',wh,.18,.3,.08,0,.58,.37);PM(g,'cone',k,.08,.14,.05,-.09,.82,.4,0,0,Math.PI/2);PM(g,'cone',k,.08,.14,.05,.09,.82,.4,0,0,-Math.PI/2);PM(g,'sph',k,.035,.035,.03,0,.82,.41);
 PM(g,'sph',wh,.46,.4,.5,0,1.08,.06);PM(g,'sph',wh,.2,.16,.24,0,.98,.4);PM(g,'sph',pk,.05,.045,.04,0,1,.63);
 [-1,1].forEach(s=>{PM(g,'sph',pk,.2,.22,.05,s*.4,1.32,-.02,0,s*.4,0);PM(g,'sph',wh,.1,.1,.1,s*.1,.45,.4);for(let i=0;i<2;i++)PM(g,'cyl',F(0xffffff),.004,.3,.004,s*.4,.98+i*.06,.5,0,0,Math.PI/2+s*(.15-i*.3));});
 bead(g,-.2,1.12,.4,.055);bead(g,.2,1.12,.4,.055);PM(g,'tor',gold,.12,.12,.12,.2,1.12,.46);PM(g,'cyl',gold,.008,.5,.008,.31,.85,.42,0,0,.1);
 PM(g,'cyl',k,.26,.34,.26,0,1.55,.02);PM(g,'cyl',k,.4,.03,.4,0,1.39,.02);PM(g,'cyl',F(0x3a3a44),.265,.06,.265,0,1.44,.02);PM(g,'cyl',pk,.03,.5,.03,.3,.2,-.4,1.2,0,.5);return g;},
gato(){const g=new THREE.Group(),k=F(0x1b1b1f),ye=F(0xc9d36a),pk=F(0xd89aa0),wh=F(0xffffff);
 PM(g,'sph',k,.46,.5,.42,0,.5,0);PM(g,'sph',k,.5,.42,.44,0,1.08,.02);
 [-1,1].forEach(s=>{PM(g,'cone',k,.17,.3,.07,s*.32,1.5,0,0,0,-s*.25);PM(g,'cone',pk,.08,.18,.04,s*.32,1.48,.04,0,0,-s*.25);PM(g,'sph',ye,.1,.07,.05,s*.2,1.1,.38);PM(g,'box',k,.012,.07,.01,s*.2,1.1,.43);PM(g,'box',k,.2,.06,.04,s*.2,1.16,.41,0,0,s*.14);PM(g,'sph',k,.12,.1,.14,s*.18,.1,.3);
  for(let i=0;i<2;i++)PM(g,'cyl',wh,.004,.3,.004,s*.42,.98+i*.05,.42,0,0,Math.PI/2+s*(.12-i*.24));});
 PM(g,'sph',F(0x5a3a3a),.05,.035,.03,0,1,.45);PM(g,'tor',k,.28,.28,.28,.48,.3,-.2,0,1.2,0);return g;},
perrito(){const g=new THREE.Group(),wh=F(0xfbfbfb),rd=F(0xe85a50),k=F(0x2a2a30);
 PM(g,'sph',rd,.36,.4,.32,0,.38,0);PM(g,'sph',wh,.52,.44,.46,0,1,0);PM(g,'cone',k,.06,.34,.06,0,1.55,0,-.1);
 [-1,1].forEach(s=>{PM(g,'sph',k,.12,.2,.08,s*.46,1.02,0,0,0,-s*.4);bead(g,s*.22,1.04,.4,.045);PM(g,'sph',wh,.1,.18,.1,s*.4,.45,.08,0,0,s*.5);PM(g,'sph',wh,.13,.12,.18,s*.15,.06,.1);});
 PM(g,'sph',k,.05,.04,.04,0,.97,.46);return g;},
calavera(){const g=new THREE.Group(),k=F(0x1c1c22),wh=F(0xf4eee8),pk=F(0xf080b8);
 PM(g,'sph',k,.44,.44,.36,0,.42,0);PM(g,'cyl',wh,.2,.05,.2,0,.72,.05);PM(g,'sph',k,.52,.46,.46,0,1.02,0);PM(g,'sph',wh,.34,.3,.1,0,.98,.4);PM(g,'sph',pk,.11,.1,.05,0,1.32,.44);PM(g,'sph',k,.02,.02,.02,-.04,1.33,.49);PM(g,'sph',k,.02,.02,.02,.04,1.33,.49);
 [-1,1].forEach(s=>{PM(g,'cone',k,.15,.55,.1,s*.34,1.55,0,0,0,-s*.35);PM(g,'cone',pk,.07,.35,.06,s*.34,1.5,.05,0,0,-s*.35);PM(g,'sph',k,.06,.07,.04,s*.15,1,.5);PM(g,'sph',pk,.05,.03,.02,s*.24,.9,.5);PM(g,'sph',wh,.1,.1,.1,s*.36,.45,.12);PM(g,'sph',k,.13,.1,.18,s*.15,.06,.1);});return g;},
sol(){const g=new THREE.Group(),k=F(0x0e0e12),go=GL(0xe2b449,.8,.3);
 PM(g,'cone',k,.62,1.1,.62,0,.55,0);PM(g,'tor',go,.49,.49,.3,0,.25,0,Math.PI/2);PM(g,'tor',go,.28,.28,.3,0,.62,0,Math.PI/2);PM(g,'sph',go,.3,.3,.28,0,1.18,0);
 for(let i=0;i<12;i++){const a=i/12*TAU;PM(g,'cone',go,.05,.4,.05,Math.cos(a)*.5,1.18+Math.sin(a)*.5,-.05,0,0,a-Math.PI/2);}
 [-1,1].forEach(s=>{PM(g,'box',k,.08,.02,.02,s*.1,1.22,.27);PM(g,'sph',go,.07,.07,.07,s*.14,.65,.38);});PM(g,'box',k,.1,.015,.02,0,1.08,.28);return g;},
sombra(){const g=new THREE.Group(),k=F(0x0e0e12),m=F(0xd0d0d6);
 PM(g,'cone',k,.6,1.25,.6,0,.62,0);PM(g,'sph',k,.36,.4,.34,0,1.15,0);PM(g,'sph',m,.17,.23,.1,0,1.12,.27);
 [-1,1].forEach(s=>{PM(g,'sph',k,.03,.035,.02,s*.06,1.15,.36);PM(g,'cone',F(0xf4f4f4),.04,.12,.03,s*.42,.1,.3,0,0,-s*.3);});
 PM(g,'sph',k,.025,.03,.02,0,1.05,.37);for(let i=0;i<5;i++)PM(g,'cone',k,.035,.5+(i%2?0:.15),.035,(i-2)*.12,1.6,0,0,0,(i-2)*.22);
 PM(g,'cyl',F(0xc01830),.09,.02,.09,0,.65,.3,Math.PI/2-.25);return g;},
capi(){const g=new THREE.Group(),br=F(0xa87a4a),dk=F(0x5a3a22);
 PM(g,'sph',br,.5,.4,.62,0,.45,-.05);PM(g,'sph',br,.34,.32,.4,0,.78,.5);PM(g,'sph',br,.26,.22,.2,0,.72,.78);PM(g,'sph',dk,.12,.07,.06,0,.8,.94);
 [-1,1].forEach(s=>{bead(g,s*.18,.9,.72,.045);PM(g,'sph',br,.06,.07,.04,s*.22,1.08,.38);PM(g,'cyl',br,.09,.25,.09,s*.3,.12,.3);PM(g,'cyl',br,.09,.25,.09,s*.3,.12,-.4);});
 PM(g,'sph',F(0xf08a24),.12,.11,.12,0,1.12,.5);PM(g,'sph',F(0x3a9a3a),.05,.015,.05,0,1.22,.5);return g;},
shiba(){const g=new THREE.Group(),be=F(0xe2a95e),wh=F(0xfbf1de),k=F(0x1a1a1a);
 PM(g,'sph',be,.42,.44,.4,0,.42,0);PM(g,'sph',wh,.26,.3,.1,0,.38,.34);PM(g,'sph',be,.56,.46,.5,0,1,.04);PM(g,'sph',wh,.22,.16,.2,0,.9,.46);PM(g,'sph',k,.06,.045,.04,0,.97,.64);
 [-1,1].forEach(s=>{PM(g,'sph',wh,.22,.2,.22,s*.3,.9,.34);bead(g,s*.2,1.1,.42,.05);PM(g,'cone',be,.16,.3,.08,s*.34,1.48,0,0,0,-s*.15);PM(g,'cone',wh,.08,.18,.05,s*.34,1.46,.03,0,0,-s*.15);PM(g,'sph',F(0x8a5a2a),.03,.03,.02,s*.2,1.2,.46);PM(g,'sph',wh,.1,.1,.1,s*.15,.06,.12);});
 PM(g,'tor',be,.2,.2,.3,0,.7,-.4,0,Math.PI/2);return g;},
hongo(){const g=new THREE.Group(),st=F(0xf5e6c8),rd=F(0xd8302a),wh=F(0xffffff);
 PM(g,'cyl',st,.3,.6,.3,0,.3,0);PM(g,'dome',rd,.62,.5,.62,0,.55,0);PM(g,'cyl',rd,.62,.06,.62,0,.55,0);
 [[0,1.04,0,.12],[.3,.9,.2,.1],[-.3,.92,.1,.1],[.05,.85,.45,.09],[-.35,.7,.35,.08],[.4,.7,-.1,.08]].forEach(d=>PM(g,'sph',wh,d[3],d[3]*.4,d[3],d[0],d[1],d[2]));
 [-1,1].forEach(s=>{bead(g,s*.1,.4,.3,.045);PM(g,'sph',F(0xf0d8b0),.15,.07,.18,s*.13,.06,.1);});return g;},
tripu(){const g=new THREE.Group(),rd=F(0xd8302c),vi=GL(0x7fd8f0,.6,.15),dk=F(0x9c1c18);
 PM(g,'cyl',rd,.42,.75,.42,0,.62,0);PM(g,'sph',rd,.42,.42,.42,0,1,0);PM(g,'sph',vi,.3,.2,.12,0,1.05,.34);PM(g,'box',dk,.32,.5,.14,0,.65,-.44);
 [-1,1].forEach(s=>PM(g,'cyl',rd,.16,.25,.16,s*.2,.14,0));return g;},
avatar(){const g=new THREE.Group(),sk=F(0xf0d0b0),hr=F(0x5a1414),k=F(0x14141a),rd=F(0x8a1a20);
 PM(g,'box',sk,.4,.4,.4,0,1.15,0);PM(g,'sph',hr,.26,.3,.24,0,1.2,-.05);PM(g,'box',hr,.42,.1,.1,0,1.32,.18);PM(g,'cyl',k,.24,.08,.24,0,1.4,0);PM(g,'cyl',k,.28,.03,.3,0,1.37,.14);
 [-1,1].forEach(s=>{PM(g,'box',hr,.1,.5,.1,s*.24,.95,0);PM(g,'sph',F(0x6a7a8a),.045,.045,.03,s*.1,1.15,.21);PM(g,'box',sk,.1,.36,.1,s*.26,.78,0);PM(g,'box',rd,.16,.46,.16,s*.1,.24,0);});
 PM(g,'box',k,.36,.42,.2,0,.78,0);return g;}};
function tint(body,rar){const r=RAR[rar],mats=[];if(!r.ei)return mats;body.traverse(o=>{if(o.isMesh){if(o.material.userData&&o.material.userData.glow)return;o.material=o.material.clone();o.material.emissive=new THREE.Color((cfg.plush.aura&&cfg.plush.aura[rar])||r.em);o.material.emissiveIntensity=r.ei;o.userData.own=true;mats.push(o.material);}});return mats;}
let GLOWT=null;function glowT(){if(!GLOWT)GLOWT=glowTex();return GLOWT;}
let STAR4=null,PILLT=null,RAYS2=null;const RUNES={};
function star4T(){if(STAR4)return STAR4;const c=document.createElement('canvas');c.width=c.height=64;const g=c.getContext('2d');g.translate(32,32);const gr=g.createRadialGradient(0,0,0,0,0,30);gr.addColorStop(0,'rgba(255,255,255,1)');gr.addColorStop(.3,'rgba(255,255,255,.5)');gr.addColorStop(1,'rgba(255,255,255,0)');g.fillStyle=gr;g.beginPath();for(let i=0;i<8;i++){const a=i*Math.PI/4,r=i%2?5:30;g.lineTo(Math.cos(a)*r,Math.sin(a)*r);}g.closePath();g.fill();return STAR4=new THREE.CanvasTexture(c);}
function raysT2(){if(RAYS2)return RAYS2;const c=document.createElement('canvas');c.width=c.height=256;const g=c.getContext('2d');g.translate(128,128);const gr=g.createRadialGradient(0,0,0,0,0,128);gr.addColorStop(0,'rgba(255,255,255,.95)');gr.addColorStop(.6,'rgba(255,255,255,.4)');gr.addColorStop(1,'rgba(255,255,255,0)');g.fillStyle=gr;for(let i=0;i<16;i++){g.rotate(TAU/16);g.beginPath();g.moveTo(0,0);g.lineTo(128,-7);g.lineTo(128,7);g.closePath();g.fill();}return RAYS2=new THREE.CanvasTexture(c);}
function pillarT(){if(PILLT)return PILLT;const c=document.createElement('canvas');c.width=16;c.height=128;const g=c.getContext('2d'),gr=g.createLinearGradient(0,128,0,0);gr.addColorStop(0,'rgba(255,255,255,.95)');gr.addColorStop(.5,'rgba(255,255,255,.35)');gr.addColorStop(1,'rgba(255,255,255,0)');g.fillStyle=gr;g.fillRect(0,0,16,128);return PILLT=new THREE.CanvasTexture(c);}
function runeT(sym){if(RUNES[sym])return RUNES[sym];const c=document.createElement('canvas');c.width=c.height=256;const g=c.getContext('2d');g.translate(128,128);g.strokeStyle='#fff';g.fillStyle='#fff';
 [120,108,70].forEach((r,i)=>{g.lineWidth=i===1?1.5:3;g.beginPath();g.arc(0,0,r,0,TAU);g.stroke();});
 for(let i=0;i<48;i++){const a=i/48*TAU,l=i%4?114:120;g.lineWidth=i%4?1:3;g.beginPath();g.moveTo(Math.cos(a)*108,Math.sin(a)*108);g.lineTo(Math.cos(a)*l,Math.sin(a)*l);g.stroke();}
 g.lineWidth=2.5;const poly=(n,r,rot)=>{g.beginPath();for(let i=0;i<=n;i++){const a=rot+i/n*TAU;g.lineTo(Math.cos(a)*r,Math.sin(a)*r);}g.stroke();};
 if(sym==='hex'){poly(3,70,-Math.PI/2);poly(3,70,Math.PI/2);}else if(sym==='star'){g.beginPath();for(let i=0;i<=5;i++){const a=-Math.PI/2+i*TAU*2/5;g.lineTo(Math.cos(a)*70,Math.sin(a)*70);}g.stroke();}else poly(8,70,0);
 for(let i=0;i<8;i++){const a=i/8*TAU;g.beginPath();g.arc(Math.cos(a)*90,Math.sin(a)*90,4,0,TAU);g.fill();}
 return RUNES[sym]=new THREE.CanvasTexture(c);}
const AUR={
 plata:{c:'#dde8ff',gl:.3,s:2.4,circle:{r:1.1,sym:'ring'},spark:{n:14}},
 oro:{c:'#ffc83a',gl:.45,s:2.9,rays:.25,circle:{r:1.25,sym:'star'},spark:{n:24},pulse:1},
 diamante:{c:'#6ff0ff',gl:.5,s:3,rays:.2,circle:{r:1.35,sym:'hex'},spark:{n:30},pulse:1,pillar:.35,orbit:5},
 ultra:{c:'#c060ff',gl:.6,s:3.4,rays:.3,circle:{r:1.5,sym:'hex'},helix:true,spark:{n:40},pulse:1,pillar:.45,orbit:6,rings:2},
 mega:{c:'#ff5a1e',gl:.7,s:3.8,rays:.3,circle:{r:1.5,sym:'star'},fire:true,spark:{n:56},pulse:1,pillar:.55,rings:1},
 unico:{c:'#ffffff',gl:.85,s:4.4,rays:.4,circle:{r:1.7,sym:'hex'},helix:true,rainbow:true,spark:{n:64},pulse:1,pillar:.6,orbit:10,rings:3}};
function auraCol(rar){const o=cfg.plush.aura&&cfg.plush.aura[rar];return new THREE.Color(o||(AUR[rar]?AUR[rar].c:'#ffffff'));}
function buildAura(rar,mats){const A=AUR[rar];if(!A)return null;const I=cfg.plush.auraI==null?1:cfg.plush.auraI,col=auraCol(rar),hs={};col.getHSL(hs);const g=new THREE.Group();
 const sp=(map,color,op)=>new THREE.Sprite(new THREE.SpriteMaterial({map,color:color.clone(),transparent:true,opacity:op,blending:THREE.AdditiveBlending,depthWrite:false}));
 const mb=(map,color,op)=>new THREE.MeshBasicMaterial({map,color:color.clone(),transparent:true,opacity:op,blending:THREE.AdditiveBlending,depthWrite:false,side:THREE.DoubleSide});
 const glow=sp(glowT(),col,A.gl*I);glow.scale.set(A.s,A.s,1);glow.position.set(0,.8,-.35);g.add(glow);
 let rays=null;if(A.rays){rays=sp(raysT2(),col,A.rays*I);rays.scale.set(A.s*1.7,A.s*1.7,1);rays.position.set(0,.8,-.4);g.add(rays);}
 const circ=new THREE.Mesh(new THREE.PlaneGeometry(1,1),mb(runeT(A.circle.sym),col,Math.min(1,.8*I)));circ.rotation.x=-Math.PI/2;circ.position.y=.03;circ.scale.set(A.circle.r*2,A.circle.r*2,1);g.add(circ);
 let pil=null;if(A.pillar){pil=new THREE.Mesh(new THREE.CylinderGeometry(.55,.85,3.4,28,1,true),mb(pillarT(),col,A.pillar*I));pil.position.y=1.7;g.add(pil);}
 const waves=[];if(A.pulse)for(let i=0;i<2;i++){const w=new THREE.Mesh(new THREE.RingGeometry(.9,1,48),mb(null,col,.6));w.rotation.x=-Math.PI/2;w.position.y=.04;g.add(w);waves.push(w);}
 const rings=[];for(let i=0;i<(A.rings||0);i++){const r=new THREE.Mesh(new THREE.TorusGeometry(1+i*.14,.016,8,72),mb(null,col,.75));r.position.y=.85;g.add(r);rings.push(r);}
 const n=A.spark.n,pos=new Float32Array(n*3),colr=new Float32Array(n*3),pr=[];for(let i=0;i<n;i++)pr.push({a:rnd(0,TAU),r:rnd(.55,1.15),s:rnd(.6,1.4),p:rnd(0,1)});
 const geo=new THREE.BufferGeometry();geo.setAttribute('position',new THREE.BufferAttribute(pos,3));geo.setAttribute('color',new THREE.BufferAttribute(colr,3));
 const pts=new THREE.Points(geo,new THREE.PointsMaterial({size:A.fire?.22:.15,map:glowT(),vertexColors:true,transparent:true,depthWrite:false,blending:THREE.AdditiveBlending,sizeAttenuation:true,opacity:Math.min(1,.9*I)}));pts.frustumCulled=false;g.add(pts);
 const stars=[];for(let i=0;i<(A.orbit||0);i++){const s=sp(star4T(),col,.95);s.scale.setScalar(.34);g.add(s);stars.push({s,a:i/A.orbit*TAU,t:rnd(.7,1.3),h:rnd(.2,1.5),r:rnd(.95,1.3)});}
 g.traverse(o=>{if(o.material)o.userData.own=true;});
 const tmp=new THREE.Color();
 return{group:g,update(t){
  const hue=A.rainbow?(t*.22)%1:0;
  if(A.rainbow){tmp.setHSL(hue,1,.6);glow.material.color.copy(tmp);if(rays)rays.material.color.copy(tmp);circ.material.color.copy(tmp);if(pil)pil.material.color.copy(tmp);rings.forEach((r,i)=>r.material.color.setHSL((hue+i*.18)%1,1,.6));waves.forEach(w=>w.material.color.copy(tmp));stars.forEach((q,i)=>q.s.material.color.setHSL((hue+i/stars.length)%1,1,.7));mats.forEach(m=>m.emissive.setHSL(hue,1,.5));}
  const pu=1+Math.sin(t*3)*.08;glow.scale.set(A.s*pu,A.s*pu,1);glow.material.opacity=A.gl*I*(.85+.15*Math.sin(t*2.3));
  if(rays)rays.material.rotation=t*.45;circ.rotation.z=t*.4;
  if(pil){pil.material.opacity=A.pillar*I*(.8+.2*Math.sin(t*3));pil.scale.y=1+.08*Math.sin(t*2);}
  waves.forEach((w,i)=>{const p=(t*.6+i*.5)%1;w.scale.setScalar(.6+p*1.4*A.circle.r);w.material.opacity=(1-p)*.55*Math.min(1,I);});
  rings.forEach((r,i)=>{r.rotation.x=1.2+Math.sin(t*(.6+i*.3)+i)*.8;r.rotation.y=t*(.7+i*.4);});
  const arr=geo.attributes.position.array,car=geo.attributes.color.array;
  for(let i=0;i<n;i++){const p=pr[i],prog=(((t*.35*p.s+p.p)%1)+1)%1,f=Math.sin(prog*Math.PI);let x,y,z;
   if(A.fire){y=prog*2.1;const rr=p.r*(1-prog*.85)*.8,a=p.a+t*p.s*.8;x=Math.cos(a)*rr;z=Math.sin(a)*rr;tmp.setHSL(hs.h+prog*.08,1,.5+.2*(1-prog));const k=1-prog*.6;car[i*3]=tmp.r*k;car[i*3+1]=tmp.g*k;car[i*3+2]=tmp.b*k;}
   else if(A.helix){const a=p.a+t*1.2*p.s+prog*TAU,rr=(.6+.4*f)*(.9+p.r*.2);y=prog*2;x=Math.cos(a)*rr;z=Math.sin(a)*rr;if(A.rainbow)tmp.setHSL((hue+prog)%1,1,.6);else tmp.copy(col);car[i*3]=tmp.r*f;car[i*3+1]=tmp.g*f;car[i*3+2]=tmp.b*f;}
   else{y=prog*1.8;const a=p.a+t*.6*p.s;x=Math.cos(a)*p.r;z=Math.sin(a)*p.r;car[i*3]=col.r*f;car[i*3+1]=col.g*f;car[i*3+2]=col.b*f;}
   arr[i*3]=x;arr[i*3+1]=y;arr[i*3+2]=z;}
  geo.attributes.position.needsUpdate=true;geo.attributes.color.needsUpdate=true;
  stars.forEach((q,i)=>{const a=q.a+t*q.t;q.s.position.set(Math.cos(a)*q.r,q.h+Math.sin(a*2)*.1+.4,Math.sin(a)*q.r*.9);q.s.scale.setScalar(.28+.14*Math.sin(t*5+i*2));});}};}
/*PLUSH_BEGIN*/
const GSPH=new THREE.SphereGeometry(1,24,16),GSPS=new THREE.SphereGeometry(1,10,8),GCYL=new THREE.CylinderGeometry(1,1,1,18),GCONE=new THREE.ConeGeometry(1,1,12),GBOX=new THREE.BoxGeometry(1,1,1),GTOR=new THREE.TorusGeometry(1,.1,8,32),GOCT=new THREE.OctahedronGeometry(1,0),GTAP=new THREE.CylinderGeometry(.5,1,1,22),GTAP2=new THREE.CylinderGeometry(1,.55,1,18);
const mcache={};
function FM(c,r,m,e,ei,glow){const k=[c,r,m,e,ei].join('_');if(mcache[k])return mcache[k];const o={color:c,roughness:r,metalness:m,vertexColors:true};if(e!=null){o.emissive=e;o.emissiveIntensity=ei||1;}const mt=new THREE.MeshStandardMaterial(o);if(glow)mt.userData.glow=true;return mcache[k]=mt;}
const LAC=c=>FM(c,.25,.4),GLD=()=>FM(0xe2b449,.22,.95),GLD2=()=>FM(0xa8761a,.3,.9),POR=c=>FM(c==null?0xe9e4da:c,.38,.08),GLO=c=>FM(c,.3,0,c,1.3,true),DRK=()=>FM(0x0b0b10,.2,.5);
function PA(par,geo,mat,x,y,z,sx,sy,sz,rx,ry,rz){if(sy==null)sy=sx;if(sz==null)sz=sx;if(geo===GSPH&&Math.max(sx,sy,sz)<.14)geo=GSPS;const m=new THREE.Mesh(geo,mat);m.position.set(x||0,y||0,z||0);m.scale.set(sx,sy,sz);m.rotation.set(rx||0,ry||0,rz||0);par.add(m);return m;}
function bake(grp){grp.children.filter(c=>c.isGroup).forEach(bake);const ms=grp.children.filter(c=>c.isMesh);if(!ms.length)return;const by=new Map();
 ms.forEach(m=>{m.updateMatrix();const g=m.geometry.clone();g.applyMatrix4(m.matrix);if(!by.has(m.material))by.set(m.material,[]);by.get(m.material).push(g);grp.remove(m);});
 by.forEach((arr,mat)=>{let nv=0,ni=0;arr.forEach(g=>{nv+=g.attributes.position.count;ni+=g.index?g.index.count:g.attributes.position.count;});
  const pos=new Float32Array(nv*3),nor=new Float32Array(nv*3),uv=new Float32Array(nv*2),idx=nv<65535?new Uint16Array(ni):new Uint32Array(ni);let vo=0,io=0;
  arr.forEach(g=>{pos.set(g.attributes.position.array,vo*3);nor.set(g.attributes.normal.array,vo*3);uv.set(g.attributes.uv.array,vo*2);const cn=g.attributes.position.count;if(g.index){const ix=g.index.array;for(let i=0;i<ix.length;i++)idx[io+i]=ix[i]+vo;io+=ix.length;}else{for(let i=0;i<cn;i++)idx[io+i]=vo+i;io+=cn;}vo+=cn;g.dispose();});
  const col=new Float32Array(nv*3);for(let i=0;i<nv;i++){const sh=.68+.32*(nor[i*3+1]*.5+.5);col[i*3]=col[i*3+1]=col[i*3+2]=sh;}
  const geo=new THREE.BufferGeometry();geo.setAttribute('color',new THREE.BufferAttribute(col,3));geo.setAttribute('position',new THREE.BufferAttribute(pos,3));geo.setAttribute('normal',new THREE.BufferAttribute(nor,3));geo.setAttribute('uv',new THREE.BufferAttribute(uv,2));geo.setIndex(new THREE.BufferAttribute(idx,1));
  grp.add(new THREE.Mesh(geo,mat));});}
const RIGS=[];
function finishPlush(g,rig){bake(g);g.updateMatrixWorld(true);const w=new THREE.Group();w.add(g);const b=new THREE.Box3().setFromObject(g),h=Math.max(.1,b.max.y-b.min.y),k=1.6/h;g.scale.setScalar(k);g.position.y=-b.min.y*k;
 rig=rig||{};rig.k=k;rig.g=g;rig.ph=Math.random()*6.28;w.userData.rig=rig;RIGS.push(w);return w;}
function mkG(par,x,y,z){const q=new THREE.Group();q.position.set(x,y,z);par.add(q);return q;}
const FIG={
 rata:{type:'suit',body:0x0e0e14,head:'rat',face:0xefe6dc,eye:0xffd36b,tail:'chain',bow:1},
 gato:{type:'suit',body:0x0a0a0e,head:'cat',eye:0x9cff4a,tail:'chain'},
 capi:{type:'orb',body:0x6b3f1c,head:'capy',eye:0xffb347},
 shiba:{type:'suit',body:0x1a1208,head:'shiba',face:0xfff0d8,fur:0xe0852a,eye:0xffd36b,tail:'fox'},
 perrito:{type:'robe',body:0xf0ece4,head:'pup',face:0xf6f2ea,fur:0x15151a,eye:0xb59cff},
 calavera:{type:'robe',body:0x14101e,head:'rabbit',eye:0xc7a8ff},
 rayo:{type:'suit',body:0x1a0d06,head:'fox',face:0xfff0d8,fur:0xe8721e,eye:0xffe08a,tail:'fox'},
 grunon:{type:'robe',body:0x3a2a8a,head:'bear',face:0xe8e4ff,eye:0xffd84a,bolt:1},
 pingu:{type:'orb',body:0x101a40,head:'penguin',belly:0xf4f1ea,eye:0xffffff},
 amarillo:{type:'orb',body:0xe0aa22,head:'chick',eye:0xaee7ff},
 azul:{type:'suit',body:0x08140e,head:'alien',eye:0x6dff9a,stripe:0x6dff9a},
 sol:{type:'suit',body:0x0b0b10,head:'sun',eye:0xffd36b},
 sombra:{type:'robe',body:0x08080c,head:'mask',face:0xd6d6dc,eye:0xff6a5a},
 hongo:{type:'orb',body:0xa81c66,head:'octo',eye:0xffd36b,tent:1},
 tripu:{type:'ghost',body:0xf3f0ea,head:'ghost',eye:0xffd36b},
 avatar:{type:'suit',body:0x14101a,head:'block',face:0xf0d4b4,eye:0x6dd6ff,stripe:0xd12a3a}
};
function buildFigure(f){
 const g=new THREE.Group(),rig={spin:[]},G=GLD(),G2=GLD2(),DK=DRK(),B=f.type==='ghost'?POR(f.body):LAC(f.body),eye=GLO(f.eye||0xffd36b),P=(geo,mat,x,y,z,sx,sy,sz,rx,ry,rz)=>PA(g,geo,mat,x,y,z,sx,sy,sz,rx,ry,rz),t=f.type;
 P(GCYL,G2,0,.05,0,.52,.1,.52);P(GCYL,DK,0,.105,0,.46,.02,.46);P(GTOR,G,0,.1,0,.5,.5,.5,Math.PI/2);for(let i=0;i<8;i++){const a=i/8*TAU;P(GSPH,G,Math.cos(a)*.5,.06,Math.sin(a)*.5,.04);}
 let headY=1.45;
 const arm=(s,x,y)=>{const A_=mkG(g,x,y,0.02);if(s<0)rig.armL=A_;else rig.armR=A_;return A_;};
 if(t==='robe'){headY=1.42;P(GTAP,B,0,.66,0,.5,1.12,.5);P(GTOR,G,0,.14,0,.5,.5,.5,Math.PI/2);P(GTOR,G,0,.66,0,.38,.38,.38,Math.PI/2);for(let i=0;i<10;i++){const a=i/10*TAU;P(GCONE,G,Math.cos(a)*.5,.16,Math.sin(a)*.5,.035,.12,.035);}
  for(let k=-2;k<=2;k++)P(GBOX,G,k*.065,.8,.3-Math.abs(k)*.012,.01,.62,.012);P(GOCT,GLO(f.eye||0xffd36b),0,.92,.29,.06,.09,.04);
  if(f.bolt){const y=FM(0xffe14a,.3,.6);P(GBOX,y,.02,.55,.37,.05,.15,.02,0,0,.5);P(GBOX,y,-.02,.43,.37,.05,.15,.02,0,0,.5);}
  [-1,1].forEach(s=>{const A_=arm(s,s*.27,1.12);A_.rotation.z=-s*.12;PA(A_,GCONE,B,0,-.3,0,.13,.6,.13);PA(A_,GTOR,G,0,-.6,0,.13,.13,.13,Math.PI/2);PA(A_,GSPH,POR(0xe9e4da),0,-.67,0,.06);});}
 else if(t==='suit'){headY=1.55;const st=FM(f.stripe||0xe2b449,.3,.9);
  [-1,1].forEach(s=>{P(GCYL,B,s*.1,.42,0,.045,.62,.045);P(GSPH,G,s*.1,.42,0,.06);P(GBOX,G,s*.1,.13,.06,.1,.05,.18);P(GSPH,G,s*.1,.74,0,.06);});
  P(GTAP2,B,0,1.0,0,.3,.55,.2);for(let k=-2;k<=2;k++)P(GBOX,st,k*.07,1.0,.185,.008,.5,.01);P(GCONE,G,0,.97,.19,.05,.3,.02,Math.PI,0,0);P(GOCT,GLO(f.eye||0xffd36b),0,1.1,.19,.04,.06,.03);P(GCYL,G,0,1.3,0,.1,.08,.1);
  if(f.bow){const bb=FM(0xe2b449,.3,.9);P(GCONE,bb,-.07,1.32,.1,.06,.11,.03,0,0,-Math.PI/2);P(GCONE,bb,.07,1.32,.1,.06,.11,.03,0,0,Math.PI/2);P(GSPH,bb,0,1.32,.11,.03);}
  [-1,1].forEach(s=>{const A_=arm(s,s*.32,1.22);A_.rotation.z=-s*.1;PA(A_,GSPH,G,0,0,0,.07);PA(A_,GCYL,B,0,-.18,0,.04,.34,.04);PA(A_,GSPH,G,0,-.36,0,.055);PA(A_,GCYL,B,0,-.55,0,.036,.36,.036);PA(A_,GSPH,G,0,-.75,0,.06);[-1,0,1].forEach(k=>PA(A_,GCONE,G,k*.03,-.83,0,.014,.1,.014,Math.PI,0,0));});}
 else if(t==='orb'){headY=1.27;P(GSPH,B,0,.64,0,.5,.52,.46);P(GTOR,G,0,.64,0,.51,.51,.51,Math.PI/2);P(GTOR,G,0,.64,0,.52,.52,.52);if(f.belly)P(GSPH,POR(f.belly),0,.58,.32,.3,.36,.14);
  [-1,1].forEach(s=>{P(GCONE,G,s*.2,.15,.3,.09,.22,.09,Math.PI/2,0,0);const A_=arm(s,s*.5,.78);A_.rotation.z=-s*.5;PA(A_,GSPH,B,0,-.1,0,.1,.2,.1);PA(A_,GSPH,G,0,-.28,0,.06);});
  if(f.tent)for(let i=0;i<8;i++){const a=i/8*TAU+.2;P(GSPH,B,Math.cos(a)*.4,.18,Math.sin(a)*.4,.1,.2,.1);P(GSPH,G,Math.cos(a)*.45,.07,Math.sin(a)*.45,.05);}}
 else{headY=1.2;P(GTAP,B,0,.62,0,.5,1.04,.5);P(GTOR,G,0,.14,0,.5,.5,.5,Math.PI/2);for(let i=0;i<10;i++){const a=i/10*TAU;P(GSPH,G,Math.cos(a)*.5,.12,Math.sin(a)*.5,.045);}
  [-1,1].forEach(s=>{const A_=arm(s,s*.28,.95);PA(A_,GSPH,B,0,-.08,0,.1,.18,.1,0,0,-s*.4);});P(GOCT,GLO(f.eye||0xffd36b),0,.7,.3,.06,.09,.04);}
 const H=mkG(g,0,headY,0),PH=(geo,mat,x,y,z,sx,sy,sz,rx,ry,rz)=>PA(H,geo,mat,x,y,z,sx,sy,sz,rx,ry,rz);rig.head=H;
 const EG=mkG(H,0,.04,0),PE=(geo,mat,x,y,z,sx,sy,sz,rx,ry,rz)=>PA(EG,geo,mat,x,y-.04,z,sx,sy,sz,rx,ry,rz);rig.eyes=EG;
 const fc=POR(f.face),fur=LAC(f.fur==null?f.body:f.fur);let HE=null;
 const hd=(mat,rx,ry,rz,cz,cy)=>{cz=cz||0;cy=cy||0;PH(GSPH,mat,0,cy,cz,rx,ry,rz);HE={rx,ry,rz,cz,cy};};
 const sz=(x,y)=>{const q=1-Math.pow(x/HE.rx,2)-Math.pow((y-HE.cy)/HE.ry,2);return HE.cz+HE.rz*Math.sqrt(Math.max(0,q))+.012;};
 const slits=(w,h,sep,y,rot,mat)=>[-1,1].forEach(s=>PE(GBOX,mat||eye,s*sep,y,sz(sep,y),w,h,.024,0,0,-s*rot));
 const ear=(s,x,y,fn)=>{const q=mkG(H,s*x,y,0);fn(q,s);if(s<0)rig.earL=q;else rig.earR=q;};
 const whisk=(y,len)=>[-1,1].forEach(s=>[0,1,2].forEach(k=>PH(GBOX,G,s*.28,y-k*.035,.18,len,.006,.006,0,0,s*(.15-k*.15))));
 const hf=f.head;
 if(hf==='rat'){hd(fc,.27,.3,.26,.02);PH(GCONE,fc,0,-.06,.3,.1,.34,.1,Math.PI/2,0,0);PH(GSPH,DK,0,-.06,.47,.03);slits(.1,.034,.11,.07,.25);
  [-1,1].forEach(s=>ear(s,.22,.26,(q)=>{PA(q,GCYL,G,0,0,0,.14,.025,.14,Math.PI/2);PA(q,GCYL,FM(0xf2b6b0,.5,.1),0,0,.014,.11,.02,.11,Math.PI/2);}));whisk(-.08,.26);
  const h=mkG(H,0,.3,0);h.rotation.z=-.1;PA(h,GCYL,DK,0,.22,0,.19,.44,.19);PA(h,GCYL,DK,0,0,0,.34,.03,.34);PA(h,GCYL,G,0,.06,0,.2,.07,.2);PA(h,GBOX,G,0,.06,.2,.07,.07,.012);
  PH(GTOR,G,.12,.08,sz(.12,.08)+.01,.09,.09,.09);PH(GCYL,FM(0xcfeaff,.1,.1,0x88ccff,.4,true),.12,.08,sz(.12,.08)+.005,.08,.012,.08,Math.PI/2);PH(GCYL,G,.2,-.08,.22,.006,.22,.006,0,0,.25);}
 else if(hf==='cat'){hd(LAC(f.body),.3,.27,.27);[-1,1].forEach(s=>ear(s,.2,.22,(q)=>{PA(q,GCONE,LAC(f.body),0,.16,0,.11,.32,.07,0,0,-s*.2);PA(q,GCONE,G,0,.27,0,.045,.12,.03,0,0,-s*.2);}));
  slits(.13,.03,.12,.05,-.18);PH(GOCT,G,0,-.04,sz(0,-.04)+.01,.03,.025,.02);whisk(-.07,.3);PH(GTOR,FM(0xc0392b,.5,.2),0,-.24,0,.2,.2,.2,Math.PI/2);PH(GSPH,G,0,-.3,.2,.05);PH(GBOX,DK,0,.02,sz(0,.02)+.002,.002,.001,.001);}
 else if(hf==='shiba'||hf==='pup'){const pup=hf==='pup';hd(pup?fc:fur,.29,.27,.27);PH(GSPH,fc,0,-.1,.2,.15,.11,.12);PH(GSPH,DK,0,-.05,.32,.04,.03,.03);slits(.1,.03,.12,.07,pup?.05:.2);
  [-1,1].forEach(s=>ear(s,.2,.2,(q)=>{if(pup){PA(q,GSPH,fur,s*.1,-.12,0,.1,.22,.07,0,0,-s*.3);}else{PA(q,GCONE,fur,0,.14,0,.11,.3,.07,0,0,-s*.15);PA(q,GCONE,G,0,.27,0,.04,.1,.03,0,0,-s*.15);}}));
  if(!pup)[-1,1].forEach(s=>PH(GCONE,G,s*.28,-.06,.1,.05,.14,.04,0,0,-s*(Math.PI/2+.3)));else PH(GCONE,fur,0,.3,0,.04,.12,.04);}
 else if(hf==='bear'){hd(LAC(f.body),.3,.28,.28);PH(GSPH,fc,0,-.1,.2,.17,.12,.12);PH(GSPH,DK,0,-.05,.32,.04,.03,.03);slits(.1,.03,.12,.06,.1);
  [-1,1].forEach(s=>{ear(s,.24,.22,(q)=>{PA(q,GSPH,LAC(f.body),0,0,0,.11,.11,.07);PA(q,GTOR,G,0,0,.02,.09,.09,.09);});PE(GBOX,G,s*.12,.14,sz(.12,.14),.14,.025,.025,0,0,s*.5);});}
 else if(hf==='fox'){hd(fur,.28,.25,.26);PH(GCONE,fc,0,-.08,.28,.1,.3,.1,Math.PI/2,0,0);PH(GSPH,DK,0,-.08,.44,.025);slits(.11,.03,.11,.06,.3);
  [-1,1].forEach(s=>{ear(s,.19,.2,(q)=>{PA(q,GCONE,fur,0,.2,0,.12,.42,.06,0,0,-s*.15);PA(q,GCONE,DK,0,.38,0,.05,.12,.03,0,0,-s*.15);});PH(GCONE,G,s*.27,-.08,.08,.05,.15,.04,0,0,-s*(Math.PI/2+.3));});}
 else if(hf==='rabbit'){hd(LAC(f.body),.27,.28,.26);[-1,1].forEach(s=>{ear(s,.12,.26,(q)=>{PA(q,GSPH,LAC(f.body),0,.4,0,.07,.42,.05,0,0,-s*.1);PA(q,GSPH,G,0,.4,.03,.035,.32,.02,0,0,-s*.1);});PE(GSPH,eye,s*.11,.05,sz(.11,.05),.045,.06,.02);});
  PH(GSPH,G,0,.3,.12,.07,.07,.03);PH(GSPH,LAC(f.body),.03,.31,.14,.06,.06,.03);PH(GOCT,GLO(0xff9ad8),0,-.05,sz(0,-.05),.025,.03,.02);}
 else if(hf==='penguin'){hd(LAC(f.body),.28,.26,.26);PH(GSPH,POR(f.belly),0,-.03,.12,.2,.2,.16);PH(GCONE,G,0,-.07,.3,.07,.17,.07,Math.PI/2,0,0);[-1,1].forEach(s=>PE(GSPH,eye,s*.1,.07,.28,.035));
  const h=mkG(H,0,.2,0);PA(h,GSPH,DK,0,.04,0,.3,.17,.3);PA(h,GBOX,G,0,0,.28,.3,.025,.2);PA(h,GOCT,GLO(0x6dff9a),0,.06,.29,.05,.05,.02);}
 else if(hf==='chick'){hd(LAC(f.body),.3,.28,.28);PH(GCONE,G,0,-.06,.3,.07,.16,.07,Math.PI/2,0,0);PH(GTOR,DK,0,.06,0,.3,.3,.3,Math.PI/2);
  [-1,1].forEach(s=>{PH(GTOR,G,s*.12,.08,.26,.1,.1,.1);PH(GCYL,GLO(0xaee7ff),s*.12,.08,.255,.09,.015,.09,Math.PI/2);});PH(GCONE,G,0,.3,0,.04,.12,.04,0,0,.3);PH(GCONE,G,.05,.29,0,.035,.1,.035,0,0,-.4);}
 else if(hf==='alien'){hd(LAC(0x0c1a14),.34,.4,.3);[-1,1].forEach(s=>{PE(GSPH,eye,s*.15,0,.28,.1,.17,.03,0,0,s*.5);PH(GCYL,G,s*.1,.42,0,.012,.18,.012,0,0,-s*.25);PH(GOCT,GLO(f.eye),s*.15,.62,0,.04,.05,.04);});PH(GBOX,G,0,-.2,.25,.08,.012,.01);}
 else if(hf==='sun'){hd(G,.3,.3,.28);[-1,1].forEach(s=>{PE(GSPH,DK,s*.11,.04,sz(.11,.04),.08,.1,.04);PE(GSPH,eye,s*.11,.03,sz(.11,.04)+.03,.022);});PH(GCONE,DK,0,-.06,sz(0,-.06)+.01,.03,.07,.02,Math.PI,0,0);PH(GBOX,DK,0,-.2,sz(0,-.2),.17,.025,.02);[-2,-1,0,1,2].forEach(i=>PH(GBOX,DK,i*.04,-.2,sz(i*.04,-.2),.008,.07,.02));
  const SG=mkG(H,0,0,-.12);for(let i=0;i<14;i++){const a=i/14*TAU,l=i%2?.3:.5;PA(SG,GCONE,G,Math.cos(a)*(.5+l/2),Math.sin(a)*(.5+l/2),0,.07,l,.07,0,0,a-Math.PI/2);}rig.spin.push({g:SG,s:.35,ax:'z'});}
 else if(hf==='mask'){hd(DK,.3,.34,.28);PH(GSPH,fc,0,-.02,.18,.22,.28,.1);[-1,1].forEach(s=>PE(GBOX,eye,s*.09,.04,.285,.07,.025,.02,0,0,-s*.3));PH(GBOX,DK,0,-.14,.285,.06,.012,.01);
  for(let i=-4;i<=4;i++)PH(GCONE,DK,i*.085,.3-Math.abs(i)*.02,0,.035,.5-Math.abs(i)*.05,.035,0,0,-i*.13);PH(GTOR,G,0,.28,0,.26,.26,.26,Math.PI/2);}
 else if(hf==='capy'){hd(LAC(f.body),.3,.26,.28);PH(GBOX,LAC(0x8a5a2e),0,-.08,.26,.26,.16,.2);[-1,1].forEach(s=>{PH(GSPH,DK,s*.05,-.03,.37,.025);ear(s,.22,.2,(q)=>PA(q,GSPH,LAC(f.body),0,0,0,.07));});slits(.1,.025,.13,.06,.1);PH(GOCT,GLO(0xff9a1a),0,.3,0,.07,.09,.07);PH(GTOR,G,0,.27,0,.09,.09,.09,Math.PI/2);}
 else if(hf==='octo'){hd(LAC(f.body),.34,.36,.32,0,.05);[-1,1].forEach(s=>PE(GSPH,eye,s*.14,.05,sz(.14,.05),.07,.09,.03));PH(GOCT,GLO(0xffd36b),0,.45,0,.06,.1,.06);PH(GTOR,G,0,.38,0,.2,.2,.2,Math.PI/2);}
 else if(hf==='ghost'){hd(POR(f.body),.3,.28,.28);[-1,1].forEach(s=>{PE(GSPH,DK,s*.1,.04,sz(.1,.04),.06,.09,.03);PE(GSPH,eye,s*.1,.03,sz(.1,.04)+.03,.018);});PH(GTOR,DK,0,-.12,sz(0,-.12),.05,.07,.02);const hl=mkG(H,0,.42,0);PA(hl,GTOR,G,0,0,0,.22,.22,.22,Math.PI/2);rig.spin.push({g:hl,s:1.2,ax:'y'});}
 else if(hf==='block'){PH(GBOX,POR(f.face),0,0,0,.52,.5,.46);[-1,1].forEach(s=>PE(GBOX,eye,s*.12,.04,.236,.05,.07,.02));PH(GBOX,DK,0,-.12,.236,.1,.018,.01);const rd=LAC(0xa11424);for(let i=0;i<5;i++)PH(GCONE,rd,(i-2)*.1,.34,-.02,.05,.2,.05,0,0,(i-2)*.2);PH(GBOX,DK,0,.3,0,.56,.12,.5);PH(GBOX,G,0,.27,.3,.5,.04,.2);}
 if(f.tail){const TG=mkG(g,0,.62,-.16);rig.tail=TG;rig.tailSp=f.tail==='fox'?2.4:3;
  if(f.tail==='fox'){PA(TG,GCONE,fur,0,.14,-.3,.14,.5,.14,-1.1,0,0);PA(TG,GSPH,POR(0xfff0d8),0,.3,-.58,.09);}
  else for(let i=0;i<9;i++)PA(TG,GSPH,i%2?G:B,0,.01*i*i,-.07*i,.05*(1-i*.06));}
 return finishPlush(g,rig);}
/*PLUSH_END*/
Object.keys(FIG).forEach(k=>{B[k]=()=>{try{return buildFigure(FIG[k]);}catch(e){console.error('figura',k,e);return new THREE.Group();}};});
function makePlush(sp,rar,pile){const root=new THREE.Group(),body=B[SPECIES[sp].k]();body.scale.setScalar(SPECIES[sp].sc);root.add(body);
 root.userData={root:true,sp,rar,body};if(!pile){const mats=tint(body,rar),a=buildAura(rar,mats);if(a){root.add(a.group);root.userData.aura=a;}}return root;}
function disposePlush(r){r.traverse(o=>{if(o.userData&&o.userData.own&&o.material)o.material.dispose();if(o.isPoints||(o.isMesh&&o.geometry&&!Object.values(GEO).includes(o.geometry))){if(o.geometry)o.geometry.dispose();if(o.material&&o.material.dispose&&!(o.userData&&o.userData.own)&&o.material.blending===THREE.AdditiveBlending)o.material.dispose();}});}
const itemById=id=>PL.items.find(i=>i.id===id);
const pValue=(sp,rar)=>Math.max(0,Math.round(cfg.plush.rar[rar].v*(cfg.plush.spMul[sp]||1)));
const sellValue=it=>Math.round(pValue(it.sp,it.rar)*cfg.plush.sellPct/100);
function pickRar(){const R=cfg.plush.rar;let t=0;RARS.forEach(r=>t+=Math.max(0,R[r].p));if(t<=0)return'normal';let x=Math.random()*t;for(const r of RARS){x-=Math.max(0,R[r].p);if(x<=0)return r;}return'normal';}
function addItem(sp,rar){const it={id:PL.next++,sp,rar,name:SPECIES[sp].n,slot:-1};PL.items.push(it);savePL();return it;}
function plushFx(rar){const i=RARS.indexOf(rar),k=['stars','lights'];if(i>=2)k.push('fireworks');if(i>=4)k.push('rainbow');if(i>=5)k.push('gold');if(i>=6)k.push('fire');fxPlay(k,i>=4);i>=3?sfx.jack():sfx.win();}

/* ================= MÁQUINA DE PELUCHES ================= */
const FLOOR=1.52,TOPY=4.75;
const CL=mkScene({fov:40,dir:[0,.12,1],fitW:5.8,fitH:7.4,shift:.05,target:[0,3.1,0]});
addLights(CL.scene);
const CLW={x:0,z:0,tx:0,tz:0,y:TOPY,open:.75,busy:false,key:{}};
CL.prongs=[];CL.pile=[];
function buildClaw(){const sc=CL.scene,go=goldMat(0xd4a23a),pur=new THREE.MeshStandardMaterial({color:0x2a1a50,metalness:.5,roughness:.4}),dark=new THREE.MeshStandardMaterial({color:0x14102a,metalness:.3,roughness:.7}),steel=GL(0xb8c0d0,.9,.25);
 const add=(g,m,x,y,z)=>{const o=new THREE.Mesh(g,m);o.position.set(x,y,z);sc.add(o);return o;},bx=(w,h,d)=>new THREE.BoxGeometry(w,h,d);
 add(bx(4.7,1.5,3.7),pur,0,.75,0);add(bx(4.8,.1,3.8),go,0,1.5,0);add(bx(4.8,.1,3.8),go,0,.05,0);
 add(new THREE.PlaneGeometry(4.3,3.4).rotateX(-Math.PI/2),new THREE.MeshStandardMaterial({color:0x24123e,roughness:.8}),0,FLOOR-.04,0);
 [-1,1].forEach(sx=>[-1,1].forEach(sz=>add(bx(.16,3.5,.16),go,sx*2.2,3.27,sz*1.7)));
 add(bx(4.7,1.05,3.7),pur,0,5.55,0);add(bx(4.8,.1,3.8),go,0,5.02,0);add(bx(4.8,.1,3.8),go,0,6.08,0);
 const mc=document.createElement('canvas');mc.width=1024;mc.height=190;const mg=mc.getContext('2d');mg.fillStyle='#120a22';mg.fillRect(0,0,1024,190);mg.strokeStyle='rgba(255,230,160,.8)';mg.lineWidth=6;mg.strokeRect(10,10,1004,170);mg.textAlign='center';mg.textBaseline='middle';
 mg.font='900 96px "Cinzel Decorative",Cinzel,Georgia,serif';const lg=mg.createLinearGradient(0,30,0,160);lg.addColorStop(0,'#fff2c0');lg.addColorStop(.5,'#e7b84b');lg.addColorStop(1,'#9a6a12');mg.fillStyle=lg;mg.fillText('LOYA PELUCHES',512,98);
 add(new THREE.PlaneGeometry(4.3,.8),new THREE.MeshBasicMaterial({map:canvasTex(mc)}),0,5.55,1.87);
 add(new THREE.PlaneGeometry(4.3,3.5),dark,0,3.27,-1.72);
 const glass=new THREE.MeshStandardMaterial({color:0x9fb0ff,transparent:true,opacity:.1,roughness:.05,metalness:.3,side:THREE.DoubleSide,depthWrite:false});
 add(new THREE.PlaneGeometry(4.3,3.5),glass,0,3.27,1.75);const gl1=add(new THREE.PlaneGeometry(3.4,3.5),glass,-2.22,3.27,0);gl1.rotation.y=Math.PI/2;const gl2=add(new THREE.PlaneGeometry(3.4,3.5),glass,2.22,3.27,0);gl2.rotation.y=Math.PI/2;
 add(bx(1,.75,.12),dark,-1.45,.8,1.88);add(bx(1.1,.06,.14),go,-1.45,1.2,1.9);add(bx(1.1,.06,.14),go,-1.45,.42,1.9);
 CL.chute=add(new THREE.CircleGeometry(.5,32).rotateX(-Math.PI/2),new THREE.MeshBasicMaterial({color:0x3be0ff,transparent:true,opacity:.35,blending:THREE.AdditiveBlending,depthWrite:false}),-1.4,FLOOR-.02,.9);
 add(bx(.1,.1,3.6),go,-2.0,TOPY+.35,0);add(bx(.1,.1,3.6),go,2.0,TOPY+.35,0);
 CL.bar=add(bx(4.1,.1,.14),go,0,TOPY+.35,0);CL.car=add(bx(.4,.22,.4),dark,0,TOPY+.35,0);
 CL.cable=add(GEO.cyl,steel,0,3.5,0);
 CL.claw=new THREE.Group();sc.add(CL.claw);PM(CL.claw,'sph',steel,.2,.16,.2,0,0,0);PM(CL.claw,'cyl',steel,.08,.18,.08,0,.15,0);
 CL.prongs=[];for(let i=0;i<3;i++){const a=i/3*TAU,piv=new THREE.Group();piv.position.set(Math.cos(a)*.17,-.08,Math.sin(a)*.17);piv.rotation.y=-a;const sw=new THREE.Group();piv.add(sw);
  PM(sw,'cyl',steel,.035,.55,.035,0,-.28,0);PM(sw,'cyl',steel,.03,.32,.03,-.1,-.66,0,0,0,-.7);PM(sw,'sph',steel,.045,.045,.045,0,-.02,0);CL.claw.add(piv);CL.prongs.push(sw);}
 CL.shadow=add(new THREE.CircleGeometry(.5,24).rotateX(-Math.PI/2),new THREE.MeshBasicMaterial({color:0x000000,transparent:true,opacity:.4,depthWrite:false}),0,FLOOR-.01,0);
 CL.bulbs=[];const bg=new THREE.SphereGeometry(.07,10,8);for(let i=0;i<12;i++){const m=new THREE.MeshBasicMaterial({color:0xffd36b});add(bg,m,-2+i*.364,5.1,1.9);CL.bulbs.push(m);}
 buildPile();}
function buildPile(){CL.pile.forEach(r=>{CL.scene.remove(r);disposePlush(r);});CL.pile=[];const spots=[];
 for(let zi=0;zi<3;zi++)for(let xi=0;xi<5;xi++){const x=-1.65+xi*.82+rnd(-.1,.1),z=-1.0+zi*.75+rnd(-.1,.1);if(x<-.8&&z>.05)continue;spots.push([x,z,0]);}
 for(let i=0;i<4;i++)spots.push([rnd(-.4,1.6),rnd(-.8,.6),.42]);
 spots.forEach(s=>{const r=makePlush(ri(0,SPECIES.length-1),'normal',true);r.scale.setScalar(.58*(1+rnd(-.08,.12)));r.position.set(s[0],FLOOR+.02+s[2],s[1]);r.rotation.set(0,rnd(0,TAU),rnd(-.1,.1));CL.scene.add(r);CL.pile.push(r);});}
CL.update=(T,dt)=>{const k=CLW.key;
 if(!CLW.busy){const sp=1.8*dt;if(k.l)CLW.tx-=sp;if(k.r)CLW.tx+=sp;if(k.u)CLW.tz-=sp;if(k.d)CLW.tz+=sp;CLW.tx=clamp(CLW.tx,-1.7,1.7);CLW.tz=clamp(CLW.tz,-1.2,1.2);const e=1-Math.exp(-dt*7);CLW.x+=(CLW.tx-CLW.x)*e;CLW.z+=(CLW.tz-CLW.z)*e;}
 const sw=CLW.busy?0:Math.sin(T*2)*.02;CL.claw.position.set(CLW.x+sw,CLW.y,CLW.z);CL.bar.position.z=CLW.z;CL.car.position.set(CLW.x,TOPY+.35,CLW.z);
 const len=TOPY+.35-CLW.y-.1;CL.cable.scale.set(.02,Math.max(.01,len),.02);CL.cable.position.set(CLW.x+sw,CLW.y+.1+len/2,CLW.z);
 CL.prongs.forEach(p=>p.rotation.z=CLW.open);const h=clamp((CLW.y-FLOOR)/3.3,0,1);CL.shadow.position.set(CLW.x,FLOOR-.01,CLW.z);CL.shadow.scale.setScalar(.7+h*.5);CL.shadow.material.opacity=.5-h*.3;
 CL.chute.material.opacity=.28+.12*Math.sin(T*3);CL.bulbs.forEach((m,i)=>m.color.setHSL(.12,1,((Math.floor(T*(CLW.busy?8:3))+i)%3===0)?.62:.2));clawMotor(dt);};
function clawEnter(){CLW.x=CLW.tx=0;CLW.z=CLW.tz=0;CLW.y=TOPY;CLW.open=.75;CLW.key={};}
function clawUI(){const b=$('#clGrab');if(b)b.disabled=CLW.busy;}
async function clawGrab(){if(CLW.busy)return;const c=cfg.plush;
 if(CLW.x<-.8&&CLW.z>.05){toast('Esa es la salida. Mueve la garra sobre los peluches');return;}
 if(S.coins<c.cost){toast('No tienes monedas suficientes');return;}
 addCoins(-c.cost);fairSfx('go');CLW.busy=true;CLW.key={};clawUI();CLW.tx=CLW.x;CLW.tz=CLW.z;
 const ok=Math.random()*100<c.grabChance,y0=CLW.y,yb=FLOOR+1.12,sx=CLW.x,sz=CLW.z;let pr=null,held;
 fairSfx('desc');await tw(.9,e=>CLW.y=y0+(yb-y0)*e,E.io);fairSfx('clack');await tw(.55,e=>CLW.open=.75+(-.2-.75)*e,E.io);sfx.card();
 if(ok){pr={sp:ri(0,SPECIES.length-1),rar:pickRar()};held=makePlush(pr.sp,pr.rar,false);}else held=makePlush(ri(0,SPECIES.length-1),'normal',true);
 held.scale.setScalar(.6);held.position.set(0,-1.12,0);CL.claw.add(held);
 const drop=async()=>{const wp=new THREE.Vector3();held.getWorldPosition(wp);CL.claw.remove(held);held.position.copy(wp);CL.scene.add(held);
  tw(.4,e=>CLW.open=-.2+.95*e,E.io);await tw(.7,e=>{held.position.y=wp.y-(wp.y-(FLOOR-.3))*e*e;held.rotation.z=e*1.6;held.rotation.x=e*.8;},E.io);CL.scene.remove(held);disposePlush(held);};
 if(ok){await tw(1.1,e=>CLW.y=yb+(TOPY-yb)*e+Math.sin(e*18)*.03*(1-e),E.io);
  await tw(1.2,e=>{CLW.x=sx+(-1.4-sx)*e;CLW.z=sz+(.9-sz)*e;CLW.tx=CLW.x;CLW.tz=CLW.z;},E.io);
  await drop();
  CLW.open=.75;const it=addItem(pr.sp,pr.rar),dup=PL.items.some(x=>x.id!==it.id&&x.sp===it.sp&&x.rar===it.rar);
  await tw(.6,e=>{CLW.x=-1.4*(1-e);CLW.z=.9*(1-e);CLW.tx=CLW.x;CLW.tz=CLW.z;},E.io);
  CLW.busy=false;clawUI();
  fairSfx('win');if(S.game==='claw')viewPlush(it.id,'claw',true,dup);else toast('Conseguiste a '+SPECIES[it.sp].n+' ('+RAR[it.rar].n+')');
 }else{await tw(.6,e=>CLW.y=yb+(TOPY-yb)*.5*e,E.io);await drop();fairSfx('miss');toast('¡Se escapó! Inténtalo otra vez');
  await tw(.6,e=>CLW.y=yb+(TOPY-yb)*(.5+.5*e),E.io);await tw(.4,e=>CLW.open=-.2+.95*e,E.io);CLW.busy=false;clawUI();}}
function setKey(k,v){if(k)CLW.key[k]=v;}
$('#panel').addEventListener('pointerdown',e=>{const b=e.target.closest('[data-k]');if(b){setKey(b.dataset.k,true);e.preventDefault();}});
addEventListener('pointerup',()=>{CLW.key={};});addEventListener('pointercancel',()=>{CLW.key={};});
const clPlane=new THREE.Plane(new THREE.Vector3(0,1,0),-TOPY);let clDrag=null;
$('#gl').addEventListener('pointerdown',e=>{if(S.game!=='claw'||CLW.busy)return;clDrag=e.pointerId;moveClawTo(e);});
$('#gl').addEventListener('pointermove',e=>{if(clDrag===e.pointerId&&S.game==='claw'&&!CLW.busy)moveClawTo(e);});
$('#gl').addEventListener('pointerup',e=>{if(clDrag===e.pointerId)clDrag=null;});
function moveClawTo(e){pNdc(e);ray.setFromCamera(ndc,CL.camera);const pt=new THREE.Vector3();if(ray.ray.intersectPlane(clPlane,pt)){CLW.tx=clamp(pt.x,-1.7,1.7);CLW.tz=clamp(pt.z,-1.2,1.2);}}
function panelClaw(){const c=cfg.plush;setHud('Mueve la garra y pulsa BAJAR');
 $('#panel').innerHTML='<div class="info"><div><small>Cada intento</small><b>'+fmt(c.cost)+'</b></div><div><small>Probabilidad</small><b>'+Math.round(c.grabChance)+'%</b></div><div><small>Colección</small><b>'+PL.items.length+'</b></div></div>'
 +'<div class="claw-ctl"><div class="pad"><button class="pf" data-k="u" aria-label="Atrás">▲</button><button class="pl" data-k="l" aria-label="Izquierda">◀</button><button class="pd" data-k="d" aria-label="Adelante">▼</button><button class="pr" data-k="r" aria-label="Derecha">▶</button></div>'
 +'<button class="btn grab" id="clGrab" data-a="grab"'+(CLW.busy?' disabled':'')+'>BAJAR</button><button class="icon" data-a="ccoll" aria-label="Colección" style="width:54px;height:54px;font-size:24px">🧸</button></div>';}

/* ================= ESTANTERÍA ================= */
const SH=mkScene({fov:40,dir:[0,.05,1],fitW:7.8,fitH:6,shift:.08,target:[0,2,0]});
addLights(SH.scene);
Object.assign(SH,{plush:new Map(),markers:[],rowsG:[],sel:-1,drag:null,root:new THREE.Group()});SH.scene.add(SH.root);
const slotPos=i=>new THREE.Vector3(((i%5)-2)*1.3,Math.floor(i/5)*2.05+.1,0);
const shelfRows=()=>2+PL.upg,slotItem=s=>PL.items.find(i=>i.slot===s);
function wallTex(){const c=document.createElement('canvas');c.width=256;c.height=128;const g=c.getContext('2d');const gr=g.createLinearGradient(0,0,0,128);gr.addColorStop(0,'#1d1233');gr.addColorStop(1,'#120a22');g.fillStyle=gr;g.fillRect(0,0,256,128);g.save();g.translate(128,150);g.strokeStyle='rgba(231,184,75,.12)';g.lineWidth=3;for(let i=0;i<20;i++){g.rotate(Math.PI/20);g.beginPath();g.moveTo(0,0);g.lineTo(0,-260);g.stroke();}g.restore();return canvasTex(c);}
function markerTex(){const c=document.createElement('canvas');c.width=128;c.height=160;const g=c.getContext('2d');g.setLineDash([10,8]);g.strokeStyle='rgba(231,184,75,.9)';g.lineWidth=4;rrect(g,10,10,108,140,24);g.stroke();g.setLineDash([]);g.fillStyle='rgba(231,184,75,.9)';g.fillRect(58,60,12,40);g.fillRect(44,74,40,12);return canvasTex(c);}
function plaque(it){const c=document.createElement('canvas');c.width=256;c.height=64;const g=c.getContext('2d');g.fillStyle='#120a22';rrect(g,2,2,252,60,14);g.fill();g.strokeStyle=RAR[it.rar].c;g.lineWidth=4;rrect(g,2,2,252,60,14);g.stroke();g.fillStyle='#f6ecd0';g.textAlign='center';g.textBaseline='middle';const t=it.name.length>12?it.name.slice(0,11)+'…':it.name;g.font='800 30px Cinzel,Georgia,serif';g.fillText(t,128,34);
 const m=new THREE.Mesh(new THREE.PlaneGeometry(1.05,.26),new THREE.MeshBasicMaterial({map:canvasTex(c),transparent:true}));return m;}
function clearShelfPlush(){SH.plush.forEach(r=>{SH.root.remove(r);if(r.userData.pl){SH.root.remove(r.userData.pl);r.userData.pl.material.map.dispose();r.userData.pl.material.dispose();r.userData.pl.geometry.dispose();}disposePlush(r);});SH.plush.clear();}
function refreshShelfPlush(hopId){clearShelfPlush();const cap=shelfRows()*5;
 PL.items.forEach(it=>{if(it.slot<0||it.slot>=cap)return;const r=makePlush(it.sp,it.rar,false);r.scale.setScalar(.82);const p=slotPos(it.slot);r.position.copy(p);r.userData.item=it;r.userData.base=p.clone();r.userData.ph=rnd(0,TAU);SH.root.add(r);SH.plush.set(it.id,r);
  const pl=plaque(it);pl.position.set(p.x,p.y+.14,.62);pl.rotation.x=-.25;SH.root.add(pl);r.userData.pl=pl;
  if(it.id===hopId){tw(.7,e=>{r.userData.hop=Math.sin(e*Math.PI)*.8;r.scale.set(.82*(1+Math.sin(e*Math.PI*3)*.06*(1-e)),.82*(1-Math.sin(e*Math.PI*3)*.06*(1-e)),.82);},E.out);}});
 SH.markers.forEach(m=>{m.visible=!slotItem(m.userData.slot);});}
function buildShelf(animRow){SH.rowsG.forEach(g=>{SH.root.remove(g);g.traverse(o=>{if(o.geometry)o.geometry.dispose();});});SH.markers.forEach(m=>{SH.root.remove(m);m.material.dispose();});SH.rowsG=[];SH.markers=[];
 const rows=shelfRows(),go=goldMat(0xc99a34),wood=new THREE.MeshStandardMaterial({color:0x2a1a3a,metalness:.3,roughness:.6}),wt=SH.wt||(SH.wt=wallTex()),wm=new THREE.MeshStandardMaterial({map:wt,roughness:.9}),mt=SH.mt||(SH.mt=markerTex());
 for(let r=0;r<rows;r++){const g=new THREE.Group();g.position.y=r*2.05;
  const add=(geo,m,x,y,z)=>{const o=new THREE.Mesh(geo,m);o.position.set(x,y,z);g.add(o);return o;};
  add(new THREE.BoxGeometry(6.9,.2,1.3),wood,0,0,.1);add(new THREE.BoxGeometry(6.9,.06,1.34),go,0,.1,.1);add(new THREE.BoxGeometry(6.8,2.05,.1),wm,0,1.05,-.5);
  add(new THREE.BoxGeometry(.2,2.05,1.3),go,-3.45,1.0,.1);add(new THREE.BoxGeometry(.2,2.05,1.3),go,3.45,1.0,.1);
  SH.root.add(g);SH.rowsG.push(g);}
 const top=new THREE.Mesh(new THREE.BoxGeometry(7.1,.3,1.4),go);top.position.set(0,rows*2.05+.05,.1);const tg=new THREE.Group();tg.add(top);SH.root.add(tg);SH.rowsG.push(tg);
 for(let i=0;i<rows*5;i++){const m=new THREE.Mesh(new THREE.PlaneGeometry(1.1,1.45),new THREE.MeshBasicMaterial({map:mt,transparent:true,opacity:.4,depthWrite:false}));const p=slotPos(i);m.position.set(p.x,p.y+.8,.45);m.userData.slot=i;SH.root.add(m);SH.markers.push(m);}
 SH.fitH=rows*2.05+1.8;SH.target.set(0,rows*1.02+.1,0);SH.fit();
 if(animRow){const g=SH.rowsG[rows-1],top2=SH.rowsG[rows];g.scale.set(1,.01,1);g.position.y=(rows-1)*2.05;tw(.8,e=>{g.scale.y=Math.max(.01,e);},E.back);const ty=top2.position.y;top2.position.y=-2;tw(.8,e=>{top2.position.y=-2*(1-e);},E.out);fxPlay(['stars'],false);sfx.win();}
 refreshShelfPlush();}
SH.update=(T,dt)=>{SH.plush.forEach(r=>{const u=r.userData;if(u.drag)return;r.position.y=u.base.y+Math.sin(T*1.6+u.ph)*.025+(u.hop||0);r.rotation.y=Math.sin(T*.7+u.ph)*.18;if(u.aura)u.aura.update(T);});
 SH.markers.forEach(m=>{m.material.opacity=m.userData.slot===SH.sel?.95:.28+.1*Math.sin(T*2+m.userData.slot);});};
const shPlane=new THREE.Plane(new THREE.Vector3(0,0,1),-.4),shV=new THREE.Vector3();
function shRay(e){pNdc(e);ray.setFromCamera(ndc,SH.camera);}
$('#gl').addEventListener('pointerdown',e=>{if(S.game!=='shelf')return;shRay(e);
 const bodies=Array.from(SH.plush.values()).map(r=>r.userData.body);const hs=ray.intersectObjects(bodies,true);
 if(hs.length){let o=hs[0].object;while(o&&!(o.userData&&o.userData.root))o=o.parent;if(o){SH.drag={r:o,sx:e.clientX,sy:e.clientY,id:e.pointerId,on:false};try{$('#gl').setPointerCapture(e.pointerId);}catch(_){}return;}}
 const mh=ray.intersectObjects(SH.markers.filter(m=>m.visible),false);if(mh.length){SH.sel=mh[0].object.userData.slot;sfx.card();panelShelf();}else if(SH.sel>=0){SH.sel=-1;panelShelf();}});
$('#gl').addEventListener('pointermove',e=>{const d=SH.drag;if(!d||d.id!==e.pointerId||S.game!=='shelf')return;
 if(!d.on&&Math.hypot(e.clientX-d.sx,e.clientY-d.sy)>8){d.on=true;d.r.userData.drag=true;d.r.userData.pl.visible=false;d.r.scale.setScalar(.95);sfx.card();}
 if(d.on){shRay(e);if(ray.ray.intersectPlane(shPlane,shV)){d.r.position.set(clamp(shV.x,-3.2,3.2),shV.y-.7,.5);d.r.rotation.z=clamp((shV.x-d.r.position.x)*.2,-.3,.3);d.r.rotation.y=0;d.px=shV.x;d.py=shV.y;}}});
function endShDrag(e,cancel){const d=SH.drag;if(!d||d.id!==e.pointerId)return;SH.drag=null;const it=d.r.userData.item;
 if(!d.on){if(!cancel)viewPlush(it.id,'shelf',false,false);return;}
 let best=-1,bd=1.3;const cap=shelfRows()*5;for(let i=0;i<cap;i++){const p=slotPos(i),dd=Math.hypot(p.x-d.px,p.y+.7-d.py);if(dd<bd){bd=dd;best=i;}}
 if(best>=0&&!cancel){const other=slotItem(best);if(other&&other!==it)other.slot=it.slot;it.slot=best;savePL();refreshShelfPlush(it.id);}else refreshShelfPlush();panelShelf();}
$('#gl').addEventListener('pointerup',e=>endShDrag(e,false));$('#gl').addEventListener('pointercancel',e=>endShDrag(e,true));
function upgCost(){return Math.round(cfg.plush.upgBase+cfg.plush.upgStep*PL.upg);}
const MAXUPG=8;
function buyUpgrade(){if(PL.upg>=MAXUPG){toast('El estante ya está al máximo');return;}const c=upgCost();if(S.coins<c){toast('Necesitas '+fmt(c)+' monedas');return;}addCoins(-c);PL.upg++;savePL();buildShelf(true);panelShelf();}
function placeItem(id){const it=itemById(id);if(!it)return;const cap=shelfRows()*5;let s=SH.sel;if(s<0||slotItem(s)||s>=cap){s=-1;for(let i=0;i<cap;i++)if(!slotItem(i)){s=i;break;}}
 if(s<0){toast('No hay espacio: compra una sección nueva');return;}it.slot=s;SH.sel=-1;savePL();refreshShelfPlush(id);panelShelf();sfx.card();}
function shelfEnter(){SH.sel=-1;buildShelf(false);}
function panelShelf(){const cap=shelfRows()*5,used=PL.items.filter(i=>i.slot>=0&&i.slot<cap).length,free=PL.items.filter(i=>i.slot<0);
 setHud(SH.sel>=0?'Elige un peluche para el lugar '+(SH.sel+1):'Arrastra los peluches para acomodarlos · toca uno para verlo');
 $('#panel').innerHTML='<div class="info"><div><small>Estante</small><b>'+used+'/'+cap+'</b></div><div><small>Nueva sección (+5)</small><b>'+(PL.upg>=MAXUPG?'Máx.':fmt(upgCost()))+'</b></div><div><small>Colección</small><b>'+PL.items.length+'</b></div></div>'
 +(free.length?'<div class="chips">'+free.map(it=>'<button class="chip2" data-a="place" data-v="'+it.id+'" style="--rc:'+RAR[it.rar].c+'"><span>'+SPECIES[it.sp].ico+'</span>'+esc(it.name.length>9?it.name.slice(0,8)+'…':it.name)+'</button>').join('')+'</div>':'<div class="cap">'+(PL.items.length?'Todo tu peluchería está en el estante.':'Aún no tienes peluches. Consíguelos en la máquina.')+'</div>')
 +'<div class="seg"><button data-a="upg"'+(PL.upg>=MAXUPG?' disabled':'')+'>Comprar sección</button><button data-a="coll">Ver colección</button></div>';}

/* ================= VISOR 3D ================= */
const PV=mkScene({fov:40,dir:[0,.12,1],fitW:5,fitH:5.8,shift:.1,target:[0,1.1,0]});
addLights(PV.scene);
Object.assign(PV,{root:null,vel:.4,dr:null,beams:new THREE.Group()});
(function(){const sc=PV.scene,go=goldMat(0xd4a23a);const ped=new THREE.Mesh(new THREE.CylinderGeometry(1.25,1.4,.3,48),go);ped.position.y=-.15;sc.add(ped);
 const ring=new THREE.Mesh(new THREE.TorusGeometry(1.3,.025,8,64),new THREE.MeshBasicMaterial({color:0xffd36b,transparent:true,opacity:.8,blending:THREE.AdditiveBlending,depthWrite:false}));ring.rotation.x=Math.PI/2;sc.add(ring);
 {const bs=new THREE.Sprite(new THREE.SpriteMaterial({map:raysT2(),color:0xffd36b,transparent:true,opacity:.5,blending:THREE.AdditiveBlending,depthWrite:false}));bs.scale.set(11,11,1);bs.position.set(0,1.3,-3);PV.beams.add(bs);PV.bs=bs;}
 for(let i=0;i<9;i++){const c=new THREE.Mesh(new THREE.ConeGeometry(.5,7,20,1,true),new THREE.MeshBasicMaterial({color:new THREE.Color().setHSL(i/9,.9,.6),transparent:true,opacity:.17,blending:THREE.AdditiveBlending,depthWrite:false,side:THREE.DoubleSide}));c.position.set(0,3,-1.4);c.rotation.z=(i-4)*.26;PV.beams.add(c);}
 sc.add(PV.beams);PV.beams.position.y=.1;
 const n=160,pos=new Float32Array(n*3);for(let i=0;i<n;i++){pos[i*3]=rnd(-5,5);pos[i*3+1]=rnd(-1,6);pos[i*3+2]=rnd(-4,1);}const geo=new THREE.BufferGeometry();geo.setAttribute('position',new THREE.BufferAttribute(pos,3));
 PV.pts=new THREE.Points(geo,new THREE.PointsMaterial({color:0xffd98a,size:.07,transparent:true,opacity:.7,depthWrite:false,blending:THREE.AdditiveBlending}));sc.add(PV.pts);})();
PV.show=(it,rev)=>{if(PV.root){PV.scene.remove(PV.root);disposePlush(PV.root);}const r=makePlush(it.sp,it.rar,false);PV.root=r;PV.scene.add(r);PV.beams.visible=rev;PV.bs.material.color.set(it.rar==='normal'?0xffd36b:(it.rar==='unico'?0xffffff:auraCol(it.rar)));PV.vel=.4;
 r.scale.setScalar(.01);const d=1.5;tw(.9,e=>r.scale.setScalar(Math.max(.01,d*e)),E.back);if(rev)tw(1.8,e=>{if(!PV.dr)r.rotation.y=e*Math.PI*4;},E.out);else r.rotation.y=0;};
PV.update=(T,dt)=>{const r=PV.root;if(r){if(!PV.dr){PV.vel+=(.4-PV.vel)*Math.min(1,dt*1.5);r.rotation.y+=PV.vel*dt;}r.position.y=Math.sin(T*1.5)*.04;if(r.userData.aura)r.userData.aura.update(T);}
 PV.bs.material.rotation=T*.3;PV.beams.rotation.z=Math.sin(T*.6)*.18;PV.beams.children.forEach((c,i)=>{if(c.isMesh)c.material.color.setHSL((T*.1+i/9)%1,.9,.6);});if(PV.root&&PV.root.userData.rar==='unico')PV.bs.material.color.setHSL((T*.2)%1,1,.6);PV.pts.rotation.y=T*.03;};
$('#gl').addEventListener('pointerdown',e=>{if(S.game!=='view')return;PV.dr={id:e.pointerId,x:e.clientX,t:performance.now()};try{$('#gl').setPointerCapture(e.pointerId);}catch(_){}});
$('#gl').addEventListener('pointermove',e=>{const d=PV.dr;if(!d||d.id!==e.pointerId||!PV.root)return;const dx=e.clientX-d.x,n=performance.now(),dt=Math.max(.008,(n-d.t)/1000);PV.root.rotation.y+=dx*.012;PV.vel=clamp(dx*.012/dt,-12,12);d.x=e.clientX;d.t=n;});
$('#gl').addEventListener('pointerup',e=>{if(PV.dr&&PV.dr.id===e.pointerId)PV.dr=null;});$('#gl').addEventListener('pointercancel',()=>{PV.dr=null;});
function viewPlush(id,from,rev,dup){const it=itemById(id);if(!it)return;S.viewId=id;S.viewFrom=from;S.viewReveal=!!rev;S.viewDup=!!dup;S.sellArm=false;S.game='view';show('game');$('#gTitle').textContent=rev?'¡Nuevo peluche!':'Peluche';setScene(PV);PV.show(it,!!rev);panelView();pvLayout();requestAnimationFrame(pvLayout);if(rev)plushFx(it.rar);}
function pvMask(){const cam=PV.camera,v1=new THREE.Vector3(0,.1,0).project(cam),v2=new THREE.Vector3(0,2.4,0).project(cam),W=innerWidth,H=innerHeight,y1=(1-v1.y)/2*H,y2=(1-v2.y)/2*H,h=Math.abs(y1-y2);FXMASK={x:(v1.x+1)/2*W,y:(y1+y2)/2,rx:h*.42,ry:h*.56};}
function pvLayout(){if(S.game!=='view')return;const p=$('#panel'),H=innerHeight,ph=p.offsetHeight||240,top=70,free=Math.max(.4,(H-ph-top)/H);PV.fitH=4.8/free;PV.shift=(ph-top)/(2*H);PV.fit();pvMask();}
function viewBack(){S.viewReveal=false;goGame(S.viewFrom||'shelf');}
function panelView(){const it=itemById(S.viewId);if(!it){viewBack();return;}const sp=SPECIES[it.sp],r=RAR[it.rar],val=sellValue(it),rev=S.viewReveal;
 $('#panel').innerHTML='<input type="text" class="nm" id="pvName" maxlength="16" value="'+esc(it.name)+'" placeholder="Ponle un nombre" autocomplete="off">'
 +'<div class="info"><div><small>Rareza</small><b style="color:'+r.c+'">'+r.n+'</b></div><div><small>Personaje</small><b style="font-size:13px">'+esc(sp.n)+'</b></div><div><small>Vale</small><b>'+fmt(val)+'</b></div></div>'
 +(rev&&S.viewDup?'<div class="cap">Ya tenías uno igual: véndelo o quédatelo.</div>':'')
 +'<div class="seg"><button data-a="pvsell">Vender +'+fmt(val)+'</button>'+(it.slot>=0?'<button data-a="pvunshelf">Quitar del estante</button>':'<button data-a="pvshelf">Poner en estante</button>')+'</div>'
 +'<button class="btn big" data-a="pvback">'+(rev?(S.viewDup?'Quedármelo':'¡Genial!'):'Volver')+'</button>';
 setHud(rev?(S.viewDup?'¡Repetido!':'¡Lo conseguiste!'):it.name);pvLayout();}
function sellItem(id){const it=itemById(id);if(!it)return 0;const v=sellValue(it);PL.items.splice(PL.items.indexOf(it),1);savePL();addCoins(v);sfx.win();return v;}
function pvSell(b){const it=itemById(S.viewId);if(!it)return;if(RARS.indexOf(it.rar)>=3&&!S.sellArm){S.sellArm=true;b.textContent='Toca otra vez para vender';setTimeout(()=>{S.sellArm=false;if(S.game==='view')panelView();},3000);return;}
 const v=sellItem(it.id);toast('Vendido: +'+fmt(v)+' monedas');viewBack();}
function pvToShelf(){const it=itemById(S.viewId);if(!it)return;const cap=shelfRows()*5;let s=-1;for(let i=0;i<cap;i++)if(!slotItem(i)){s=i;break;}if(s<0){toast('No hay espacio: compra una sección nueva en la estantería');return;}it.slot=s;savePL();toast('Colocado en el estante');panelView();}
function pvUnshelf(){const it=itemById(S.viewId);if(!it)return;it.slot=-1;savePL();panelView();}
$('#panel').addEventListener('input',e=>{if(e.target.id==='pvName'){const it=itemById(S.viewId);if(it){it.name=e.target.value.slice(0,16);savePL();}}});
$('#panel').addEventListener('click',e=>{const b=e.target.closest('[data-a]');if(!b)return;const a=b.dataset.a,v=b.dataset.v;
 if(a==='grab')clawGrab();else if(a==='coll'||a==='ccoll')openColl();else if(a==='upg')buyUpgrade();else if(a==='place')placeItem(+v);else if(a==='pvsell')pvSell(b);else if(a==='pvshelf')pvToShelf();else if(a==='pvunshelf')pvUnshelf();else if(a==='pvback')viewBack();});

/* ================= COLECCIÓN ================= */
let dupArm=false;
function openColl(){renderColl();$('#coll').classList.remove('hidden');}
function renderColl(){const items=PL.items.slice().sort((a,b)=>RARS.indexOf(b.rar)-RARS.indexOf(a.rar)||a.sp-b.sp),tot=items.reduce((a,i)=>a+sellValue(i),0);
 $('#collInfo').textContent=items.length+' peluches · valen '+fmt(tot);
 $('#collBody').innerHTML=items.length?items.map(i=>'<div class="crow" data-id="'+i.id+'"><span class="ci">'+SPECIES[i.sp].ico+'</span><span class="cn"><b>'+esc(i.name)+'</b><small style="color:'+RAR[i.rar].c+'">'+RAR[i.rar].n+' · '+esc(SPECIES[i.sp].n)+(i.slot>=0?' · en el estante':'')+'</small></span><span class="cv">'+fmt(sellValue(i))+'</span></div>').join(''):'<div class="note" style="padding:20px 0">Todavía no tienes peluches. Prueba suerte en la máquina.</div>';}
$('#collBody').addEventListener('click',e=>{const r=e.target.closest('[data-id]');if(!r)return;$('#coll').classList.add('hidden');viewPlush(+r.dataset.id,S.game==='claw'?'claw':'shelf',false,false);});
$('#collClose').onclick=()=>$('#coll').classList.add('hidden');
$('#collDupes').onclick=function(){const seen=new Map(),sell=[];PL.items.slice().sort((a,b)=>(b.slot>=0)-(a.slot>=0)).forEach(i=>{const k=i.sp+'-'+i.rar;if(!seen.has(k))seen.set(k,i);else if(i.slot<0)sell.push(i);});
 if(!sell.length){toast('No tienes repetidos para vender');return;}const tot=sell.reduce((a,i)=>a+sellValue(i),0);
 if(!dupArm){dupArm=true;this.textContent='Vender '+sell.length+' por +'+fmt(tot)+' (toca otra vez)';setTimeout(()=>{dupArm=false;this.textContent='Vender repetidos';},3500);return;}
 dupArm=false;this.textContent='Vender repetidos';sell.forEach(i=>sellItem(i.id));toast('Vendidos '+sell.length+' repetidos: +'+fmt(tot));renderColl();if(S.game==='shelf')panelShelf();if(S.game==='claw')panelClaw();};
function initPlush(){buildClaw();buildShelf(false);}

/* ================= bucle principal ================= */
function onResize(){renderer.setSize(innerWidth,innerHeight,false);SCENES.forEach(s=>s.fit());fxResize();bgResize();cardsLayout();pvLayout();}
addEventListener('resize',onResize);
let last=performance.now(),T=0,lastShown=-1;
function loop(now){requestAnimationFrame(loop);const dt=Math.min(.05,(now-last)/1000);last=now;T+=dt;
 runTweens(dt);
 S.shown+=(S.coins-S.shown)*Math.min(1,dt*8);if(Math.abs(S.coins-S.shown)<.5)S.shown=S.coins;const r=Math.round(S.shown);
 if(r!==lastShown){lastShown=r;const t=fmt(r);$$('.coins').forEach(e=>e.textContent=t);}
 if(cur){safe(()=>{cur.update(T,dt);rigTick(T,dt);});renderer.render(cur.scene,cur.camera);}
 if(S.screen==='game'&&S.game==='claw'){if(!FAIR.on)fairStart();}else if(FAIR.on)fairStop();
 safe(()=>coinRender(T));safe(()=>bgStep(dt));safe(()=>fxStep(dt));}
function safe(f){try{f();}catch(e){if(!safe.w){safe.w=1;console.error(e);}}}
function init(){bgResize();renderer.setSize(innerWidth,innerHeight,false);buildAmbCards();try{initPlush();}catch(e){console.error(e);}buildSlots();buildWheelTex();buildFelt();fxResize();setScene(AMB);requestAnimationFrame(loop);
 if(document.fonts&&document.fonts.ready)document.fonts.ready.then(()=>{resetCardTex();buildSlots();buildWheelTex();});}
init();
})();
